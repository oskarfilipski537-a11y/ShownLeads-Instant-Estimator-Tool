import express, { Request, Response } from 'express';
import http from 'http';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Parse JSON with high limit for image payloads
app.use(express.json({ limit: '30mb' }));

// Gemini model configuration constants
const PRIMARY_MODEL = process.env.GEMINI_MODEL || 'gemini-3.8-flash';
const FALLBACK_MODEL = 'gemini-3.1-flash-lite';

// Model circuit-breaker timestamps to prevent calling rate-limited models
let primaryModelCooldownUntil = 0;
let fallbackModelCooldownUntil = 0;

// Server-side Gemini initialization
const apiKey = process.env.GEMINI_API_KEY || '';
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-memory request cache to prevent duplicate calls and protect free tier quota (3min TTL)
const requestCache = new Map<string, { data: any; expiry: number }>();

function getCached<T>(key: string): T | null {
  const item = requestCache.get(key);
  if (item && item.expiry > Date.now()) {
    return item.data as T;
  }
  if (item) requestCache.delete(key);
  return null;
}

function setCache(key: string, data: any, ttlMs: number = 180000) {
  requestCache.set(key, { data, expiry: Date.now() + ttlMs });
}

// Helper to safely call Gemini with quota fallback and circuit breaker
async function executeGeminiSafe<T>(
  cacheKey: string,
  generator: (modelName: string) => Promise<T>,
  fallbackGenerator: () => T
): Promise<T> {
  const cached = getCached<T>(cacheKey);
  if (cached) {
    return cached;
  }

  if (!ai) {
    return fallbackGenerator();
  }

  const now = Date.now();

  // Attempt 1: Primary model (if not currently in rate-limit cooldown)
  if (now >= primaryModelCooldownUntil) {
    try {
      const result = await generator(PRIMARY_MODEL);
      setCache(cacheKey, result);
      return result;
    } catch (error: any) {
      const errorStr = String(error?.message || error || '');
      const isUnavailableOrRateLimited =
        errorStr.includes('429') ||
        errorStr.includes('RESOURCE_EXHAUSTED') ||
        errorStr.includes('quota') ||
        errorStr.includes('503') ||
        errorStr.includes('high demand') ||
        errorStr.includes('UNAVAILABLE');

      if (isUnavailableOrRateLimited) {
        primaryModelCooldownUntil = Date.now() + 45000;
      }
    }
  }

  // Attempt 2: Fallback model (if not currently in rate-limit cooldown)
  if (Date.now() >= fallbackModelCooldownUntil) {
    try {
      const fallbackResult = await generator(FALLBACK_MODEL);
      setCache(cacheKey, fallbackResult);
      return fallbackResult;
    } catch (fallbackError: any) {
      const fallbackErrorStr = String(fallbackError?.message || fallbackError || '');
      const isFallbackUnavailable =
        fallbackErrorStr.includes('429') ||
        fallbackErrorStr.includes('RESOURCE_EXHAUSTED') ||
        fallbackErrorStr.includes('quota') ||
        fallbackErrorStr.includes('503') ||
        fallbackErrorStr.includes('high demand') ||
        fallbackErrorStr.includes('UNAVAILABLE');

      if (isFallbackUnavailable) {
        fallbackModelCooldownUntil = Date.now() + 45000;
      }
    }
  }

  // Attempt 3: Guaranteed deterministic trade generator (instant benchmark, 0 delay, 100% reliable)
  const benchmarkResult = fallbackGenerator();
  return benchmarkResult;
}

// Health check
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(apiKey),
    primaryModel: PRIMARY_MODEL,
    fallbackModel: FALLBACK_MODEL,
    cachedItems: requestCache.size,
    time: new Date().toISOString(),
  });
});

// 1. Analyze photos and estimate measurements
app.post('/api/gemini/analyze-photos', async (req: Request, res: Response) => {
  const { photos, jobType, description } = req.body || {};
  const cacheKey = `analyze_${jobType}_${(description || '').slice(0, 50)}_${(photos || []).length}`;

  const fallback = {
    fallback: true,
    observations: [
      `Visual inspection of ${jobType || 'attic'} space completed`,
      'Framing members inspected for depth, spacing, and clearances',
      'Checked attic access point and roof perimeter ventilation paths',
    ],
    hazards: [
      'Check for non-IC rated recessed fixtures before disturbing insulation',
      'Confirm bathroom exhaust ducts terminate to exterior cap',
    ],
    measurements: {
      squareFootage: 1250,
      existingDepthInches: 3.5,
      targetRValue: 49,
      accessPointCount: 1,
      ceilingHeightFeet: 6.5,
      confidence: 'medium',
    },
  };

  const result = await executeGeminiSafe(
    cacheKey,
    async (model) => {
      const imageParts = (photos || []).slice(0, 3).map((p: { dataUrl: string }) => {
        const match = p.dataUrl.match(/^data:(.+?);base64,(.+)$/);
        if (match) {
          return {
            inlineData: {
              mimeType: match[1],
              data: match[2],
            },
          };
        }
        return null;
      }).filter(Boolean);

      const prompt = `You are a veteran home-service estimating master with 25 years of experience in ${jobType}.
Analyze these site inspection photos and description: "${description || 'None provided'}".
Extract key observations, hazards or red flags, and estimate realistic physical dimensions/measurements.
Output strict JSON matching the schema.`;

      const contents: any = imageParts.length > 0 
        ? { parts: [...imageParts, { text: prompt }] }
        : prompt;

      const response = await ai!.models.generateContent({
        model,
        contents,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              observations: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              hazards: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              measurements: {
                type: Type.OBJECT,
                properties: {
                  squareFootage: { type: Type.NUMBER },
                  existingDepthInches: { type: Type.NUMBER },
                  targetRValue: { type: Type.NUMBER },
                  ceilingHeightFeet: { type: Type.NUMBER },
                  accessPointCount: { type: Type.NUMBER },
                  confidence: { type: Type.STRING },
                },
              },
            },
            required: ['observations', 'hazards', 'measurements'],
          },
        },
      });

      return JSON.parse(response.text || '{}');
    },
    () => fallback
  );

  res.status(200).json(result);
});

// 2. Dynamic Rapid Questions Generation
app.post('/api/gemini/generate-questions', async (req: Request, res: Response) => {
  const { jobType, subTypes, description, measurements, companyProfile } = req.body || {};
  const cacheKey = `questions_${jobType}_${(subTypes || []).join('-')}_${measurements?.squareFootage || 0}`;

  const isConversion = (jobType || '').toLowerCase().includes('conversion') || (jobType || '').toLowerCase().includes('remodel');

  const fallbackQuestions = isConversion
    ? [
        {
          id: 'q1',
          question: 'Are existing ceiling joists 2x6, 2x8, or engineered trusses?',
          options: ['2x8 or larger joists', '2x6 (needs sistering)', 'Engineered roof trusses'],
          reasonTag: 'structural_joist_capacity',
        },
        {
          id: 'q2',
          question: 'Is minimum 7ft ceiling height available over 50% of floor space?',
          options: ['Yes, ample headroom', 'Tight (dormer needed)', 'Unsure on site'],
          reasonTag: 'code_headroom_requirement',
        },
        {
          id: 'q3',
          question: 'Will project require a full bathroom addition?',
          options: ['Yes, full 3-piece bath', 'Half bath only', 'No bathroom, flex room only'],
          reasonTag: 'plumbing_roughin_scope',
        },
        {
          id: 'q4',
          question: 'Is there direct staircase access or pull-down ladder currently?',
          options: ['Full code staircase exists', 'Pull-down ladder (stair needed)', 'New stair rough-in'],
          reasonTag: 'staircase_construction',
        },
      ]
    : [
        {
          id: 'q1',
          question: 'Is existing insulation contaminated by pests, mold or water?',
          options: ['No, clean and dry', 'Yes, partial removal needed', 'Yes, full removal & sanitized'],
          reasonTag: 'insulation_removal_sanitizing',
        },
        {
          id: 'q2',
          question: 'Are there recessed can lights or flues requiring fire-rated covers?',
          options: ['None present', '1 to 5 fixtures', '6 or more fixtures'],
          reasonTag: 'baffles_and_covers',
        },
        {
          id: 'q3',
          question: 'How difficult is attic or work area access?',
          options: ['Easy walk-in / fold-down stair', 'Hallway scuttle hatch', 'Tight closet / high ceiling'],
          reasonTag: 'access_difficulty_surcharge',
        },
        {
          id: 'q4',
          question: 'Is comprehensive perimeter air sealing included?',
          options: ['Yes, top plates & penetrations', 'Basic bypasses only', 'None / unconditioned'],
          reasonTag: 'air_sealing_scope',
        },
      ];

  const result = await executeGeminiSafe(
    cacheKey,
    async (model) => {
      const prompt = `You are a veteran on-site contractor estimator for ${jobType} (${(subTypes || []).join(', ')}).
Description: "${description || ''}".
Measurements: ${JSON.stringify(measurements || {})}.
Company Trade: ${companyProfile?.primaryTrade || jobType}.

Generate 4 to 6 fast, highly specific multiple-choice questions for the contractor on-site.
Rules:
- Questions must clarify scope, safety risks, and material requirements.
- Under 10 words per option.
- Each question must include an internal reasonTag explaining how it impacts pricing or materials.
- Plain contractor language.`;

      const response = await ai!.models.generateContent({
        model,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              questions: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    question: { type: Type.STRING },
                    options: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING },
                    },
                    reasonTag: { type: Type.STRING },
                  },
                  required: ['id', 'question', 'options', 'reasonTag'],
                },
              },
            },
            required: ['questions'],
          },
        },
      });

      return JSON.parse(response.text || '{}');
    },
    () => ({ questions: fallbackQuestions, fallback: true })
  );

  res.status(200).json(result);
});

// 3. Propose Line Items, Labor & Scope (Combined for maximum efficiency & quota savings)
app.post('/api/gemini/propose-line-items', async (req: Request, res: Response) => {
  const { jobContext, companyProfile, pricingProfile, fewShotQuotes } = req.body || {};
  const sqFt = Number(jobContext?.measurements?.squareFootage) || 1200;
  const targetR = Number(jobContext?.measurements?.targetRValue) || 49;
  const jobType = jobContext?.jobType || 'Attic Insulation';

  const cacheKey = `lineitems_${jobType}_${sqFt}_${targetR}_${(jobContext?.subTypes || []).join('-')}`;

  const bagCount = Math.max(15, Math.round((sqFt * 1.1) / 38));
  const laborHours = Math.max(6, Math.round((sqFt / 350) * (companyProfile?.crewSize || 2) * 10) / 10);

  const fallbackData = {
    fallback: true,
    estimatedLaborHours: laborHours,
    lineItems: [
      {
        id: 'fb-mat-1',
        category: 'materials',
        name: `Blown-In Borate-Treated Cellulose (Target R-${targetR})`,
        description: `Premium loose-fill cellulose (${bagCount} bags covering ${sqFt} sq ft to R-${targetR})`,
        quantity: bagCount,
        unit: 'bags',
        unitCost: 19.5,
        markupPct: companyProfile?.materialMarkupPct || 25,
        reasoningTag: 'calculated_bag_coverage',
      },
      {
        id: 'fb-mat-2',
        category: 'materials',
        name: 'Polyurethane Air Seal & Fireblock Foam Kit',
        description: 'Complete sealing of interior top plates, wiring drops, and plumbing bypasses',
        quantity: 1,
        unit: 'lot',
        unitCost: 165.0,
        markupPct: 30,
        reasoningTag: 'air_barrier_standard',
      },
      {
        id: 'fb-mat-3',
        category: 'materials',
        name: 'Raft-R-Mate Attic Rafter Baffles (22"x48")',
        description: 'Preserves eave-to-ridge soffit intake ventilation channels',
        quantity: Math.max(16, Math.round(sqFt / 50)),
        unit: 'pieces',
        unitCost: 4.5,
        markupPct: 35,
        reasoningTag: 'soffit_ventilation',
      },
      {
        id: 'fb-mat-4',
        category: 'materials',
        name: 'Insulated Attic Hatch Cover Box (R-13)',
        description: 'Gasketed draft-stop thermal cover for access scuttle',
        quantity: 1,
        unit: 'ea',
        unitCost: 95.0,
        markupPct: 35,
        reasoningTag: 'access_weatherization',
      },
      {
        id: 'fb-lab-1',
        category: 'labor',
        name: 'Field Crew Installation Labor',
        description: `Preparation, tarps, air sealing, baffle installation & mechanical blow-in (${laborHours} crew-hours)`,
        quantity: laborHours,
        unit: 'hours',
        unitCost: companyProfile?.loadedHourlyRate || 58,
        markupPct: 0,
        reasoningTag: 'crew_productivity_rate',
      },
    ],
    flags: [
      {
        id: 'flag-canlights',
        type: 'info',
        title: 'Recessed Can Fixture Clearance',
        detail: 'Verify fixtures are IC-rated or install fire-rated covers to maintain safety gap.',
        resolved: false,
      },
      {
        id: 'flag-exhaust',
        type: 'info',
        title: 'Bathroom Fan Vent Termination',
        detail: 'Confirm bath fans vent through roof or soffit cap, not directly into attic air.',
        resolved: false,
      },
    ],
    scopeBullets: [
      'Protective drop cloths laid across all indoor travel corridors.',
      'Comprehensive polyurethane air sealing along accessible top plates and ceiling penetrations.',
      'Installation of rafter baffles at eaves to preserve continuous soffit ventilation.',
      `Blowing in borate-treated loose-fill insulation to achieve full R-${targetR} thermal resistance.`,
      'Installation of insulated draft-proof attic hatch cover and full vacuum cleanup of staging area.',
    ],
  };

  const result = await executeGeminiSafe(
    cacheKey,
    async (model) => {
      const prompt = `You are a veteran estimator with 25 years of experience in ${jobType}.
CONTEXT:
Job Type: ${jobType}
Subtypes: ${(jobContext?.subTypes || []).join(', ')}
Description: "${jobContext?.description || ''}"
Measurements: ${JSON.stringify(jobContext?.measurements || {})}
Questions & Answers: ${JSON.stringify(jobContext?.questions || [])}
Company Profile: ${JSON.stringify({
        primaryTrade: companyProfile?.primaryTrade,
        crewSize: companyProfile?.crewSize,
        laborModel: companyProfile?.laborModel,
        loadedHourlyRate: companyProfile?.loadedHourlyRate,
      })}
Past Contractor Style Examples: ${JSON.stringify((fewShotQuotes || []).slice(0, 2))}

IMPORTANT ARCHITECTURAL RULE:
Do NOT calculate final contract dollar totals.
Only propose structured line items with physical quantities, standard commercial units, estimated unit costs (derived from contractor style or standard market rates), and a brief reasoning tag for each item.
Also return any site flags, hazard warnings, and 4 to 6 customer-ready concise scope bullets in plain contractor language.
Output strict JSON matching the schema.`;

      const response = await ai!.models.generateContent({
        model,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              lineItems: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    category: {
                      type: Type.STRING,
                      description: 'materials, labor, equipment, permits, travel, or other',
                    },
                    name: { type: Type.STRING },
                    description: { type: Type.STRING },
                    quantity: { type: Type.NUMBER },
                    unit: { type: Type.STRING },
                    unitCost: { type: Type.NUMBER },
                    reasoningTag: { type: Type.STRING },
                  },
                  required: ['id', 'category', 'name', 'quantity', 'unit', 'unitCost'],
                },
              },
              estimatedLaborHours: { type: Type.NUMBER },
              flags: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    id: { type: Type.STRING },
                    type: { type: Type.STRING, description: 'warning, info, risk, or code' },
                    title: { type: Type.STRING },
                    detail: { type: Type.STRING },
                  },
                  required: ['id', 'type', 'title', 'detail'],
                },
              },
              scopeBullets: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ['lineItems', 'estimatedLaborHours', 'flags', 'scopeBullets'],
          },
        },
      });

      return JSON.parse(response.text || '{}');
    },
    () => fallbackData
  );

  res.status(200).json(result);
});

// 4. Build Customer-Facing Scope of Work
app.post('/api/gemini/build-scope', async (req: Request, res: Response) => {
  const { jobContext, companyProfile } = req.body || {};
  const cacheKey = `scope_${jobContext?.jobType}_${jobContext?.measurements?.squareFootage || 0}`;

  const fallbackScope = [
    'Protective drop cloths laid across all indoor travel corridors.',
    'Comprehensive polyurethane air sealing along accessible top plates and ceiling wire penetrations.',
    'Installation of ventilation baffles at eaves to preserve uninterrupted soffit airflow.',
    `Blowing in borate-treated loose-fill insulation to achieve full R-${jobContext?.measurements?.targetRValue || 49} thermal resistance.`,
    'Installation of insulated draft-proof attic hatch cover and complete HEPA vacuum cleanup of staging area.',
  ];

  const result = await executeGeminiSafe(
    cacheKey,
    async (model) => {
      const prompt = `You are a master estimator for "${companyProfile?.companyName || 'QuoteOnSite'}".
Write a concise, professional, customer-ready scope of work for:
Job: ${jobContext?.jobType} (${(jobContext?.subTypes || []).join(', ')})
Description: "${jobContext?.description || ''}"
Measurements: ${JSON.stringify(jobContext?.measurements || {})}

Rules:
- 4 to 6 clear, confidence-inspiring bullet points in plain customer language.
- Mention prep, air sealing/ventilation, primary installation, and cleanup.
- Max 18 words per bullet. No technical jargon.`;

      const response = await ai!.models.generateContent({
        model,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              scopeBullets: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: ['scopeBullets'],
          },
        },
      });

      return JSON.parse(response.text || '{}');
    },
    () => ({ scopeBullets: fallbackScope, fallback: true })
  );

  res.status(200).json(result);
});

// 5. Extract Structured Quote from Past Quote Document / Image
app.post('/api/gemini/extract-quote', async (req: Request, res: Response) => {
  const { fileDataUrl, fileText, fileName } = req.body || {};
  const cacheKey = `extract_${fileName || 'doc'}_${(fileText || '').slice(0, 50)}`;

  const fallbackExtracted = {
    extracted: {
      title: fileName ? fileName.replace(/\.[^/.]+$/, '') : 'Past Attic Quote',
      jobType: 'Attic Insulation',
      customerName: 'Sample Homeowner',
      totalAmount: 4650,
      sqFt: 1350,
      scopeNotes: 'Air sealing top plates, baffles, and blown-in cellulose R-49 with hatch box',
      lineItems: [
        {
          id: 'ext-1',
          category: 'materials',
          name: 'Blown-In Cellulose R-49',
          quantity: 42,
          unit: 'bags',
          unitCost: 19.0,
          total: 798,
        },
        {
          id: 'ext-2',
          category: 'materials',
          name: 'Perimeter Air Sealing Lot',
          quantity: 1,
          unit: 'lot',
          unitCost: 220,
          total: 220,
        },
        {
          id: 'ext-3',
          category: 'labor',
          name: 'Crew Labor & Blow In',
          quantity: 14,
          unit: 'hours',
          unitCost: 65,
          total: 910,
        },
      ],
    },
    fallback: true,
  };

  const result = await executeGeminiSafe(
    cacheKey,
    async (model) => {
      let contents: any;
      if (fileDataUrl && fileDataUrl.startsWith('data:')) {
        const match = fileDataUrl.match(/^data:(.+?);base64,(.+)$/);
        if (match) {
          contents = {
            parts: [
              {
                inlineData: {
                  mimeType: match[1],
                  data: match[2],
                },
              },
              {
                text: `Extract this past contractor quote or invoice into structured data.
Identify the job type, customer name, total dollar amount, square footage or primary measurement, scope summary, and itemized line items.
Output strict JSON matching the schema.`,
              },
            ],
          };
        }
      } else {
        contents = `Extract this past contractor quote text into structured data:
Filename: ${fileName}
Content:
${fileText || 'Past invoice for attic insulation'}

Identify the job type, customer name, total dollar amount, square footage, scope summary, and itemized line items.
Output strict JSON matching the schema.`;
      }

      const response = await ai!.models.generateContent({
        model,
        contents,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              extracted: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  jobType: { type: Type.STRING },
                  customerName: { type: Type.STRING },
                  totalAmount: { type: Type.NUMBER },
                  sqFt: { type: Type.NUMBER },
                  scopeNotes: { type: Type.STRING },
                  lineItems: {
                    type: Type.ARRAY,
                    items: {
                      type: Type.OBJECT,
                      properties: {
                        id: { type: Type.STRING },
                        category: { type: Type.STRING },
                        name: { type: Type.STRING },
                        quantity: { type: Type.NUMBER },
                        unit: { type: Type.STRING },
                        unitCost: { type: Type.NUMBER },
                        total: { type: Type.NUMBER },
                      },
                      required: ['name', 'quantity', 'unitCost', 'total'],
                    },
                  },
                },
                required: ['jobType', 'totalAmount'],
              },
            },
            required: ['extracted'],
          },
        },
      });

      return JSON.parse(response.text || '{}');
    },
    () => fallbackExtracted
  );

  res.status(200).json(result);
});

// OAuth 2.0 popup callback handler for Google Sign-In
app.get('/auth/callback', (_req: Request, res: Response) => {
  res.send(`<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Google Sign-In Complete</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      background: #0B0D12;
      color: #FFFFFF;
      text-align: center;
    }
    .card {
      padding: 32px;
      border-radius: 20px;
      background: #14171F;
      border: 1px solid rgba(255, 255, 255, 0.1);
      box-shadow: 0 20px 40px rgba(0,0,0,0.5);
      max-width: 360px;
    }
    .spinner {
      width: 36px;
      height: 36px;
      border: 3px solid rgba(255,255,255,0.1);
      border-top-color: #5B6CFF;
      border-radius: 50%;
      animation: spin 1s linear infinite;
      margin: 0 auto 16px;
    }
    @keyframes spin { to { transform: rotate(360deg); } }
    h2 { font-size: 18px; margin: 0 0 8px; }
    p { font-size: 13px; color: #9CA3AF; margin: 0; }
  </style>
</head>
<body>
  <div class="card">
    <div class="spinner"></div>
    <h2>Authenticating...</h2>
    <p>Signing in to ShownLeads. This window will close automatically.</p>
  </div>
  <script>
    (function() {
      try {
        const urlParams = new URLSearchParams(window.location.search);
        const hashParams = new URLSearchParams(window.location.hash.substring(1));

        const code = urlParams.get('code') || hashParams.get('code');
        const token = hashParams.get('access_token') || urlParams.get('access_token');
        const idToken = hashParams.get('id_token') || urlParams.get('id_token');
        const error = urlParams.get('error') || hashParams.get('error');
        const errorDescription = urlParams.get('error_description') || hashParams.get('error_description');

        const payload = {
          type: 'GOOGLE_AUTH_SUCCESS',
          code: code || undefined,
          token: token || undefined,
          access_token: token || undefined,
          id_token: idToken || undefined,
          error: error || undefined,
          error_description: errorDescription || undefined
        };

        if (window.opener) {
          window.opener.postMessage(payload, window.location.origin);
          setTimeout(function() {
            window.close();
          }, 300);
        } else {
          document.querySelector('h2').textContent = 'Sign-In Complete';
          document.querySelector('p').innerHTML = 'You can now close this tab and return to ShownLeads.';
        }
      } catch (e) {
        console.error('Callback error', e);
      }
    })();
  </script>
</body>
</html>`);
});

// Mount Vite or serve static assets in production

async function startServer() {
  const server = http.createServer(app);

  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : { server },
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  server.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`QuoteOnSite server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
