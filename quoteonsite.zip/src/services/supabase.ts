import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Estimate, SupabaseConfig } from '../types';

let cachedClient: SupabaseClient | null = null;
let lastClientKey = '';

export function getSupabaseClient(config?: SupabaseConfig): SupabaseClient | null {
  const url = config?.url?.trim();
  const anonKey = config?.anonKey?.trim();

  if (!url || !anonKey) {
    return null;
  }

  const keyPair = `${url}::${anonKey}`;
  if (cachedClient && lastClientKey === keyPair) {
    return cachedClient;
  }

  try {
    cachedClient = createClient(url, anonKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });
    lastClientKey = keyPair;
    return cachedClient;
  } catch (err) {
    console.error('Failed to create Supabase client:', err);
    return null;
  }
}

export async function testSupabaseConnection(config: SupabaseConfig): Promise<{
  success: boolean;
  message: string;
  details?: any;
}> {
  const url = config.url?.trim();
  const anonKey = config.anonKey?.trim();
  const tableName = config.tableName?.trim() || 'estimates';

  if (!url) {
    return { success: false, message: 'Please provide your Supabase Project URL.' };
  }
  if (!anonKey) {
    return { success: false, message: 'Please provide your Supabase Public Anon Key.' };
  }

  if (!url.startsWith('https://') && !url.startsWith('http://')) {
    return { success: false, message: 'Project URL must begin with https:// (e.g. https://your-id.supabase.co)' };
  }

  try {
    const client = getSupabaseClient(config);
    if (!client) {
      return { success: false, message: 'Failed to initialize Supabase client with provided credentials.' };
    }

    // Ping the specified table or query table info
    const { data, error } = await client
      .from(tableName)
      .select('id')
      .limit(1);

    if (error) {
      // Check if table does not exist
      if (error.code === '42P01' || error.message?.includes('relation') || error.message?.includes('does not exist')) {
        return {
          success: true,
          message: `Connected to Supabase! Note: table "${tableName}" does not exist yet. Run the SQL snippet below in your Supabase SQL Editor.`,
          details: { tableMissing: true },
        };
      }
      return {
        success: false,
        message: `Supabase returned error: ${error.message} (code: ${error.code || 'unknown'})`,
      };
    }

    return {
      success: true,
      message: `Successfully connected to Supabase! Table "${tableName}" is reachable and active.`,
      details: { rowCountSample: data?.length || 0 },
    };
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Connection test failed. Check network or CORS policies.',
    };
  }
}

export async function syncEstimateToSupabase(
  estimate: Estimate,
  config: SupabaseConfig
): Promise<{ success: boolean; error?: string }> {
  const client = getSupabaseClient(config);
  if (!client) {
    return { success: false, error: 'Supabase client is not configured' };
  }

  const tableName = config.tableName?.trim() || 'estimates';

  const row = {
    id: estimate.id,
    estimate_number: estimate.estimateNumber,
    customer_name: estimate.customer?.name || null,
    customer_phone: estimate.customer?.phone || null,
    customer_email: estimate.customer?.email || null,
    customer_address: estimate.customer?.address || null,
    job_type: estimate.jobType || null,
    status: estimate.status || 'draft',
    sold_price: estimate.soldPrice || null,
    selected_tier: estimate.selectedTier || 'better',
    total_exact: estimate.costBreakdown?.totalExact || 0,
    range_low: estimate.costBreakdown?.rangeLow || 0,
    range_high: estimate.costBreakdown?.rangeHigh || 0,
    square_footage: estimate.measurements?.squareFootage || null,
    line_items: estimate.lineItems || [],
    cost_breakdown: estimate.costBreakdown || {},
    scope_bullets: estimate.scopeBullets || [],
    signature: estimate.signature || null,
    flags: estimate.flags || [],
    created_at: estimate.createdAt,
    updated_at: new Date().toISOString(),
  };

  try {
    const { error } = await client.from(tableName).upsert(row, { onConflict: 'id' });
    if (error) {
      return { success: false, error: error.message };
    }
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message || 'Upsert failed' };
  }
}

export async function syncAllEstimatesToSupabase(
  estimates: Estimate[],
  config: SupabaseConfig
): Promise<{ success: boolean; count: number; error?: string }> {
  const client = getSupabaseClient(config);
  if (!client) {
    return { success: false, count: 0, error: 'Supabase client not configured' };
  }

  const tableName = config.tableName?.trim() || 'estimates';
  const rows = estimates.map((estimate) => ({
    id: estimate.id,
    estimate_number: estimate.estimateNumber,
    customer_name: estimate.customer?.name || null,
    customer_phone: estimate.customer?.phone || null,
    customer_email: estimate.customer?.email || null,
    customer_address: estimate.customer?.address || null,
    job_type: estimate.jobType || null,
    status: estimate.status || 'draft',
    sold_price: estimate.soldPrice || null,
    selected_tier: estimate.selectedTier || 'better',
    total_exact: estimate.costBreakdown?.totalExact || 0,
    range_low: estimate.costBreakdown?.rangeLow || 0,
    range_high: estimate.costBreakdown?.rangeHigh || 0,
    square_footage: estimate.measurements?.squareFootage || null,
    line_items: estimate.lineItems || [],
    cost_breakdown: estimate.costBreakdown || {},
    scope_bullets: estimate.scopeBullets || [],
    signature: estimate.signature || null,
    flags: estimate.flags || [],
    created_at: estimate.createdAt,
    updated_at: estimate.updatedAt || new Date().toISOString(),
  }));

  try {
    const { error } = await client.from(tableName).upsert(rows, { onConflict: 'id' });
    if (error) {
      return { success: false, count: 0, error: error.message };
    }
    return { success: true, count: rows.length };
  } catch (err: any) {
    return { success: false, count: 0, error: err.message || 'Batch upsert failed' };
  }
}

export async function fetchEstimatesFromSupabase(
  config: SupabaseConfig
): Promise<{ success: boolean; estimates?: Estimate[]; error?: string }> {
  const client = getSupabaseClient(config);
  if (!client) {
    return { success: false, error: 'Supabase client not configured' };
  }

  const tableName = config.tableName?.trim() || 'estimates';

  try {
    const { data, error } = await client
      .from(tableName)
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      return { success: false, error: error.message };
    }

    const estimates: Estimate[] = (data || []).map((row: any) => ({
      id: row.id,
      estimateNumber: row.estimate_number || 'EST-000',
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      status: row.status || 'draft',
      soldPrice: row.sold_price,
      selectedTier: row.selected_tier || 'better',
      customer: {
        name: row.customer_name || 'Homeowner',
        phone: row.customer_phone || '',
        email: row.customer_email || '',
        address: row.customer_address || '',
      },
      jobType: row.job_type || 'Custom Scope',
      subTypes: [],
      photos: [],
      description: '',
      measurements: {
        squareFootage: row.square_footage || 1000,
      },
      measurementConfirmed: { squareFootage: true },
      measurementAiSuggested: {},
      questions: [],
      flags: row.flags || [],
      lineItems: row.line_items || [],
      costBreakdown: row.cost_breakdown || {
        materialsBase: 0,
        materialsMarkedUp: 0,
        laborCost: 0,
        laborHours: 0,
        crewDays: 0,
        travelCost: 0,
        equipmentCost: 0,
        permitsCost: 0,
        subtotalCosts: 0,
        overheadAmount: 0,
        profitAmount: 0,
        contingencyAmount: 0,
        preTaxTotal: 0,
        taxAmount: 0,
        totalExact: row.total_exact || 0,
        rangeLow: row.range_low || 0,
        rangeHigh: row.range_high || 0,
        confidence: 'high',
        confidenceScore: 90,
        confidenceReasons: [],
        appliedRules: [],
      },
      scopeBullets: row.scope_bullets || [],
      signature: row.signature,
      viewMode: 'contractor',
      priceDisplayMode: 'exact',
      spotDiscountApplied: false,
      validDays: 14,
    }));

    return { success: true, estimates };
  } catch (err: any) {
    return { success: false, error: err.message || 'Fetch failed' };
  }
}

export function getSupabaseSqlSetup(tableName: string = 'estimates'): string {
  return `-- ShownLeads Instant Estimator — Supabase Schema
-- Run this script in your Supabase SQL Editor:

create table if not exists public.${tableName} (
  id text primary key,
  estimate_number text not null,
  customer_name text,
  customer_phone text,
  customer_email text,
  customer_address text,
  job_type text,
  status text default 'draft',
  sold_price numeric,
  selected_tier text default 'better',
  total_exact numeric,
  range_low numeric,
  range_high numeric,
  square_footage numeric,
  line_items jsonb default '[]'::jsonb,
  cost_breakdown jsonb default '{}'::jsonb,
  scope_bullets jsonb default '[]'::jsonb,
  signature jsonb,
  flags jsonb default '[]'::jsonb,
  created_at timestamp with time zone default timezone('utc'::text, now()),
  updated_at timestamp with time zone default timezone('utc'::text, now())
);

-- Enable Row Level Security (RLS)
alter table public.${tableName} enable row level security;

-- Create policy to allow read/write with your anon API key
create policy "Allow anon access for estimates"
  on public.${tableName}
  for all
  using (true)
  with check (true);
`;
}
