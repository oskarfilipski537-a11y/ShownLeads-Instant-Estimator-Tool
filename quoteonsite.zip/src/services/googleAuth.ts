import { GoogleAuthConfig } from '../types';

/**
 * Parses payload from a JWT token (e.g. Google id_token)
 */
export function parseJwtPayload(token: string): any {
  try {
    const base64Url = token.split('.')[1];
    if (!base64Url) return null;
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
      window
        .atob(base64)
        .split('')
        .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
        .join('')
    );
    return JSON.parse(jsonPayload);
  } catch (err) {
    console.error('Failed to parse JWT payload', err);
    return null;
  }
}

/**
 * Returns the current window origin to register as Authorized JavaScript Origin in Google Cloud Console
 */
export function getAuthorizedOrigin(): string {
  if (typeof window !== 'undefined' && window.location) {
    return window.location.origin;
  }
  return 'https://ais-dev-etr765ce6yrvxbmfpqnfqo-86360367697.europe-west1.run.app';
}

/**
 * Returns the authorized redirect URI to register in Google Cloud Console
 */
export function getAuthorizedRedirectUri(): string {
  return `${getAuthorizedOrigin()}/auth/callback`;
}

export interface GoogleAuthResult {
  success: boolean;
  email?: string;
  name?: string;
  avatar?: string;
  idToken?: string;
  accessToken?: string;
  error?: string;
}

/**
 * Launches Google OAuth Popup for user sign in
 */
export function launchGoogleOAuthPopup(clientId: string): Promise<GoogleAuthResult> {
  return new Promise((resolve) => {
    if (!clientId || clientId.trim() === '') {
      resolve({
        success: false,
        error: 'Please paste your Google OAuth Client ID first.',
      });
      return;
    }

    const cleanClientId = clientId.trim();
    const redirectUri = getAuthorizedRedirectUri();
    const state = Math.random().toString(36).substring(2, 15);
    const nonce = Math.random().toString(36).substring(2, 15);

    // Google OAuth 2.0 endpoint requesting ID token & user profile
    const authUrl =
      `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${encodeURIComponent(cleanClientId)}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&response_type=token%20id_token` +
      `&scope=${encodeURIComponent('openid email profile')}` +
      `&state=${encodeURIComponent(state)}` +
      `&nonce=${encodeURIComponent(nonce)}` +
      `&prompt=select_account`;

    const width = 540;
    const height = 660;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;

    const popup = window.open(
      authUrl,
      'google_oauth_popup',
      `width=${width},height=${height},left=${left},top=${top},toolbar=no,menubar=no,location=yes,status=no`
    );

    if (!popup) {
      resolve({
        success: false,
        error: 'Popup was blocked by your browser. Please allow popups for this site.',
      });
      return;
    }

    let resolved = false;

    // Listen for postMessage from the popup callback
    const handleMessage = (event: MessageEvent) => {
      // Allow messages from this origin
      if (event.origin !== window.location.origin) return;

      const data = event.data;
      if (data && (data.type === 'GOOGLE_AUTH_SUCCESS' || data.type === 'OAUTH_RESPONSE')) {
        resolved = true;
        window.removeEventListener('message', handleMessage);
        clearInterval(popupChecker);

        if (data.error) {
          resolve({
            success: false,
            error: data.error_description || data.error,
          });
          return;
        }

        const idToken = data.id_token || data.idToken;
        const accessToken = data.access_token || data.token;
        let email = data.email;
        let name = data.name;
        let avatar = data.avatar;

        if (idToken) {
          const payload = parseJwtPayload(idToken);
          if (payload) {
            email = payload.email || email;
            name = payload.name || name;
            avatar = payload.picture || avatar;
          }
        }

        resolve({
          success: true,
          email: email || 'contractor@gmail.com',
          name: name || 'Google Contractor User',
          avatar,
          idToken,
          accessToken,
        });
      }
    };

    window.addEventListener('message', handleMessage);

    // Periodically check if user closed popup without completing
    const popupChecker = setInterval(() => {
      if (popup.closed) {
        clearInterval(popupChecker);
        window.removeEventListener('message', handleMessage);
        if (!resolved) {
          // Check if maybe hash or token was saved locally
          resolve({
            success: false,
            error: 'Sign-in window closed before authentication was completed.',
          });
        }
      }
    }, 1000);

    // Timeout safety after 3 minutes
    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        clearInterval(popupChecker);
        window.removeEventListener('message', handleMessage);
        resolve({
          success: false,
          error: 'Sign-in timed out. Please check your Authorized Redirect URIs in Google Cloud Console.',
        });
      }
    }, 180000);
  });
}
