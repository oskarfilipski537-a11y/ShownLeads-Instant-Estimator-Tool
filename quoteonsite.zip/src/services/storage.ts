import {
  AppSettings,
  CompanyProfile,
  Estimate,
  PastQuote,
  PriceListItem,
  PricingProfile,
  PricingRule,
} from '../types';
import { TRADES } from '../data/tradeKnowledge';
import { syncEstimateToSupabase } from './supabase';

const STORAGE_KEYS = {
  PROFILE: 'quoteonsite_company_profile_v1',
  ESTIMATES: 'quoteonsite_estimates_v1',
  PRICING_PROFILE: 'quoteonsite_pricing_profile_v1',
  PRICE_LIST: 'quoteonsite_price_list_v1',
  RULES: 'quoteonsite_pricing_rules_v1',
  SETTINGS: 'quoteonsite_settings_v1',
};

export const DEFAULT_COMPANY_PROFILE: CompanyProfile = {
  companyName: 'Apex Contractors',
  logoUrl: '',
  primaryTrade: 'Kitchen & Bath Remodel',
  otherTrades: ['Attic Conversion / Remodel', 'Attic Insulation'],
  location: {
    city: 'Denver',
    state: 'CO',
    country: 'USA',
    zip: '80202',
    lat: 39.7392,
    lng: -104.9903,
  },
  serviceRadius: 45,
  radiusUnit: 'miles',
  companyType: 'Small crew (2-5)',
  crewSize: 2,
  crewsRunning: 2,
  avgJobValue: 4200,
  targetMargin: 35,
  overheadPct: 15,
  laborModel: 'hourly',
  loadedHourlyRate: 58,
  billableHourlyRate: 95,
  travelPricing: {
    type: 'free',
    flatFee: 75,
    perMileRate: 2.5,
    freeRadiusMiles: 30,
  },
  materialMarkupPct: 25,
  quoteStyle: 'options', // Good / Better / Best default
  chargeAddons: {
    permits: { enabled: false, amount: 150 },
    dumpster: { enabled: false, amount: 450 },
    equipmentRental: { enabled: false, amount: 125 },
    mobilizationFee: { enabled: false, amount: 95 },
  },
  taxRatePct: 7.75,
  paymentTerms: '50% deposit, 50% on completion',
  warranty: '10-Year Craftsmanship & Thermal Performance Guarantee',
  spotDiscount: {
    enabled: true,
    amount: 250,
    label: 'On-The-Spot Decision Courtesy Credit',
  },
  termsAndConditions: 'Work performed according to BPI standards. 14-day price lock.',
  customerDisclaimer: 'Estimate based on on-site inspection. Final price confirmed upon full access verification.',
  isOnboarded: false,
};

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'dark',
  units: 'imperial',
  currency: 'USD',
  currencySymbol: '$',
  defaultValidityDays: 14,
  showLineItemsToCustomer: true,
  allowRangeToCustomer: true,
  userEmail: 'oskarfipsku@gmail.com',
  isAuthenticated: true,
  supabase: {
    url: '',
    anonKey: '',
    tableName: 'estimates',
    isConnected: false,
    autoSync: true,
  },
  googleAuth: {
    clientId: '148971107659-nk933e494c5rm4pahl9ji592jmtgguho.apps.googleusercontent.com',
    clientSecret: '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',
    isConnected: true,
    userEmail: 'oskarfipsku@gmail.com',
    userName: 'Oskar',
  },
};

export const DEMO_PAST_QUOTES: PastQuote[] = [
  {
    id: 'demo-pq-1',
    title: '1840 Elm St - R-49 Blown Cellulose',
    fileName: '1840_Elm_Invoice.pdf',
    date: '2026-09-14',
    jobType: 'Attic Insulation',
    customerName: 'Marcus Vance',
    totalAmount: 4450,
    sqFt: 1350,
    scopeNotes: 'Air sealing top plates, 22 baffles, R-49 cellulose blow-in, hatch box',
    lineItems: [],
    confirmed: true,
  },
  {
    id: 'demo-pq-2',
    title: '742 Ridge Way - Vac Removal & R-49',
    fileName: '742_Ridge_Quote.pdf',
    date: '2026-09-28',
    jobType: 'Attic Insulation',
    customerName: 'Elena Rostova',
    totalAmount: 6200,
    sqFt: 1500,
    scopeNotes: 'Full rodent vac removal, enzyme sanitizer fogging, air seal, R-49 cellulose',
    lineItems: [],
    confirmed: true,
  },
  {
    id: 'demo-pq-3',
    title: '512 Pinecrest Dr - Blown Fiberglass Top-Up',
    fileName: '512_Pinecrest.pdf',
    date: '2026-10-08',
    jobType: 'Attic Insulation',
    customerName: 'David Chen',
    totalAmount: 3200,
    sqFt: 1100,
    scopeNotes: 'R-38 fiberglass top up, 18 baffles, hatch weatherstripping',
    lineItems: [],
    confirmed: true,
  },
];

export const DEMO_ESTIMATES: Estimate[] = [
  {
    id: 'est-demo-1',
    estimateNumber: 'QOS-1048',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    status: 'sent',
    customer: {
      name: 'Sarah & Tom Jenkins',
      phone: '(303) 555-0192',
      email: 'sjenkins@gmail.com',
      address: '4820 Evergreen Ter, Denver, CO 80211',
      oneWayMiles: 14,
    },
    jobType: 'Attic Insulation',
    subTypes: ['Blown-in cellulose', 'Perimeter air sealing', 'Baffles & ventilation chutes'],
    photos: [
      {
        id: 'p1',
        dataUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=600&auto=format&fit=crop&q=80',
        shotType: 'overview',
        caption: 'Existing blown cellulose compacted down to ~3.5 inches',
        timestamp: Date.now() - 3600000 * 4,
      },
      {
        id: 'p2',
        dataUrl: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&auto=format&fit=crop&q=80',
        shotType: 'depth',
        caption: 'Access hatch scuttle requires weatherstrip border',
        timestamp: Date.now() - 3600000 * 4,
      },
    ],
    description: 'Drafty 1974 ranch home. High winter gas bills. Cold ceiling spots in master bedroom.',
    measurements: {
      squareFootage: 1380,
      existingDepthInches: 3.5,
      targetRValue: 49,
      ceilingHeightFeet: 6.8,
      accessPointCount: 1,
      storyCount: 1,
    },
    measurementConfirmed: {
      squareFootage: true,
      existingDepthInches: true,
      targetRValue: true,
      ceilingHeightFeet: true,
    },
    measurementAiSuggested: {},
    questions: [
      {
        id: 'q-contam',
        question: 'Is existing insulation contaminated by pests, mold or water?',
        options: ['No, clean and dry', 'Yes, partial removal needed', 'Yes, full removal & sanitized'],
        answer: 'No, clean and dry',
        reasonTag: 'insulation_removal_sanitizing',
      },
      {
        id: 'q-lights',
        question: 'Are there recessed can lights or flues requiring fire-rated covers?',
        options: ['None present', '1 to 5 fixtures', '6 or more fixtures'],
        answer: '1 to 5 fixtures',
        reasonTag: 'baffles_and_covers',
      },
    ],
    flags: [
      {
        id: 'f-1',
        type: 'info',
        title: '4 Can Lights Identified',
        detail: 'Tenmat fire-rated covers included in materials to maintain non-combustible clearance.',
        resolved: true,
        resolveActionLabel: 'Covers Added',
      },
    ],
    lineItems: [
      {
        id: 'li-1',
        category: 'materials',
        name: 'Blown-In Borate-Treated Cellulose (R-49 Target)',
        description: 'Premium pest-inhibiting loose-fill cellulose insulation',
        quantity: 42,
        unit: 'bags',
        unitCost: 18.5,
        markupPct: 25,
        total: 971.25,
      },
      {
        id: 'li-2',
        category: 'materials',
        name: 'Polyurethane Air Seal & Fireblock Foam Kit',
        description: 'Complete sealing of interior top plates & wire chases',
        quantity: 1,
        unit: 'kit',
        unitCost: 145.0,
        markupPct: 30,
        total: 188.5,
      },
      {
        id: 'li-3',
        category: 'materials',
        name: 'Rafter-Vent Soffit Baffles (22"x48")',
        description: 'Preserves eave-to-ridge passive intake ventilation',
        quantity: 26,
        unit: 'pieces',
        unitCost: 4.25,
        markupPct: 35,
        total: 149.18,
      },
      {
        id: 'li-4',
        category: 'materials',
        name: 'Fire-Rated Recessed Can Light Covers',
        description: 'Tenmat mineral-wool covers for non-IC can fixtures',
        quantity: 4,
        unit: 'ea',
        unitCost: 24.5,
        markupPct: 35,
        total: 132.3,
      },
      {
        id: 'li-5',
        category: 'materials',
        name: 'Insulated Attic Access Hatch Cover Box (R-13)',
        description: 'Gasketed draft-stop thermal cover for scuttle entrance',
        quantity: 1,
        unit: 'ea',
        unitCost: 85.0,
        markupPct: 40,
        total: 119.0,
      },
      {
        id: 'li-6',
        category: 'labor',
        name: 'Installation Field Crew Labor (2 Techs)',
        description: 'Path prep, full air seal, baffle stapling, mechanical blow-in & cleanup',
        quantity: 11,
        unit: 'hours',
        unitCost: 58.0,
        markupPct: 0,
        total: 638.0,
      },
    ],
    costBreakdown: {
      materialsBase: 1248.5,
      materialsMarkedUp: 1560.23,
      laborCost: 638.0,
      laborHours: 11,
      crewDays: 0.7,
      travelCost: 0,
      equipmentCost: 0,
      permitsCost: 0,
      subtotalCosts: 2198.23,
      overheadAmount: 329.73,
      profitAmount: 1361.21,
      contingencyAmount: 194.46,
      preTaxTotal: 4083.63,
      taxAmount: 120.92,
      totalExact: 4204.55,
      rangeLow: 3995,
      rangeHigh: 4415,
      confidence: 'high',
      confidenceScore: 94,
      confidenceReasons: ['All measurements verified on site with clear attic overview photos.'],
      appliedRules: [],
    },
    scopeBullets: [
      'Protective drop cloths laid across all indoor travel corridors.',
      'Comprehensive polyurethane air sealing along all accessible top plates and ceiling wire penetrations.',
      'Installation of 26 Raft-R-Mate ventilation baffles at eaves to preserve uninterrupted soffit airflow.',
      'Fire-rated safety covers installed over 4 recessed light fixtures.',
      'Blowing in borate-treated loose-fill cellulose to achieve full R-49 thermal resistance (~14 inches depth).',
      'Installation of insulated R-13 attic access seal and thorough HEPA vacuum cleanup of work areas.',
    ],
    goodBetterBest: {
      good: {
        name: 'Standard R-38 Upgrade',
        badge: 'Essential',
        subtitle: 'Code-compliant reliable thermal protection',
        total: 3575,
        scopeSummary: [
          'Top up existing insulation with loose-fill cellulose to R-38.',
          'Basic weatherstripping at access scuttle.',
          'Pre- and post-installation digital site inspection.',
        ],
        specHighlights: ['R-38 Thermal Spec', 'Standard Air Seal', '5-Year Warranty'],
        lineItems: [],
        breakdown: {} as any,
        isPopular: false,
      },
      better: {
        name: 'High-Performance R-49 Air Seal',
        badge: 'Most Popular',
        subtitle: 'Maximum utility savings and drafts elimination',
        total: 4200,
        scopeSummary: [
          'Full polyurethane foam air sealing of attic bypasses.',
          'High-density R-49 borate-treated loose fill.',
          'Rafter baffles to protect continuous soffit airflow.',
          'Insulated draft-proof attic hatch cover box.',
        ],
        specHighlights: ['R-49 High-Density', 'Comprehensive Air Seal', '10-Year Warranty', 'IRA Rebate Eligible'],
        lineItems: [],
        breakdown: {} as any,
        isPopular: true,
      },
      best: {
        name: 'Complete Sanitization & R-60 Thermal Shield',
        badge: 'Ultimate Protection',
        subtitle: 'Full old insulation extraction, antimicrobial fogging & R-60 shield',
        total: 6930,
        scopeSummary: [
          'Complete HEPA vacuum extraction of contaminated old insulation.',
          'Enzyme sanitizing and antimicrobial misting.',
          'Precision 2-component foam air seal along all plates.',
          'R-60 premium thermal boundary for lifetime comfort.',
        ],
        specHighlights: ['R-60 Extreme Efficiency', 'Full Extraction & Sanitize', 'Lifetime Craftsmanship Guarantee'],
        lineItems: [],
        breakdown: {} as any,
        isPopular: false,
      },
    },
    selectedTier: 'better',
    viewMode: 'customer',
    priceDisplayMode: 'exact',
    spotDiscountApplied: true,
    validDays: 14,
  },
  {
    id: 'est-demo-2',
    estimateNumber: 'QOS-1047',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 86400000).toISOString(),
    status: 'won',
    soldPrice: 5100,
    customer: {
      name: 'Robert Miller',
      phone: '(720) 555-8391',
      email: 'rmiller.co@outlook.com',
      address: '1129 W 32nd Ave, Denver, CO 80211',
      oneWayMiles: 8,
    },
    jobType: 'Attic Insulation',
    subTypes: ['Blown-in cellulose', 'Insulation removal & vac', 'Rodent proofing & sanitizing'],
    photos: [],
    description: 'Past rodent contamination in north corner. Full extraction and botanical treatment required.',
    measurements: { squareFootage: 1250, targetRValue: 49 },
    measurementConfirmed: { squareFootage: true },
    measurementAiSuggested: {},
    questions: [],
    flags: [],
    lineItems: [],
    costBreakdown: {
      materialsBase: 1350,
      materialsMarkedUp: 1687,
      laborCost: 1100,
      laborHours: 19,
      crewDays: 1.2,
      travelCost: 0,
      equipmentCost: 200,
      permitsCost: 0,
      subtotalCosts: 2987,
      overheadAmount: 448,
      profitAmount: 1480,
      contingencyAmount: 220,
      preTaxTotal: 5135,
      taxAmount: 130,
      totalExact: 5265,
      rangeLow: 5000,
      rangeHigh: 5500,
      confidence: 'high',
      confidenceScore: 90,
      confidenceReasons: [],
      appliedRules: [],
    },
    scopeBullets: [
      'Full HEPA extraction of old degraded fiberglass.',
      'Enzyme botanical fogging of attic floor.',
      'Full air seal and R-49 blown cellulose application.',
    ],
    viewMode: 'contractor',
    priceDisplayMode: 'exact',
    spotDiscountApplied: false,
    validDays: 14,
  },
];

export const StorageService = {
  getCompanyProfile(): CompanyProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return data ? JSON.parse(data) : DEFAULT_COMPANY_PROFILE;
    } catch {
      return DEFAULT_COMPANY_PROFILE;
    }
  },

  saveCompanyProfile(profile: CompanyProfile): void {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  },

  getEstimates(): Estimate[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ESTIMATES);
      return data ? JSON.parse(data) : DEMO_ESTIMATES;
    } catch {
      return DEMO_ESTIMATES;
    }
  },

  saveEstimate(estimate: Estimate): void {
    const list = this.getEstimates();
    const idx = list.findIndex((e) => e.id === estimate.id);
    if (idx >= 0) {
      list[idx] = { ...estimate, updatedAt: new Date().toISOString() };
    } else {
      list.unshift(estimate);
    }
    localStorage.setItem(STORAGE_KEYS.ESTIMATES, JSON.stringify(list));

    // Background sync to Supabase if connected
    try {
      const settings = this.getSettings();
      if (settings.supabase?.isConnected && settings.supabase?.autoSync && settings.supabase?.url && settings.supabase?.anonKey) {
        syncEstimateToSupabase(estimate, settings.supabase).catch((err) => {
          console.warn('Background Supabase sync warning:', err);
        });
      }
    } catch {}
  },

  deleteEstimate(id: string): void {
    const list = this.getEstimates().filter((e) => e.id !== id);
    localStorage.setItem(STORAGE_KEYS.ESTIMATES, JSON.stringify(list));
  },

  markEstimateOutcome(id: string, status: 'won' | 'lost', soldPrice?: number): void {
    const list = this.getEstimates();
    const target = list.find((e) => e.id === id);
    if (target) {
      target.status = status;
      if (soldPrice !== undefined) {
        target.soldPrice = soldPrice;
        // Update PricingProfile delta
        const profile = this.getPricingProfile();
        const deltaPct = ((soldPrice - target.costBreakdown.totalExact) / target.costBreakdown.totalExact) * 100;
        profile.wonDeltaRecords.push({
          estimateId: id,
          quoted: target.costBreakdown.totalExact,
          sold: soldPrice,
          deltaPct: Math.round(deltaPct * 10) / 10,
          date: new Date().toISOString().split('T')[0],
        });
        profile.accuracyLevel = Math.min(98, profile.accuracyLevel + 4);
        this.savePricingProfile(profile);
      }
      localStorage.setItem(STORAGE_KEYS.ESTIMATES, JSON.stringify(list));
    }
  },

  getPricingProfile(): PricingProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRICING_PROFILE);
      if (data) return JSON.parse(data);
    } catch {}
    return {
      tradeKey: 'attic-insulation',
      pricePerSqFtRanges: {
        'attic-insulation': { min: 2.2, avg: 3.15, max: 5.2 },
      },
      typicalMaterialMarkup: 25,
      laborHoursPerSqFt: {
        'attic-insulation': 0.008,
      },
      typicalAddons: ['Air Sealing', 'Baffles', 'Hatch Box', 'Sanitizing Fog'],
      pastQuotes: DEMO_PAST_QUOTES,
      wonDeltaRecords: [
        { estimateId: 'hist-1', quoted: 4400, sold: 4250, deltaPct: -3.4, date: '2026-09-18' },
        { estimateId: 'hist-2', quoted: 5300, sold: 5100, deltaPct: -3.7, date: '2026-10-12' },
      ],
      accuracyLevel: 75,
    };
  },

  savePricingProfile(profile: PricingProfile): void {
    localStorage.setItem(STORAGE_KEYS.PRICING_PROFILE, JSON.stringify(profile));
  },

  getPriceList(tradeId: string = 'attic-insulation'): PriceListItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRICE_LIST);
      if (data) {
        const list: PriceListItem[] = JSON.parse(data);
        if (list.length > 0) return list;
      }
    } catch {}
    return TRADES['attic-insulation'].defaultPriceList;
  },

  savePriceList(items: PriceListItem[]): void {
    localStorage.setItem(STORAGE_KEYS.PRICE_LIST, JSON.stringify(items));
  },

  getRules(): PricingRule[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.RULES);
      if (data) return JSON.parse(data);
    } catch {}
    return TRADES['attic-insulation'].defaultRules;
  },

  saveRules(rules: PricingRule[]): void {
    localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(rules));
  },

  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.SETTINGS);
      if (data) {
        const parsed: AppSettings = JSON.parse(data);
        if (!parsed.googleAuth?.clientId) {
          parsed.googleAuth = {
            clientId: '148971107659-nk933e494c5rm4pahl9ji592jmtgguho.apps.googleusercontent.com',
            clientSecret: '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',
            isConnected: true,
            userEmail: 'oskarfipsku@gmail.com',
            userName: 'Oskar',
          };
          parsed.userEmail = parsed.userEmail || 'oskarfipsku@gmail.com';
          parsed.isAuthenticated = true;
          this.saveSettings(parsed);
        }
        return parsed;
      }
      return DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: AppSettings): void {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  },

  enableDemoMode(customName?: string, customTrade?: string): void {
    const selectedTrade = customTrade || 'Kitchen & Bath Remodel';
    const tradeConfig = TRADES[selectedTrade.toLowerCase().replace(/[^a-z0-9]+/g, '-')] || TRADES['kitchen-bath'];

    const profile: CompanyProfile = {
      ...DEFAULT_COMPANY_PROFILE,
      companyName: customName || 'Apex Contractors',
      primaryTrade: selectedTrade,
      otherTrades: selectedTrade.includes('Remodel') ? ['Attic Conversion / Remodel', 'Flooring'] : ['Spray Foam', 'Air Sealing'],
      isOnboarded: true,
    };
    this.saveCompanyProfile(profile);
    const settings = { ...DEFAULT_SETTINGS, isAuthenticated: true };
    this.saveSettings(settings);

    // Trade appropriate demo estimate
    const isRemodel = profile.primaryTrade.toLowerCase().includes('remodel') || profile.primaryTrade.toLowerCase().includes('kitchen') || profile.primaryTrade.toLowerCase().includes('bath');
    const demoEstimates = isRemodel
      ? [
          {
            id: 'est-demo-remodel-1',
            estimateNumber: 'QOS-1048',
            createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
            updatedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
            status: 'sent' as const,
            customer: {
              name: 'Sarah & Tom Jenkins',
              phone: '(303) 555-0192',
              email: 'sjenkins@gmail.com',
              address: '4820 Evergreen Ter, Denver, CO',
              oneWayMiles: 12,
            },
            jobType: 'Kitchen & Bath Remodel',
            subTypes: ['Master bathroom renovation', 'Walk-in tile shower conversion', 'Cabinetry & quartz replacement'],
            photos: [],
            description: 'Master bathroom remodel with curbless tile shower, double vanity and new lighting.',
            measurements: {
              squareFootage: 140,
              ceilingHeightFeet: 8,
              finishTier: 'semi-custom',
              plumbingScope: 'relocate',
              cabinetryLinearFeet: 12,
            },
            measurementConfirmed: { squareFootage: true },
            measurementAiSuggested: {},
            questions: [
              {
                id: 'q-plumb',
                question: 'Are plumbing supply and drain lines remaining in current locations?',
                options: ['Moving toilet / shower drains', 'Keep existing drain rough-ins', 'New waste stack tie-in'],
                answer: 'Moving toilet / shower drains',
                reasonTag: 'plumbing_relocation',
              },
            ],
            flags: [],
            lineItems: [
              {
                id: 'li-1',
                category: 'materials' as const,
                name: 'Schluter-Kerdi Waterproof Shower Pan & Drain System',
                quantity: 1,
                unit: 'kit',
                unitCost: 680,
                markupPct: 25,
                total: 850,
              },
              {
                id: 'li-2',
                category: 'materials' as const,
                name: 'Designer Porcelain Tile & Setting Mortar',
                quantity: 180,
                unit: 'sq-ft',
                unitCost: 9.5,
                markupPct: 25,
                total: 2137.5,
              },
              {
                id: 'li-3',
                category: 'materials' as const,
                name: 'Solid Wood Double Vanity & Quartz Countertop',
                quantity: 1,
                unit: 'ea',
                unitCost: 1650,
                markupPct: 25,
                total: 2062.5,
              },
              {
                id: 'li-4',
                category: 'labor' as const,
                name: 'Certified Tile & Carpentry Crew Labor',
                quantity: 42,
                unit: 'hours',
                unitCost: 65,
                markupPct: 0,
                total: 2730,
              },
            ],
            costBreakdown: {
              materialsBase: 3840,
              materialsMarkedUp: 5050,
              laborCost: 2730,
              laborHours: 42,
              crewDays: 2.6,
              travelCost: 0,
              equipmentCost: 250,
              permitsCost: 150,
              subtotalCosts: 8180,
              overheadAmount: 1227,
              profitAmount: 4120,
              contingencyAmount: 676,
              preTaxTotal: 14203,
              taxAmount: 391,
              totalExact: 14594,
              rangeLow: 13850,
              rangeHigh: 15300,
              confidence: 'high' as const,
              confidenceScore: 94,
              confidenceReasons: ['Detailed room walkthrough with verified tile and plumbing locations.'],
              appliedRules: [],
            },
            scopeBullets: [
              'Demolition of existing fiberglass surround down to framing studs.',
              'Installation of Schluter-Kerdi 100% waterproof vapor membrane and shower pan.',
              'Setting designer porcelain wall tile and mosaic shower floor with epoxy grout.',
              'Plumbing rough-in relocation for double vanity and thermostatic shower valve.',
              'Installation of solid wood vanity, quartz countertop, and mirror package.',
            ],
            viewMode: 'customer' as const,
            priceDisplayMode: 'exact' as const,
            spotDiscountApplied: false,
            validDays: 14,
          },
        ]
      : DEMO_ESTIMATES;

    localStorage.setItem(STORAGE_KEYS.ESTIMATES, JSON.stringify(demoEstimates));
    localStorage.setItem(STORAGE_KEYS.PRICE_LIST, JSON.stringify(tradeConfig.defaultPriceList));
    localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(tradeConfig.defaultRules));
    this.savePricingProfile({
      tradeKey: tradeConfig.id,
      pricePerSqFtRanges: {
        [tradeConfig.id]: { min: 45, avg: 110, max: 220 },
      },
      typicalMaterialMarkup: 25,
      laborHoursPerSqFt: { [tradeConfig.id]: 0.3 },
      typicalAddons: ['Plumbing Rough-In', 'Schluter Membrane', 'Quartz Fabrication'],
      pastQuotes: DEMO_PAST_QUOTES,
      wonDeltaRecords: [
        { estimateId: 'hist-1', quoted: 14200, sold: 13900, deltaPct: -2.1, date: '2026-09-18' },
      ],
      accuracyLevel: 86,
    });
  },

  clearAll(): void {
    localStorage.clear();
  },
};
