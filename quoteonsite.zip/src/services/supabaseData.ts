import { supabase } from '../lib/supabase';
import {
  CompanyProfile,
  Estimate,
  PastQuote,
  PriceListItem,
  PricingProfile,
  PricingRule,
} from '../types';
import { DEFAULT_COMPANY_PROFILE } from './storage';
import { TRADES } from '../data/tradeKnowledge';

// ==========================================
// 1. COMPANIES (camelCase <-> snake_case)
// ==========================================

export function companyToSnakeCase(profile: CompanyProfile, ownerId: string): any {
  return {
    id: profile.id || undefined,
    owner_id: ownerId,
    name: profile.companyName,
    primary_trade: profile.primaryTrade,
    other_trades: profile.otherTrades || [],
    city: profile.location?.city || '',
    state: profile.location?.state || '',
    postal_code: profile.location?.zip || '',
    country: profile.location?.country || 'USA',
    lat: profile.location?.lat || null,
    lng: profile.location?.lng || null,
    service_radius: profile.serviceRadius || 30,
    company_type: profile.companyType || 'Small crew (2-5)',
    crew_size: profile.crewSize || 2,
    crews: profile.crewsRunning || 1,
    target_margin: profile.targetMargin || 35,
    overhead_pct: profile.overheadPct || 15,
    labor_model: profile.laborModel || 'hourly',
    billable_rate: profile.billableHourlyRate || 95,
    material_markup: profile.materialMarkupPct || 25,
    quote_style: profile.quoteStyle || 'options',
    tax_rate: profile.taxRatePct || 7.75,
    payment_terms: profile.paymentTerms || '',
    warranty: profile.warranty || '',
    settings: {
      logoUrl: profile.logoUrl || '',
      loadedHourlyRate: profile.loadedHourlyRate || 58,
      avgJobValue: profile.avgJobValue || 4000,
      radiusUnit: profile.radiusUnit || 'miles',
      travelPricing: profile.travelPricing,
      chargeAddons: profile.chargeAddons,
      spotDiscount: profile.spotDiscount,
      termsAndConditions: profile.termsAndConditions,
      customerDisclaimer: profile.customerDisclaimer,
      isOnboarded: profile.isOnboarded ?? true,
    },
    updated_at: new Date().toISOString(),
  };
}

export function companyFromSnakeCase(row: any): CompanyProfile {
  const settings = row.settings || {};
  return {
    id: row.id,
    companyName: row.name || 'Contractor',
    logoUrl: settings.logoUrl || '',
    primaryTrade: row.primary_trade || 'Kitchen & Bath Remodel',
    otherTrades: row.other_trades || [],
    location: {
      city: row.city || '',
      state: row.state || '',
      zip: row.postal_code || '',
      country: row.country || 'USA',
      lat: row.lat || 39.7392,
      lng: row.lng || -104.9903,
    },
    serviceRadius: row.service_radius || 30,
    radiusUnit: settings.radiusUnit || 'miles',
    companyType: row.company_type || 'Small crew (2-5)',
    crewSize: row.crew_size || 2,
    crewsRunning: row.crews || 1,
    avgJobValue: settings.avgJobValue || 4000,
    targetMargin: row.target_margin || 35,
    overheadPct: row.overhead_pct || 15,
    laborModel: row.labor_model || 'hourly',
    loadedHourlyRate: settings.loadedHourlyRate || 58,
    billableHourlyRate: row.billable_rate || 95,
    travelPricing: settings.travelPricing || DEFAULT_COMPANY_PROFILE.travelPricing,
    materialMarkupPct: row.material_markup || 25,
    quoteStyle: row.quote_style || 'options',
    chargeAddons: settings.chargeAddons || DEFAULT_COMPANY_PROFILE.chargeAddons,
    taxRatePct: row.tax_rate || 7.75,
    paymentTerms: row.payment_terms || '',
    warranty: row.warranty || '',
    spotDiscount: settings.spotDiscount || DEFAULT_COMPANY_PROFILE.spotDiscount,
    termsAndConditions: settings.termsAndConditions || '',
    customerDisclaimer: settings.customerDisclaimer || '',
    isOnboarded: settings.isOnboarded ?? true,
  };
}

export async function fetchCompanyFromSupabase(
  ownerId: string
): Promise<{ company: CompanyProfile | null; error?: string }> {
  try {
    const { data, error } = await supabase
      .from('companies')
      .select('*')
      .eq('owner_id', ownerId)
      .maybeSingle();

    if (error) {
      console.warn('fetchCompanyFromSupabase error:', error.message);
      return { company: null, error: error.message };
    }

    if (!data) {
      return { company: null };
    }

    return { company: companyFromSnakeCase(data) };
  } catch (err: any) {
    return { company: null, error: err.message };
  }
}

export async function saveCompanyToSupabase(
  profile: CompanyProfile,
  ownerId: string
): Promise<{ company: CompanyProfile | null; error?: string }> {
  try {
    const row = companyToSnakeCase(profile, ownerId);

    // If company already has an ID, update; else insert
    let query = supabase.from('companies');
    let result;

    if (profile.id) {
      result = await query.update(row).eq('id', profile.id).select().single();
    } else {
      // Check if one already exists for this owner
      const existing = await supabase
        .from('companies')
        .select('id')
        .eq('owner_id', ownerId)
        .maybeSingle();

      if (existing.data?.id) {
        result = await query
          .update(row)
          .eq('id', existing.data.id)
          .select()
          .single();
      } else {
        result = await query.insert(row).select().single();
      }
    }

    if (result.error) {
      console.error('saveCompanyToSupabase error:', result.error.message);
      return { company: null, error: result.error.message };
    }

    return { company: companyFromSnakeCase(result.data) };
  } catch (err: any) {
    return { company: null, error: err.message };
  }
}

// ==========================================
// 2. PRICE LIST ITEMS
// ==========================================

export async function fetchPriceListFromSupabase(
  companyId: string,
  trade: string
): Promise<PriceListItem[]> {
  try {
    const { data, error } = await supabase
      .from('price_list_items')
      .select('*')
      .eq('company_id', companyId);

    if (error || !data || data.length === 0) {
      const defaultItems =
        TRADES['kitchen-bath']?.defaultPriceList ||
        TRADES['attic-insulation']?.defaultPriceList ||
        [];
      return defaultItems;
    }

    return data.map((row) => ({
      id: row.id,
      trade: row.trade || trade,
      category: 'materials',
      name: row.name,
      unit: row.unit || 'unit',
      unitCost: Number(row.unit_cost) || 0,
      defaultMarkup: Number(row.markup) || 25,
      notes: '',
    }));
  } catch {
    return [];
  }
}

export async function savePriceListItemToSupabase(
  companyId: string,
  item: PriceListItem
): Promise<{ success: boolean; error?: string }> {
  try {
    const row = {
      id: item.id.includes('demo') ? undefined : item.id,
      company_id: companyId,
      name: item.name,
      trade: item.trade,
      unit: item.unit,
      unit_cost: item.unitCost,
      markup: item.defaultMarkup,
    };
    const { error } = await supabase.from('price_list_items').upsert(row);
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// ==========================================
// 3. PRICING RULES
// ==========================================

export async function fetchPricingRulesFromSupabase(
  companyId: string
): Promise<PricingRule[]> {
  try {
    const { data, error } = await supabase
      .from('pricing_rules')
      .select('*')
      .eq('company_id', companyId);

    if (error || !data || data.length === 0) {
      return TRADES['kitchen-bath']?.defaultRules || TRADES['attic-insulation']?.defaultRules || [];
    }

    return data.map((row) => ({
      id: row.id,
      name: row.name,
      description: row.name,
      enabled: Boolean(row.enabled),
      conditionType: (row.type as any) || 'access_difficulty',
      condition: row.condition,
      parameter: row.condition,
      effectType: 'surcharge_fixed',
      effectValue: Number(row.value) || 0,
    }));
  } catch {
    return [];
  }
}

export async function savePricingRuleToSupabase(
  companyId: string,
  rule: PricingRule
): Promise<{ success: boolean; error?: string }> {
  try {
    const row = {
      id: isValidUUID(rule.id) ? rule.id : undefined,
      company_id: companyId,
      name: rule.name,
      enabled: rule.enabled ?? true,
      type: rule.conditionType || 'custom',
      condition: rule.condition || rule.parameter || rule.description || '',
      value: rule.adjustmentValue ?? rule.effectValue ?? 0,
    };
    const { error } = await supabase.from('pricing_rules').upsert(row);
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// ==========================================
// 4. PAST QUOTES
// ==========================================

export async function fetchPastQuotesFromSupabase(
  companyId: string
): Promise<PastQuote[]> {
  try {
    const { data, error } = await supabase
      .from('past_quotes')
      .select('*')
      .eq('company_id', companyId)
      .order('created_at', { ascending: false });

    if (error || !data) return [];

    return data.map((row) => ({
      id: row.id,
      title: `${row.job_type} - $${row.total}`,
      date: row.created_at ? row.created_at.split('T')[0] : new Date().toISOString().split('T')[0],
      jobType: row.job_type || 'General Remodel',
      totalAmount: Number(row.total) || 0,
      sqFt: Number(row.sqft) || 0,
      scopeNotes: '',
      lineItems: [],
      confirmed: Boolean(row.confirmed),
    }));
  } catch {
    return [];
  }
}

export async function savePastQuoteToSupabase(
  companyId: string,
  quote: PastQuote
): Promise<{ success: boolean; error?: string }> {
  try {
    const row = {
      id: isValidUUID(quote.id) ? quote.id : undefined,
      company_id: companyId,
      job_type: quote.jobType,
      total: quote.totalAmount,
      sqft: quote.sqFt || 0,
      confirmed: quote.confirmed ?? true,
    };
    const { error } = await supabase.from('past_quotes').upsert(row);
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// ==========================================
// 5. ESTIMATES & AUTOSAVE DRAFTS
// ==========================================

const UUID_REGEX = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function generateUUID(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

export function isValidUUID(id?: string): boolean {
  if (!id) return false;
  return UUID_REGEX.test(id);
}

export function estimateToSnakeCase(estimate: Estimate, companyId: string): any {
  // Guarantee valid Postgres UUID for the primary key
  const validId = isValidUUID(estimate.id) ? estimate.id : generateUUID();
  estimate.id = validId;

  // Store all rich details cleanly in totals.fullDetails so zero data is lost
  const fullDetails = {
    estimateNumber: estimate.estimateNumber,
    jobType: estimate.jobType,
    subTypes: estimate.subTypes || [],
    photos: estimate.photos || [],
    description: estimate.description || '',
    measurements: estimate.measurements,
    measurementConfirmed: estimate.measurementConfirmed,
    measurementAiSuggested: estimate.measurementAiSuggested,
    questions: estimate.questions,
    flags: estimate.flags,
    scopeBullets: estimate.scopeBullets,
    goodBetterBest: estimate.goodBetterBest,
    selectedTier: estimate.selectedTier,
    viewMode: estimate.viewMode,
    priceDisplayMode: estimate.priceDisplayMode,
    spotDiscountApplied: estimate.spotDiscountApplied,
    validDays: estimate.validDays,
    costBreakdown: estimate.costBreakdown,
  };

  return {
    id: validId,
    company_id: companyId,
    status: estimate.status,
    customer: estimate.customer || {},
    line_items: estimate.lineItems || [],
    totals: {
      ...estimate.costBreakdown,
      __details: fullDetails,
    },
    total: estimate.costBreakdown?.totalExact || 0,
    signature: estimate.signature || null,
    version: 1,
    created_at: estimate.createdAt || new Date().toISOString(),
    updated_at: new Date().toISOString(),
  };
}

export function estimateFromSnakeCase(row: any): Estimate {
  const totalsObj = row.totals || {};
  const details = totalsObj.__details || {};

  return {
    id: row.id,
    estimateNumber: details.estimateNumber || `EST-${row.id.slice(0, 6).toUpperCase()}`,
    createdAt: row.created_at || new Date().toISOString(),
    updatedAt: row.updated_at || new Date().toISOString(),
    status: row.status || 'draft',
    soldPrice: row.total,
    customer: row.customer || {
      name: 'Customer',
      phone: '',
      email: '',
      address: '',
      oneWayMiles: 0,
    },
    jobType: details.jobType || 'Kitchen & Bath Remodel',
    subTypes: details.subTypes || [],
    photos: details.photos || [],
    description: details.description || '',
    measurements: details.measurements || {
      squareFootage: 140,
    },
    measurementConfirmed: details.measurementConfirmed || { squareFootage: true },
    measurementAiSuggested: details.measurementAiSuggested || {},
    questions: details.questions || [],
    flags: details.flags || [],
    lineItems: row.line_items || [],
    costBreakdown: details.costBreakdown || {
      materialsBase: totalsObj.materialsBase || 0,
      materialsMarkedUp: totalsObj.materialsMarkedUp || 0,
      laborCost: totalsObj.laborCost || 0,
      laborHours: totalsObj.laborHours || 0,
      crewDays: totalsObj.crewDays || 0,
      travelCost: totalsObj.travelCost || 0,
      equipmentCost: totalsObj.equipmentCost || 0,
      permitsCost: totalsObj.permitsCost || 0,
      subtotalCosts: totalsObj.subtotalCosts || 0,
      overheadAmount: totalsObj.overheadAmount || 0,
      profitAmount: totalsObj.profitAmount || 0,
      contingencyAmount: totalsObj.contingencyAmount || 0,
      preTaxTotal: totalsObj.preTaxTotal || 0,
      taxAmount: totalsObj.taxAmount || 0,
      totalExact: row.total || totalsObj.totalExact || 0,
      rangeLow: (row.total || 0) * 0.95,
      rangeHigh: (row.total || 0) * 1.05,
      confidence: 'high' as const,
      confidenceScore: 92,
      confidenceReasons: ['Calculated from trade rate formulas and local pricing'],
      appliedRules: [],
    },
    scopeBullets: details.scopeBullets || [],
    goodBetterBest: details.goodBetterBest,
    selectedTier: details.selectedTier || 'better',
    viewMode: details.viewMode || 'contractor',
    priceDisplayMode: details.priceDisplayMode || 'exact',
    spotDiscountApplied: details.spotDiscountApplied ?? false,
    validDays: details.validDays || 14,
    signature: row.signature || undefined,
  };
}

export async function fetchEstimatesFromSupabase(companyId: string): Promise<Estimate[]> {
  try {
    const { data, error } = await supabase
      .from('estimates')
      .select('*')
      .eq('company_id', companyId)
      .order('updated_at', { ascending: false });

    if (error) {
      console.warn('fetchEstimatesFromSupabase warning:', error.message);
      return [];
    }

    return (data || []).map((row) => estimateFromSnakeCase(row));
  } catch (err) {
    console.error('Error fetching estimates from Supabase:', err);
    return [];
  }
}

export async function saveEstimateToSupabase(
  arg1: string | Estimate,
  arg2?: Estimate | string
): Promise<{ success: boolean; error?: string }> {
  try {
    let companyId: string;
    let estimate: Estimate;

    if (typeof arg1 === 'string') {
      companyId = arg1;
      estimate = arg2 as Estimate;
    } else {
      estimate = arg1;
      companyId = (arg2 as string) || estimate.companyId || 'company_1';
    }

    const row = estimateToSnakeCase(estimate, companyId);
    const { error } = await supabase.from('estimates').upsert(row);

    if (error) {
      console.error('saveEstimateToSupabase error:', error.message);
      return { success: false, error: error.message };
    }

    // Also record a snapshot version in estimate_versions
    try {
      await supabase.from('estimate_versions').insert({
        estimate_id: estimate.id,
        version: 1,
        snapshot: row,
      });
    } catch {
      // Non-blocking version save
    }

    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

export async function deleteEstimateFromSupabase(
  estimateId: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase.from('estimates').delete().eq('id', estimateId);
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// 6. RECORD ESTIMATE PHOTO TO TABLE
export async function recordEstimatePhotoToSupabase(
  estimateId: string,
  storagePath: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { error } = await supabase.from('estimate_photos').insert({
      estimate_id: estimateId,
      storage_path: storagePath,
    });
    if (error) return { success: false, error: error.message };
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}
