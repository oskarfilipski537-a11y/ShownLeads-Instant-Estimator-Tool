import React, { useState } from 'react';
import {
  LogOut,
  Download,
  ChevronRight,
  Sparkles,
  Layers,
  Shield,
  CreditCard,
  Sun,
  Ruler,
  Globe,
  Sliders,
  DollarSign
} from 'lucide-react';
import { AppSettings, CompanyProfile, Estimate } from '../types';
import { ALL_TRADE_PACKS } from '../tradePacks';
import { InsetGroup, InsetRow } from '../components/apple/InsetGroup';
import { SegmentedControl } from '../components/apple/SegmentedControl';
import { BottomSheet, SheetOption } from '../components/apple/BottomSheet';
import { supabase } from '../lib/supabase';

interface SettingsScreenProps {
  company: CompanyProfile;
  settings: AppSettings;
  estimates?: Estimate[];
  onUpdateCompany: (company: CompanyProfile) => void;
  onUpdateSettings: (settings: AppSettings) => void;
  onSignOut: () => void;
}

export const SettingsScreen: React.FC<SettingsScreenProps> = ({
  company,
  settings,
  estimates = [],
  onUpdateCompany,
  onUpdateSettings,
  onSignOut,
}) => {
  const [profile, setProfile] = useState<CompanyProfile>(company);
  const [currentSettings, setCurrentSettings] = useState<AppSettings>(settings);
  const [versionTapCount, setVersionTapCount] = useState(0);
  const [isDeveloperMode, setIsDeveloperMode] = useState(false);
  const [tradeWarning, setTradeWarning] = useState(false);

  // Custom Bottom Sheet Picker state for Settings Dropdowns
  const [activePicker, setActivePicker] = useState<{
    title: string;
    options: SheetOption[];
    selected: string;
    onSelect: (val: string) => void;
  } | null>(null);

  const handleCompanyChange = (updates: Partial<CompanyProfile>) => {
    const updated = { ...profile, ...updates };
    setProfile(updated);
    onUpdateCompany(updated);
  };

  const handleSettingsChange = (updates: Partial<AppSettings>) => {
    const updated = { ...currentSettings, ...updates };
    setCurrentSettings(updated);
    onUpdateSettings(updated);
  };

  const handleVersionTap = () => {
    const next = versionTapCount + 1;
    setVersionTapCount(next);
    if (next >= 7) {
      setIsDeveloperMode(!isDeveloperMode);
      setVersionTapCount(0);
    }
  };

  const handleExportJSON = () => {
    const data = {
      company: profile,
      settings: currentSettings,
      estimates: estimates,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `shownleads_backup_${Date.now()}.json`;
    a.click();
  };

  // Trade selection options
  const tradeOptions: SheetOption[] = ALL_TRADE_PACKS.map((t) => ({
    value: t.id,
    label: t.displayName,
    description: `e.g. ${t.jobTypes[0]?.name}`,
  }));

  // Payment plan options
  const paymentPlanOptions: SheetOption[] = [
    { value: 'Pay when the job is done.', label: 'Pay when done', description: '100% on job completion' },
    { value: '20% deposit, balance on completion.', label: 'Deposit + completion', description: '20% upfront deposit' },
    { value: 'Stages: 30% start, 40% midway, 30% finish.', label: 'Stage payments', description: '30% / 40% / 30% milestones' },
  ];

  // Warranty options
  const warrantyOptions: SheetOption[] = [
    { value: '5-Year', label: '5-Year Warranty', description: 'Standard coverage' },
    { value: '10-Year', label: '10-Year Warranty', description: 'Most popular protection' },
    { value: '15-Year', label: '15-Year Warranty', description: 'Extended guarantee' },
    { value: '25-Year', label: '25-Year Warranty', description: 'Lifetime tier' },
  ];

  // Find active trade label
  const activeTradeName =
    ALL_TRADE_PACKS.find((t) => t.id === profile.primaryTrade)?.displayName || profile.primaryTrade;

  return (
    <div className="min-h-screen text-white pb-28 px-4 pt-4 max-w-md mx-auto w-full select-none">
      {/* Large Title with White Text */}
      <div className="pt-2 pb-3">
        <h1 className="text-[34px] font-extrabold tracking-tight text-white">
          Settings
        </h1>
        <p className="text-[14px] text-white/80 font-medium">
          Customize your business, rates and appearance
        </p>
      </div>

      <div className="space-y-4">
        {/* Business Group */}
        <InsetGroup title="Business">
          <InsetRow
            label="Company name"
            control={
              <input
                type="text"
                value={profile.companyName}
                onChange={(e) => handleCompanyChange({ companyName: e.target.value })}
                className="text-right text-[17px] font-bold text-white bg-transparent outline-none w-48"
              />
            }
          />
          <InsetRow
            label="Phone"
            control={
              <input
                type="tel"
                value={profile.location?.city || ''}
                onChange={(e) =>
                  handleCompanyChange({
                    location: { ...profile.location, city: e.target.value },
                  })
                }
                placeholder="Phone or City"
                className="text-right text-[17px] font-bold text-white bg-transparent outline-none w-36 placeholder:text-white/40"
              />
            }
          />

          {/* Super-Optimized Trade Option Button (Replaced ugly native select) */}
          <InsetRow
            label="Trade"
            helper="Active trade config"
            isLast
            onClick={() => {
              setActivePicker({
                title: 'Select Trade',
                options: tradeOptions,
                selected: profile.primaryTrade,
                onSelect: (tradeId) => {
                  setTradeWarning(true);
                  handleCompanyChange({ primaryTrade: tradeId, otherTrades: [tradeId] });
                },
              });
            }}
            control={
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] bg-white/10 border border-white/20 text-cyan-300 font-bold text-[15px] active:scale-95 transition-all">
                <span>{activeTradeName}</span>
                <ChevronRight className="w-4 h-4 text-white/70" />
              </div>
            }
          />
        </InsetGroup>

        {tradeWarning && (
          <div className="p-4 rounded-[16px] bg-amber-500/20 border border-amber-400/40 text-amber-200 text-[14px] font-semibold leading-snug shadow-md">
            Changing trade changes your price book, measurements and questions to match that industry.
          </div>
        )}

        {/* My Numbers Group (White text, high contrast) */}
        <InsetGroup title="My numbers" footer="Used by the estimate engine for all new quotes.">
          <InsetRow
            label="Hourly rate"
            helper="Cost per worker hour"
            control={
              <div className="flex items-center gap-1">
                <span className="text-[17px] text-white/70 font-bold">$</span>
                <input
                  type="number"
                  inputMode="decimal"
                  value={profile.loadedHourlyRate || 55}
                  onChange={(e) =>
                    handleCompanyChange({
                      loadedHourlyRate: parseFloat(e.target.value) || 0,
                      billableHourlyRate: parseFloat(e.target.value) || 0,
                    })
                  }
                  className="text-right text-[18px] font-extrabold text-white bg-transparent outline-none w-16 tabular-nums"
                />
              </div>
            }
          />
          <InsetRow
            label="Crew size"
            helper="Technicians on standard job"
            control={
              <input
                type="number"
                inputMode="numeric"
                value={profile.crewSize || 2}
                onChange={(e) => handleCompanyChange({ crewSize: parseInt(e.target.value, 10) || 1 })}
                className="text-right text-[18px] font-extrabold text-white bg-transparent outline-none w-14 tabular-nums"
              />
            }
          />
          <InsetRow
            label="Profit wanted"
            helper="Profit you want from each job"
            control={
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  inputMode="decimal"
                  value={profile.targetMargin || 35}
                  onChange={(e) => handleCompanyChange({ targetMargin: parseFloat(e.target.value) || 0 })}
                  className="text-right text-[18px] font-extrabold text-emerald-300 bg-transparent outline-none w-14 tabular-nums"
                />
                <span className="text-[17px] text-white/80 font-bold">%</span>
              </div>
            }
          />
          <InsetRow
            label="Overhead"
            helper="Van, tools and insurance"
            control={
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  inputMode="decimal"
                  value={profile.overheadPct || 15}
                  onChange={(e) => handleCompanyChange({ overheadPct: parseFloat(e.target.value) || 0 })}
                  className="text-right text-[18px] font-extrabold text-white bg-transparent outline-none w-14 tabular-nums"
                />
                <span className="text-[17px] text-white/80 font-bold">%</span>
              </div>
            }
          />
          <InsetRow
            label="Minimum job"
            helper="Smallest job taken"
            control={
              <div className="flex items-center gap-1">
                <span className="text-[17px] text-white/70 font-bold">$</span>
                <input
                  type="number"
                  inputMode="decimal"
                  value={profile.avgJobValue || 500}
                  onChange={(e) => handleCompanyChange({ avgJobValue: parseFloat(e.target.value) || 0 })}
                  className="text-right text-[18px] font-extrabold text-white bg-transparent outline-none w-20 tabular-nums"
                />
              </div>
            }
          />
          <InsetRow
            label="Tax rate"
            isLast
            control={
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  inputMode="decimal"
                  value={profile.taxRatePct || 0}
                  onChange={(e) => handleCompanyChange({ taxRatePct: parseFloat(e.target.value) || 0 })}
                  className="text-right text-[18px] font-extrabold text-white bg-transparent outline-none w-14 tabular-nums"
                />
                <span className="text-[17px] text-white/80 font-bold">%</span>
              </div>
            }
          />
        </InsetGroup>

        {/* Quote Terms: Super-Optimized Dropdown Buttons */}
        <InsetGroup title="Quote terms">
          {/* Payment Plan Option Button */}
          <InsetRow
            label="Payment plan"
            helper="Customer payment schedule"
            onClick={() => {
              setActivePicker({
                title: 'Select Payment Plan',
                options: paymentPlanOptions,
                selected: profile.paymentTerms || 'Pay when the job is done.',
                onSelect: (val) => handleCompanyChange({ paymentTerms: val }),
              });
            }}
            control={
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] bg-white/10 border border-white/20 text-cyan-300 font-bold text-[15px] active:scale-95 transition-all">
                <span className="max-w-[140px] truncate">
                  {paymentPlanOptions.find((p) => p.value === profile.paymentTerms)?.label || 'Pay when done'}
                </span>
                <ChevronRight className="w-4 h-4 text-white/70 shrink-0" />
              </div>
            }
          />

          {/* Warranty Option Button */}
          <InsetRow
            label="Warranty"
            helper="Guaranteed years"
            isLast
            onClick={() => {
              setActivePicker({
                title: 'Select Warranty Period',
                options: warrantyOptions,
                selected: profile.warranty || '10-Year',
                onSelect: (val) => handleCompanyChange({ warranty: val }),
              });
            }}
            control={
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-[12px] bg-white/10 border border-white/20 text-cyan-300 font-bold text-[15px] active:scale-95 transition-all">
                <span>{profile.warranty || '10-Year'}</span>
                <ChevronRight className="w-4 h-4 text-white/70" />
              </div>
            }
          />
        </InsetGroup>

        {/* Display Settings (Theme & Units both working & persisting) */}
        <InsetGroup title="Display">
          <div className="px-4 py-3.5 border-b border-white/10">
            <span className="text-[17px] font-bold text-white block mb-2.5">
              Appearance
            </span>
            <SegmentedControl
              size="sm"
              value={currentSettings.theme || 'system'}
              onChange={(val) => handleSettingsChange({ theme: val as any })}
              options={[
                { value: 'system', label: 'System' },
                { value: 'light', label: 'Light' },
                { value: 'dark', label: 'Dark' },
              ]}
            />
          </div>

          <div className="px-4 py-3.5">
            <span className="text-[17px] font-bold text-white block mb-2.5">
              Units
            </span>
            <SegmentedControl
              size="sm"
              value={currentSettings.unitSystem || 'metric'}
              onChange={(val) => handleSettingsChange({ unitSystem: val as any })}
              options={[
                { value: 'metric', label: 'Metric (m, m²)' },
                { value: 'imperial', label: 'Imperial (ft, sq ft)' },
              ]}
            />
          </div>
        </InsetGroup>

        {/* Data & Account */}
        <InsetGroup title="Data & Account">
          <InsetRow
            label="Export backup"
            helper="Download all quotes as JSON"
            onClick={handleExportJSON}
            control={<Download className="w-5 h-5 text-cyan-300" />}
          />
          <InsetRow
            label="Sign out"
            isLast
            onClick={async () => {
              await supabase.auth.signOut();
              onSignOut();
            }}
            control={<LogOut className="w-5 h-5 text-rose-400" />}
          />
        </InsetGroup>

        {/* Hidden Developer Mode (Tap version 7 times) */}
        {isDeveloperMode && (
          <InsetGroup title="Developer (Secret Mode)">
            <div className="p-4 text-[13px] text-white/90 space-y-2.5 bg-black/40">
              <div>
                <span className="font-bold text-white block">Supabase Host:</span>
                <span className="font-mono text-[12px] text-cyan-300 block truncate">
                  https://vlhobumjnpuzhihpqgkt.supabase.co
                </span>
              </div>
              <div>
                <span className="font-bold text-white block">Connected Tables:</span>
                <span className="font-mono text-[12px] text-white/80 block">
                  companies, estimates, estimate_photos, past_quotes
                </span>
              </div>
              <div>
                <span className="font-bold text-white block">RLS Status:</span>
                <span className="text-emerald-400 font-bold">Active (user_id = auth.uid())</span>
              </div>
            </div>
          </InsetGroup>
        )}

        {/* Version info footer */}
        <div className="pt-2 text-center">
          <button
            type="button"
            onClick={handleVersionTap}
            className="text-[13px] text-white/70 active:text-white font-medium select-none"
          >
            ShownLeads Instant Estimator v2.5 (Glass Flow)
          </button>
        </div>
      </div>

      {/* Reusable Bottom Sheet for Settings Pickers */}
      {activePicker && (
        <BottomSheet
          isOpen={true}
          onClose={() => setActivePicker(null)}
          title={activePicker.title}
          options={activePicker.options}
          selectedValue={activePicker.selected}
          onSelect={activePicker.onSelect}
        />
      )}
    </div>
  );
};
