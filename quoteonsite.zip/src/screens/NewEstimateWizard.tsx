import React, { useState, useEffect, useRef } from 'react';
import {
  Camera,
  Check,
  ChevronRight,
  Mic,
  MicOff,
  Trash2,
  AlertTriangle,
  Upload,
  RotateCcw
} from 'lucide-react';
import {
  CompanyProfile,
  Estimate,
  PhotoAsset,
  PricingProfile,
} from '../types';
import { getTradePack } from '../tradePacks';
import { calculateEstimate } from '../engine/estimateEngine';
import { generateGoodBetterBestTiers } from '../engine/pricing';
import { formatArea, getAreaUnit, toCanonicalLength, toDisplayLength } from '../lib/units';
import { LargeNavBar } from '../components/apple/LargeNavBar';
import { InsetGroup, InsetRow } from '../components/apple/InsetGroup';
import { SegmentedControl } from '../components/apple/SegmentedControl';
import { Stepper } from '../components/apple/Stepper';
import { PrimaryButton } from '../components/apple/PrimaryButton';
import { ActionBottomBar } from '../components/apple/ActionBottomBar';
import { BottomSheet, SheetOption } from '../components/apple/BottomSheet';
import { uploadEstimatePhoto } from '../lib/supabase';
import { saveEstimateToSupabase, recordEstimatePhotoToSupabase, generateUUID, isValidUUID } from '../services/supabaseData';

interface NewEstimateWizardProps {
  company: CompanyProfile;
  pricingProfile: PricingProfile;
  userId?: string;
  initialDraft?: Estimate | null;
  onEstimateGenerated: (estimate: Estimate) => void;
  onCancel: () => void;
}

export const NewEstimateWizard: React.FC<NewEstimateWizardProps> = ({
  company,
  pricingProfile,
  userId,
  initialDraft,
  onEstimateGenerated,
  onCancel,
}) => {
  const pack = getTradePack(company.primaryTrade);
  const [step, setStep] = useState(1);
  const totalSteps = 4;

  // Step 1: Who & where
  const [customerName, setCustomerName] = useState(initialDraft?.customerName || initialDraft?.customer?.name || '');
  const [customerAddress, setCustomerAddress] = useState(initialDraft?.customerAddress || initialDraft?.customer?.address || '');
  const [customerPhone, setCustomerPhone] = useState(initialDraft?.customerPhone || initialDraft?.customer?.phone || '');
  const [customerEmail, setCustomerEmail] = useState(initialDraft?.customerEmail || initialDraft?.customer?.email || '');
  const [selectedJobType, setSelectedJobType] = useState(
    initialDraft?.measurements?.jobTypeId || pack.jobTypes[0]?.id || 'bedroom'
  );

  // Step 2: Photos & notes
  const [photos, setPhotos] = useState<PhotoAsset[]>(initialDraft?.photos || []);
  const [notes, setNotes] = useState(initialDraft?.notes || '');
  const [isRecording, setIsRecording] = useState(false);
  const recognitionRef = useRef<any>(null);

  // Step 3: Measurements
  const defaultMeasures: Record<string, any> = {};
  pack.measureFields.forEach((f) => {
    defaultMeasures[f.id] = initialDraft?.measurements?.[f.id] ?? f.defaultVal;
  });
  const [measurements, setMeasurements] = useState<Record<string, any>>(defaultMeasures);

  // Step 4: Questions
  const [answers, setAnswers] = useState<Record<string, string>>(initialDraft?.answers || {});

  // Picker bottom sheet state
  const [activePicker, setActivePicker] = useState<{
    id: string;
    title: string;
    options: SheetOption[];
    selected: string;
    onSelect: (val: string) => void;
  } | null>(null);

  // Autosave and sync status
  const [syncStatus, setSyncStatus] = useState<'saved' | 'syncing' | 'offline'>('saved');
  const [currentEstimateId] = useState(() => (isValidUUID(initialDraft?.id) ? initialDraft!.id : generateUUID()));

  // Validation errors
  const [validationError, setValidationError] = useState<string | null>(null);

  // Voice recording support
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.onresult = (event: any) => {
          let currentTranscript = '';
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          if (currentTranscript) {
            setNotes((prev: string) => `${prev} ${currentTranscript}`.trim());
          }
        };
        recognition.onerror = () => setIsRecording(false);
        recognition.onend = () => setIsRecording(false);
        recognitionRef.current = recognition;
      }
    }
  }, []);

  const toggleRecording = () => {
    if (!recognitionRef.current) {
      alert('Voice dictation is not available in this browser. Please type your notes.');
      return;
    }
    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      try {
        recognitionRef.current.start();
        setIsRecording(true);
      } catch (e) {
        setIsRecording(false);
      }
    }
  };

  // Autosave draft
  useEffect(() => {
    const timer = setTimeout(async () => {
      if (!customerName && !customerAddress) return;
      setSyncStatus('syncing');

      const draftEstimate: Estimate = {
        id: currentEstimateId,
        companyId: company.id || 'company_1',
        customerName,
        customerAddress,
        customerPhone,
        customerEmail,
        status: 'draft',
        photos,
        notes,
        measurements: {
          ...measurements,
          jobTypeId: selectedJobType,
          jobTypeName: pack.jobTypes.find((j) => j.id === selectedJobType)?.name,
          squareFootage: Number(measurements.length || 0) * Number(measurements.width || 0),
        },
        answers,
        lineItems: [],
        costBreakdown: {
          materialsBase: 0,
          materialsMarkedUp: 0,
          laborCost: 0,
          laborHours: 0,
          crewDays: 1,
          travelCost: 0,
          equipmentCost: 0,
          permitsCost: 0,
          subtotalCosts: 0,
          overheadAmount: 0,
          profitAmount: 0,
          contingencyAmount: 0,
          preTaxTotal: 0,
          taxAmount: 0,
          totalExact: 0,
          rangeLow: 0,
          rangeHigh: 0,
          confidence: 'medium',
          confidenceScore: 60,
          confidenceReasons: ['Draft in progress'],
          appliedRules: [],
        },
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      try {
        // Save to localStorage
        localStorage.setItem(`draft_${currentEstimateId}`, JSON.stringify(draftEstimate));
        // Save to Supabase
        await saveEstimateToSupabase(draftEstimate);
        setSyncStatus('saved');
      } catch (err) {
        setSyncStatus('offline');
      }
    }, 1000);

    return () => clearTimeout(timer);
  }, [customerName, customerAddress, customerPhone, customerEmail, selectedJobType, photos, notes, measurements, answers]);

  // Handle Photo Capture/Upload
  const handlePhotoUpload = async (shotId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const localUrl = URL.createObjectURL(file);
    const newPhoto: PhotoAsset = {
      id: `photo_${Date.now()}`,
      dataUrl: localUrl,
      shotType: shotId,
      timestamp: Date.now(),
    };

    setPhotos((prev) => [...prev.filter((p) => p.shotType !== shotId), newPhoto]);

    // Background upload to Supabase storage
    if (userId) {
      try {
        const uploadRes = await uploadEstimatePhoto(userId, file);
        if (uploadRes && uploadRes.storagePath) {
          await recordEstimatePhotoToSupabase(currentEstimateId, uploadRes.storagePath);
        }
      } catch (err) {
        console.warn('Background photo upload warning:', err);
      }
    }
  };

  // Live Area and Headroom Math
  const lengthM = Number(measurements.length || 0);
  const widthM = Number(measurements.width || 0);
  const floorAreaSqm = lengthM * widthM;
  const standingAreaSqm = Number(measurements.standing_area || (floorAreaSqm * 0.65));
  const usablePct = floorAreaSqm > 0 ? Math.round((standingAreaSqm / floorAreaSqm) * 100) : 0;
  const isHeadroomLow = pack.id === 'attic' && usablePct < 50;

  // Filter relevant questions for Step 4
  const relevantQuestions = pack.questions.filter((q) => {
    if (q.relevantIf) {
      return q.relevantIf(selectedJobType, measurements);
    }
    return true;
  });

  const answeredCount = relevantQuestions.filter((q) => !!answers[q.id]).length;
  const unansweredCount = relevantQuestions.length - answeredCount;

  // Navigation handlers with instant single-tap execution (Bug #1)
  const handleStep1Next = () => {
    setValidationError(null);
    if (!customerName.trim()) {
      setValidationError('Add the customer name.');
      return;
    }
    if (!customerAddress.trim()) {
      setValidationError('Add the job address.');
      return;
    }
    setStep(2);
  };

  const handleStep2Next = () => {
    setValidationError(null);
    setStep(3);
  };

  const handleStep3Next = () => {
    setValidationError(null);
    setStep(4);
  };

  const handleGenerateEstimate = () => {
    setValidationError(null);

    // Run deterministic engine
    const engineResult = calculateEstimate({
      pack,
      company,
      jobTypeId: selectedJobType,
      measurements: {
        ...measurements,
        length: lengthM,
        width: widthM,
      },
      answers,
      photosCount: photos.length,
      pastQuotesCount: pricingProfile.pastQuotes?.length || 0,
    });

    const goodBetterBest = generateGoodBetterBestTiers({
      lineItems: [],
      companyProfile: company,
      costBreakdown: {
        materialsBase: engineResult.materials,
        materialsMarkedUp: engineResult.materials,
        laborCost: engineResult.labour,
        laborHours: engineResult.crewHours,
        crewDays: engineResult.labourDays,
        travelCost: 0,
        equipmentCost: engineResult.extras,
        permitsCost: engineResult.fees,
        subtotalCosts: engineResult.directCost,
        overheadAmount: engineResult.overheadAmount,
        profitAmount: engineResult.profit,
        contingencyAmount: engineResult.contingencyTotal,
        preTaxTotal: engineResult.price,
        taxAmount: engineResult.taxAmount,
        totalExact: engineResult.price,
        rangeLow: Math.round((engineResult.price * 0.95) / 5) * 5,
        rangeHigh: Math.round((engineResult.price * 1.05) / 5) * 5,
        confidence: engineResult.confidenceLevel,
        confidenceScore: engineResult.confidenceScore,
        confidenceReasons: [engineResult.confidenceReason],
        appliedRules: [],
      },
      squareFootage: floorAreaSqm,
      tradeId: pack.id,
      engineResult,
      measurements,
    });

    const activeJobTypeObj = pack.jobTypes.find((j) => j.id === selectedJobType) || pack.jobTypes[0];

    const finalEstimate: Estimate = {
      id: currentEstimateId,
      companyId: company.id || 'company_1',
      customerName: customerName.trim(),
      customerAddress: customerAddress.trim(),
      customerPhone: customerPhone.trim(),
      customerEmail: customerEmail.trim(),
      status: 'draft',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      photos,
      notes,
      measurements: {
        ...measurements,
        jobTypeId: selectedJobType,
        jobTypeName: activeJobTypeObj.name,
        squareFootage: floorAreaSqm,
      },
      answers,
      lineItems: engineResult.lineItems.map((li) => ({
        id: li.id,
        category: li.category === 'labor' ? 'labor' : li.category === 'extras' ? 'other' : 'materials',
        name: li.name,
        quantity: li.quantity,
        unit: li.unit,
        unitCost: li.unitCost,
        markupPct: 0,
        total: li.total,
        aiSuggested: false,
        reasoningTag: li.source,
      })),
      costBreakdown: {
        materialsBase: engineResult.materials,
        materialsMarkedUp: engineResult.materials,
        laborCost: engineResult.labour,
        laborHours: engineResult.crewHours,
        crewDays: engineResult.labourDays,
        travelCost: 0,
        equipmentCost: engineResult.extras,
        permitsCost: engineResult.fees,
        subtotalCosts: engineResult.directCost,
        overheadAmount: engineResult.overheadAmount,
        profitAmount: engineResult.profit,
        contingencyAmount: engineResult.contingencyTotal,
        preTaxTotal: engineResult.price,
        taxAmount: engineResult.taxAmount,
        totalExact: engineResult.price,
        rangeLow: Math.round((engineResult.price * (engineResult.confidenceLevel === 'high' ? 0.95 : 0.9)) / 5) * 5,
        rangeHigh: Math.round((engineResult.price * (engineResult.confidenceLevel === 'high' ? 1.05 : 1.1)) / 5) * 5,
        confidence: engineResult.confidenceLevel,
        confidenceScore: engineResult.confidenceScore,
        confidenceReasons: [engineResult.confidenceReason],
        appliedRules: [],
      },
      options: goodBetterBest,
      total: engineResult.price,
    };

    // Save final to Supabase and proceed
    saveEstimateToSupabase(finalEstimate);
    onEstimateGenerated(finalEstimate);
  };

  return (
    <div className="min-h-screen bg-[var(--apple-bg)] text-[var(--apple-label)] flex flex-col pb-28">
      {/* 6.3 Large Navigation Bar with Thin Progress Bar */}
      <LargeNavBar
        title={
          step === 1
            ? 'Who & where'
            : step === 2
            ? 'Photos & notes'
            : step === 3
            ? 'Size of the job'
            : 'Questions'
        }
        subtitle={
          step === 1
            ? 'Enter customer details and pick the job.'
            : step === 2
            ? 'Photos set your price confidence.'
            : step === 3
            ? 'Enter the key sizes below.'
            : 'Answer these to get your exact price.'
        }
        backLabel={step > 1 ? 'Back' : undefined}
        onBack={step > 1 ? () => setStep(step - 1) : onCancel}
        progressPct={(step / totalSteps) * 100}
        rightAction={
          <span className="text-[12px] font-semibold text-[var(--apple-secondary)]">
            {syncStatus === 'saved' ? 'Saved' : syncStatus === 'syncing' ? 'Syncing…' : 'Offline – saved'}
          </span>
        }
      />

      <main className="flex-1 max-w-md mx-auto w-full px-4 pt-4">
        {/* Validation Error Banner */}
        {validationError && (
          <div className="mb-4 p-3.5 rounded-[14px] bg-[var(--apple-danger)]/15 border border-[var(--apple-danger)]/30 text-[var(--apple-danger)] text-[14px] font-medium leading-snug animate-shake">
            {validationError}
          </div>
        )}

        {/* STEP 1: Who & Where */}
        {step === 1 && (
          <div className="space-y-4">
            <InsetGroup title="Customer Details">
              <InsetRow
                label="Name"
                control={
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => {
                      setCustomerName(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    placeholder="Customer full name"
                    className="text-right text-[17px] text-white placeholder:text-white/40 bg-transparent outline-none w-48 font-medium"
                    autoFocus
                  />
                }
              />
              <InsetRow
                label="Address"
                control={
                  <input
                    type="text"
                    value={customerAddress}
                    onChange={(e) => {
                      setCustomerAddress(e.target.value);
                      if (validationError) setValidationError(null);
                    }}
                    placeholder="Street and postcode"
                    className="text-right text-[17px] text-white placeholder:text-white/40 bg-transparent outline-none w-48 font-medium"
                  />
                }
              />
              <InsetRow
                label="Phone"
                helper="Optional"
                control={
                  <input
                    type="tel"
                    inputMode="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="Mobile number"
                    className="text-right text-[17px] text-white placeholder:text-white/40 bg-transparent outline-none w-36 font-medium"
                  />
                }
              />
              <InsetRow
                label="Email"
                helper="Optional"
                isLast
                control={
                  <input
                    type="email"
                    inputMode="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="customer@email.com"
                    className="text-right text-[17px] text-white placeholder:text-white/40 bg-transparent outline-none w-44 font-medium"
                  />
                }
              />
            </InsetGroup>

            <InsetGroup title="Job Type">
              <div className="p-2 space-y-2">
                {pack.jobTypes.map((job) => {
                  const isSelected = selectedJobType === job.id;
                  return (
                    <button
                      key={job.id}
                      type="button"
                      onClick={() => setSelectedJobType(job.id)}
                      className={`w-full flex items-center justify-between p-3.5 rounded-[14px] text-left transition-all ${
                        isSelected
                          ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-[0_0_20px_rgba(56,189,248,0.5)] border border-cyan-300/40'
                          : 'glass-panel text-white hover:bg-white/[0.08] active:scale-[0.985]'
                      }`}
                    >
                      <div>
                        <span className="text-[16px] font-bold block leading-tight">
                          {job.name}
                        </span>
                        <span
                          className={`text-[13px] block mt-0.5 leading-snug ${
                            isSelected ? 'text-white/90 font-medium' : 'text-white/80'
                          }`}
                        >
                          {job.description}
                        </span>
                      </div>
                      {isSelected && <Check className="w-5 h-5 text-white shrink-0 ml-2 stroke-[2.8]" />}
                    </button>
                  );
                })}
              </div>
            </InsetGroup>

            <ActionBottomBar>
              <PrimaryButton
                label="Next: Photos & notes"
                onClick={handleStep1Next}
              />
            </ActionBottomBar>
          </div>
        )}

        {/* STEP 2: Photos & Notes (Merged) */}
        {step === 2 && (
          <div className="space-y-4">
            <InsetGroup title="Key Photos" footer="Each photo sharpens your estimate confidence.">
              <div className="p-3 space-y-2.5">
                {pack.photoShots.map((shot) => {
                  const existingPhoto = photos.find((p) => p.shotType === shot.id);
                  return (
                    <div
                      key={shot.id}
                      className="flex items-center justify-between p-3.5 rounded-[14px] glass-panel border border-white/15"
                    >
                      <div className="flex-1 pr-3">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[16px] font-bold text-white">
                            {shot.label}
                          </span>
                          {shot.required && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase">
                              Required
                            </span>
                          )}
                        </div>
                        <span className="text-[13px] text-white/80 block mt-0.5 leading-tight font-normal">
                          {shot.why}
                        </span>
                      </div>

                      {existingPhoto ? (
                        <div className="flex items-center gap-2 shrink-0">
                          <img
                            src={existingPhoto.dataUrl}
                            alt={shot.label}
                            className="w-12 h-12 object-cover rounded-[10px] border border-white/20 shadow-sm"
                          />
                          <label className="cursor-pointer p-2 rounded-full bg-white/10 text-white/80 hover:text-white active:scale-95 transition-all">
                            <RotateCcw className="w-4 h-4" />
                            <input
                              type="file"
                              accept="image/*"
                              capture="environment"
                              onChange={(e) => handlePhotoUpload(shot.id, e)}
                              className="hidden"
                            />
                          </label>
                        </div>
                      ) : (
                        <label className="h-10 px-4 rounded-[12px] bg-gradient-to-r from-cyan-500/20 to-blue-500/20 border border-cyan-400/30 text-cyan-300 font-bold text-[14px] flex items-center gap-1.5 cursor-pointer active:scale-95 transition-all shadow-sm shrink-0 hover:bg-cyan-500/30">
                          <Camera className="w-4 h-4 stroke-[2.2]" />
                          <span>Photo</span>
                          <input
                            type="file"
                            accept="image/*"
                            capture="environment"
                            onChange={(e) => handlePhotoUpload(shot.id, e)}
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>
                  );
                })}
              </div>
            </InsetGroup>

            <InsetGroup title="Notes">
              <div className="p-3 space-y-3">
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Tell me about the job. Talk or type."
                  rows={3}
                  className="w-full glass-panel rounded-[14px] p-3.5 text-[16px] text-white placeholder:text-white/45 outline-none resize-none border border-white/15 focus:border-cyan-400"
                />

                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={toggleRecording}
                    className={`inline-flex items-center gap-2 h-10 px-4 rounded-[12px] font-bold text-[14px] transition-all shadow-sm ${
                      isRecording
                        ? 'bg-rose-500 text-white animate-pulse shadow-[0_0_15px_rgba(244,63,94,0.6)]'
                        : 'bg-white/10 text-cyan-300 border border-white/15 hover:bg-white/15 active:scale-95'
                    }`}
                  >
                    {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                    <span>{isRecording ? 'Listening… Tap to stop' : 'Talk note'}</span>
                  </button>
                </div>
              </div>
            </InsetGroup>

            <ActionBottomBar>
              <PrimaryButton
                label="Next: Size of the job"
                onClick={handleStep2Next}
              />
            </ActionBottomBar>
          </div>
        )}

        {/* STEP 3: Size of the Job (Measurements) */}
        {step === 3 && (
          <div className="space-y-4">
            {/* Live Calculated Banner */}
            <div className="p-5 rounded-[22px] glass-panel border border-white/15 shadow-xl space-y-2 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-cyan-500/20 to-transparent rounded-bl-full pointer-events-none" />
              <div className="flex items-center justify-between">
                <span className="text-[15px] font-bold text-white">
                  Floor area
                </span>
                <span className="text-[24px] font-extrabold text-cyan-400 tabular-nums drop-shadow-[0_0_12px_rgba(34,211,238,0.5)]">
                  {formatArea(floorAreaSqm, pack.defaultUnitSystem)}
                </span>
              </div>

              {pack.id === 'attic' && (
                <div className="flex items-center justify-between text-[13px] text-white/80 pt-2 border-t border-white/10">
                  <span>Full standing height area</span>
                  <span className="font-bold text-white tabular-nums">
                    {usablePct}% of floor
                  </span>
                </div>
              )}

              {isHeadroomLow && (
                <div className="mt-2 flex items-start gap-2 p-3 rounded-[12px] bg-amber-500/15 border border-amber-500/30 text-amber-300 text-[12px] font-medium leading-snug">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5 text-amber-400" />
                  <span>
                    Head room is below 50% of floor. Check local building rules for conversion clearance.
                  </span>
                </div>
              )}
            </div>

            {/* Inset List of Measurement Fields */}
            <InsetGroup title="Dimensions & Specifications">
              {pack.measureFields.map((field, idx) => {
                const isLast = idx === pack.measureFields.length - 1;
                const currentVal = measurements[field.id] ?? field.defaultVal;

                if (field.type === 'number' || field.type === 'stepper') {
                  return (
                    <InsetRow
                      key={field.id}
                      label={field.label}
                      helper={field.helper}
                      isLast={isLast}
                      control={
                        <Stepper
                          value={Number(currentVal) || 0}
                          onChange={(val) => setMeasurements((prev) => ({ ...prev, [field.id]: val }))}
                          min={field.min}
                          max={field.max}
                          step={field.step || 1}
                          unit={field.unit}
                          decimals={field.step && field.step < 1 ? 1 : 0}
                        />
                      }
                    />
                  );
                }

                if (field.type === 'segmented' && field.options) {
                  return (
                    <div
                      key={field.id}
                      className={`px-4 py-3.5 ${!isLast ? 'border-b border-white/10' : ''}`}
                    >
                      <div className="mb-2">
                        <span className="text-[16px] font-semibold text-white block">
                          {field.label}
                        </span>
                        <span className="text-[13px] text-white/80 block mt-0.5 font-normal">
                          {field.helper}
                        </span>
                      </div>
                      <SegmentedControl
                        size="sm"
                        value={currentVal}
                        onChange={(val) => setMeasurements((prev) => ({ ...prev, [field.id]: val }))}
                        options={field.options.map((o) => ({
                          value: o.value,
                          label: o.label,
                        }))}
                      />
                    </div>
                  );
                }

                if (field.type === 'picker' && field.options) {
                  const selectedOpt = field.options.find((o) => o.value === currentVal) || field.options[0];
                  return (
                    <InsetRow
                      key={field.id}
                      label={field.label}
                      helper={field.helper}
                      isLast={isLast}
                      onClick={() => {
                        setActivePicker({
                          id: field.id,
                          title: field.label,
                          options: field.options!,
                          selected: currentVal,
                          onSelect: (val) => setMeasurements((prev) => ({ ...prev, [field.id]: val })),
                        });
                      }}
                      control={
                        <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-[16px]">
                          <span>{selectedOpt.label}</span>
                          <ChevronRight className="w-4 h-4 text-white/70" />
                        </div>
                      }
                    />
                  );
                }

                return null;
              })}
            </InsetGroup>

            <ActionBottomBar>
              <PrimaryButton
                label="Next: Questions"
                onClick={handleStep3Next}
              />
            </ActionBottomBar>
          </div>
        )}

        {/* STEP 4: Questions (All on One Page, Grouped) */}
        {step === 4 && (
          <div className="space-y-4">
            <InsetGroup
              title="Site Checks"
              footer={
                unansweredCount > 0
                  ? `${unansweredCount} ${unansweredCount === 1 ? 'question' : 'questions'} left to answer.`
                  : 'All questions answered. Ready to calculate your price.'
              }
            >
              <div className="divide-y divide-white/10">
                {relevantQuestions.map((q) => {
                  const currentAnswer = answers[q.id];
                  const isAnswered = !!currentAnswer;

                  return (
                    <div key={q.id} className="p-4 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <span className="text-[16px] font-bold text-white leading-snug">
                          {q.text}
                        </span>
                        {isAnswered && (
                          <div className="w-5 h-5 rounded-full bg-emerald-400 text-white flex items-center justify-center shrink-0 shadow-[0_0_8px_rgba(52,211,153,0.7)]">
                            <Check className="w-3.5 h-3.5 stroke-[3]" />
                          </div>
                        )}
                      </div>

                      {q.options.length <= 3 ? (
                        <SegmentedControl
                          size="sm"
                          value={currentAnswer || ''}
                          onChange={(val) => setAnswers((prev) => ({ ...prev, [q.id]: val }))}
                          options={q.options.map((opt) => ({
                            value: opt.value,
                            label: opt.label,
                          }))}
                        />
                      ) : (
                        <button
                          type="button"
                          onClick={() => {
                            setActivePicker({
                              id: q.id,
                              title: q.text,
                              options: q.options.map((o) => ({
                                value: o.value,
                                label: o.label,
                                extraCost: o.priceEffect?.amount,
                              })),
                              selected: currentAnswer,
                              onSelect: (val) => setAnswers((prev) => ({ ...prev, [q.id]: val })),
                            });
                          }}
                          className="w-full flex items-center justify-between p-3.5 rounded-[12px] glass-panel text-white font-semibold text-[15px] border border-white/15 hover:bg-white/[0.08] active:scale-[0.985] transition-all"
                        >
                          <span>
                            {q.options.find((o) => o.value === currentAnswer)?.label || 'Choose answer…'}
                          </span>
                          <ChevronRight className="w-4 h-4 text-cyan-400" />
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            </InsetGroup>

            <ActionBottomBar>

              <PrimaryButton
                label="Get price"
                onClick={handleGenerateEstimate}
              />
            </ActionBottomBar>
          </div>
        )}
      </main>

      {/* Reusable Bottom Sheet Picker */}
      {activePicker && (
        <BottomSheet
          isOpen={true}
          onClose={() => setActivePicker(null)}
          title={activePicker.title}
          options={activePicker.options}
          selectedValue={activePicker.selected}
          onSelect={activePicker.onSelect}
        />
      )}
    </div>
  );
};
