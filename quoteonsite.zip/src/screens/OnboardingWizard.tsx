import React, { useState } from 'react';
import {
  Home,
  Layers,
  Shield,
  Sun,
  Utensils,
  Droplet,
  Palette,
  Square,
  Compass,
  Zap,
  Wind,
  Check,
  Upload,
  ChevronRight
} from 'lucide-react';
import { CompanyProfile } from '../types';
import { ALL_TRADE_PACKS, getTradePack } from '../tradePacks';
import { LargeNavBar } from '../components/apple/LargeNavBar';
import { InsetGroup, InsetRow } from '../components/apple/InsetGroup';
import { PrimaryButton } from '../components/apple/PrimaryButton';
import { ActionBottomBar } from '../components/apple/ActionBottomBar';
import { BottomSheet } from '../components/apple/BottomSheet';
import { uploadPastQuote } from '../lib/supabase';

interface OnboardingWizardProps {
  initialProfile: CompanyProfile;
  userId?: string;
  onComplete: (profile: CompanyProfile, goToBrain?: boolean) => void;
  onBackToWelcome?: () => void;
}

const TRADE_ICONS: Record<string, React.ReactNode> = {
  attic: <Home className="w-6 h-6 stroke-[2]" />,
  driveways: <Layers className="w-6 h-6 stroke-[2]" />,
  roofing: <Shield className="w-6 h-6 stroke-[2]" />,
  insulation: <Sun className="w-6 h-6 stroke-[2]" />,
  kitchen: <Utensils className="w-6 h-6 stroke-[2]" />,
  bathroom: <Droplet className="w-6 h-6 stroke-[2]" />,
  painting: <Palette className="w-6 h-6 stroke-[2]" />,
  siding: <Square className="w-6 h-6 stroke-[2]" />,
  landscaping: <Compass className="w-6 h-6 stroke-[2]" />,
  electrical: <Zap className="w-6 h-6 stroke-[2]" />,
  plumbing: <Droplet className="w-6 h-6 stroke-[2]" />,
  hvac: <Wind className="w-6 h-6 stroke-[2]" />
};

const COUNTRY_OPTIONS = [
  { value: 'US', label: 'United States', description: 'USD ($) · Square Feet (sq ft)' },
  { value: 'GB', label: 'United Kingdom', description: 'GBP (£) · Square Meters (m²)' },
  { value: 'IE', label: 'Ireland', description: 'EUR (€) · Square Meters (m²)' },
  { value: 'CA', label: 'Canada', description: 'CAD ($) · Feet & Meters' },
  { value: 'AU', label: 'Australia', description: 'AUD ($) · Square Meters (m²)' },
];

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({
  initialProfile,
  userId,
  onComplete,
  onBackToWelcome
}) => {
  const [step, setStep] = useState(1);
  const totalSteps = 4;
  const [selectedTrade, setSelectedTrade] = useState(initialProfile.primaryTrade || 'attic');
  const [companyName, setCompanyName] = useState(initialProfile.companyName || '');
  const [contractorName, setContractorName] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState(initialProfile.location?.country || 'US');
  const [showCountrySheet, setShowCountrySheet] = useState(false);

  // Rates initialized from trade pack
  const pack = getTradePack(selectedTrade);
  const [hourlyRate, setHourlyRate] = useState(initialProfile.loadedHourlyRate || pack.labourRates.hourlyRate || 55);
  const [crewSize, setCrewSize] = useState(initialProfile.crewSize || pack.labourRates.crewSize || 2);
  const [profitMargin, setProfitMargin] = useState(initialProfile.targetMargin || 35);
  const [overheadPct, setOverheadPct] = useState(initialProfile.overheadPct || 15);
  const [minJobPrice, setMinJobPrice] = useState(initialProfile.avgJobValue || 500);
  const [travelFee, setTravelFee] = useState(initialProfile.travelPricing?.flatFee || 0);

  const [uploadedQuotes, setUploadedQuotes] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  const handleTradeSelect = (tradeId: string) => {
    setSelectedTrade(tradeId);
    const newPack = getTradePack(tradeId);
    setHourlyRate(newPack.labourRates.hourlyRate);
    setCrewSize(newPack.labourRates.crewSize);
    setStep(2);
  };

  const handleFinish = (hasUploaded: boolean) => {
    const finalProfile: CompanyProfile = {
      ...initialProfile,
      companyName: companyName.trim() || `${pack.displayName} Pros`,
      primaryTrade: selectedTrade,
      otherTrades: [selectedTrade],
      location: {
        ...initialProfile.location,
        country: country
      },
      loadedHourlyRate: Number(hourlyRate) || 55,
      billableHourlyRate: Number(hourlyRate) || 55,
      crewSize: Number(crewSize) || 2,
      targetMargin: Number(profitMargin) || 35,
      overheadPct: Number(overheadPct) || 15,
      avgJobValue: Number(minJobPrice) || 500,
      travelPricing: {
        type: travelFee > 0 ? 'flat' : 'free',
        flatFee: Number(travelFee) || 0,
        perMileRate: 0,
        freeRadiusMiles: 25
      },
      isOnboarded: true
    };

    onComplete(finalProfile, hasUploaded);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setIsUploading(true);

    try {
      const file = files[0];
      if (userId) {
        await uploadPastQuote(userId, file);
      }
      setUploadedQuotes((prev) => [...prev, file.name]);
    } catch (err) {
      console.warn('Quote upload error:', err);
      setUploadedQuotes((prev) => [...prev, 'Uploaded quote']);
    } finally {
      setIsUploading(false);
    }
  };

  const selectedCountryObj = COUNTRY_OPTIONS.find((c) => c.value === country) || COUNTRY_OPTIONS[0];

  return (
    <div className="min-h-screen text-white flex flex-col pb-28">
      <LargeNavBar
        title={
          step === 1
            ? 'What work do you do?'
            : step === 2
            ? 'Your business'
            : step === 3
            ? 'Your numbers'
            : 'Teach me your prices'
        }
        subtitle={
          step === 1
            ? 'Pick your trade. Every word adapts to it.'
            : step === 2
            ? 'Enter your business details.'
            : step === 3
            ? 'Set your rates. You can edit anytime in Settings.'
            : 'Add old quotes, or skip for now.'
        }
        backLabel={step > 1 ? 'Back' : undefined}
        onBack={step > 1 ? () => setStep(step - 1) : onBackToWelcome}
        progressPct={(step / totalSteps) * 100}
      />

      <main className="flex-1 max-w-md mx-auto w-full px-4 pt-4">
        {/* Step 1: Big Tappable Trade List */}
        {step === 1 && (
          <div className="space-y-2.5 pb-6">
            {ALL_TRADE_PACKS.map((t) => {
              const isSelected = selectedTrade === t.id;
              return (
                <button
                  key={t.id}
                  type="button"
                  onClick={() => handleTradeSelect(t.id)}
                  className={`w-full flex items-center justify-between p-4 rounded-[18px] transition-all duration-200 min-h-[64px] text-left border ${
                    isSelected
                      ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-[0_0_20px_rgba(56,189,248,0.5)] border-cyan-300/40'
                      : 'glass-panel text-white hover:bg-white/[0.08] active:scale-[0.985] border-white/15'
                  }`}
                >
                  <div className="flex items-center gap-3.5">
                    <div
                      className={`w-12 h-12 rounded-[14px] flex items-center justify-center shrink-0 ${
                        isSelected
                          ? 'bg-white/20 text-white'
                          : 'bg-white/10 text-cyan-300 border border-white/10'
                      }`}
                    >
                      {TRADE_ICONS[t.id] || <Home className="w-6 h-6 stroke-[2]" />}
                    </div>
                    <div>
                      <span className="text-[17px] font-bold text-white block leading-snug">
                        {t.displayName}
                      </span>
                      <span className={`text-[13px] block mt-0.5 ${isSelected ? 'text-white/90' : 'text-white/80'}`}>
                        e.g. {t.jobTypes[0]?.name}
                      </span>
                    </div>
                  </div>

                  {isSelected ? (
                    <div className="w-7 h-7 rounded-full bg-white text-blue-600 flex items-center justify-center shadow-md">
                      <Check className="w-4 h-4 stroke-[3]" />
                    </div>
                  ) : (
                    <ChevronRight className="w-5 h-5 text-white/50" />
                  )}
                </button>
              );
            })}
          </div>
        )}

        {/* Step 2: Your Business */}
        {step === 2 && (
          <div className="space-y-4">
            <InsetGroup title="Company Details">
              <InsetRow
                label="Company name"
                control={
                  <input
                    type="text"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Apex Thermal & Attic Pros"
                    className="text-right text-[17px] font-medium text-white placeholder:text-white/40 bg-transparent outline-none w-48"
                  />
                }
              />
              <InsetRow
                label="Your name"
                control={
                  <input
                    type="text"
                    value={contractorName}
                    onChange={(e) => setContractorName(e.target.value)}
                    placeholder="Sean"
                    className="text-right text-[17px] font-medium text-white placeholder:text-white/40 bg-transparent outline-none w-40"
                  />
                }
              />
              <InsetRow
                label="Phone"
                control={
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="555-0199"
                    className="text-right text-[17px] font-medium text-white placeholder:text-white/40 bg-transparent outline-none w-36"
                  />
                }
              />
              <InsetRow
                label="Country / Region"
                isLast
                onClick={() => setShowCountrySheet(true)}
                control={
                  <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-[16px]">
                    <span>{selectedCountryObj.label}</span>
                    <ChevronRight className="w-4 h-4 text-white/70" />
                  </div>
                }
              />
            </InsetGroup>

            <ActionBottomBar>
              <PrimaryButton
                label="Next: Your numbers"
                onClick={() => setStep(3)}
              />
            </ActionBottomBar>
          </div>
        )}

        {/* Step 3: Your Numbers */}
        {step === 3 && (
          <div className="space-y-4">
            <InsetGroup title="Pricing Defaults" footer="You can change all of these later in Settings.">
              <InsetRow
                label="Hourly rate"
                helper="Cost per worker hour"
                control={
                  <div className="flex items-center gap-1">
                    <span className="text-[17px] text-white/70 font-semibold">$</span>
                    <input
                      type="number"
                      inputMode="decimal"
                      value={hourlyRate}
                      onChange={(e) => setHourlyRate(parseFloat(e.target.value) || 0)}
                      className="text-right text-[17px] font-extrabold text-cyan-300 bg-transparent outline-none w-20 tabular-nums"
                    />
                  </div>
                }
              />
              <InsetRow
                label="Crew size"
                helper="People on a standard job"
                control={
                  <input
                    type="number"
                    inputMode="numeric"
                    value={crewSize}
                    onChange={(e) => setCrewSize(parseInt(e.target.value, 10) || 1)}
                    className="text-right text-[17px] font-extrabold text-white bg-transparent outline-none w-16 tabular-nums"
                  />
                }
              />
              <InsetRow
                label="Profit wanted"
                helper="Profit you want from each job (%)"
                control={
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      inputMode="decimal"
                      value={profitMargin}
                      onChange={(e) => setProfitMargin(parseFloat(e.target.value) || 0)}
                      className="text-right text-[17px] font-extrabold text-emerald-400 bg-transparent outline-none w-16 tabular-nums"
                    />
                    <span className="text-[17px] text-emerald-400 font-bold">%</span>
                  </div>
                }
              />
              <InsetRow
                label="Overhead"
                helper="Van, tools and insurance (%)"
                control={
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      inputMode="decimal"
                      value={overheadPct}
                      onChange={(e) => setOverheadPct(parseFloat(e.target.value) || 0)}
                      className="text-right text-[17px] font-extrabold text-amber-300 bg-transparent outline-none w-16 tabular-nums"
                    />
                    <span className="text-[17px] text-amber-300 font-bold">%</span>
                  </div>
                }
              />
              <InsetRow
                label="Minimum job"
                helper="Smallest job you will take"
                control={
                  <div className="flex items-center gap-1">
                    <span className="text-[17px] text-white/70 font-semibold">$</span>
                    <input
                      type="number"
                      inputMode="decimal"
                      value={minJobPrice}
                      onChange={(e) => setMinJobPrice(parseFloat(e.target.value) || 0)}
                      className="text-right text-[17px] font-extrabold text-cyan-300 bg-transparent outline-none w-20 tabular-nums"
                    />
                  </div>
                }
              />
              <InsetRow
                label="Travel fee"
                helper="Flat trip fee if any"
                isLast
                control={
                  <div className="flex items-center gap-1">
                    <span className="text-[17px] text-white/70 font-semibold">$</span>
                    <input
                      type="number"
                      inputMode="decimal"
                      value={travelFee}
                      onChange={(e) => setTravelFee(parseFloat(e.target.value) || 0)}
                      className="text-right text-[17px] font-extrabold text-white bg-transparent outline-none w-16 tabular-nums"
                    />
                  </div>
                }
              />
            </InsetGroup>

            <ActionBottomBar>
              <PrimaryButton
                label="Next: Teach me your prices"
                onClick={() => setStep(4)}
              />
            </ActionBottomBar>
          </div>
        )}

        {/* Step 4: Teach Me Your Prices */}
        {step === 4 && (
          <div className="space-y-4">
            <div className="glass-panel rounded-[22px] p-6 text-center border border-white/15 shadow-xl relative overflow-hidden">
              <div className="w-16 h-16 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 flex items-center justify-center mx-auto mb-3 shadow-[0_0_20px_rgba(34,211,238,0.3)]">
                <Upload className="w-7 h-7 stroke-[2.2]" />
              </div>
              <h2 className="text-[20px] font-bold text-white mb-1">
                Add old quotes
              </h2>
              <p className="text-[14px] text-white/80 leading-relaxed max-w-xs mx-auto mb-5">
                Upload up to 3 past invoices or quotes. I will learn your prices and line items.
              </p>

              <label className="inline-flex items-center justify-center gap-2 h-12 px-6 rounded-[14px] bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-[15px] cursor-pointer active:scale-95 transition-all shadow-[0_0_20px_rgba(56,189,248,0.4)] hover:shadow-[0_0_28px_rgba(56,189,248,0.6)]">
                <Upload className="w-4 h-4 stroke-[2.5]" />
                <span>Choose quote files (PDF/Image)</span>
                <input
                  type="file"
                  accept="application/pdf,image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>

              {uploadedQuotes.length > 0 && (
                <div className="mt-4 space-y-2 text-left">
                  {uploadedQuotes.map((name, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between text-[14px] glass-panel px-3.5 py-2.5 rounded-[12px] border border-white/10"
                    >
                      <span className="truncate text-white font-medium">{name}</span>
                      <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                    </div>
                  ))}
                </div>
              )}
            </div>

            <ActionBottomBar>
              <div className="flex flex-col sm:flex-row gap-2.5">
                <PrimaryButton
                  label="Skip for now"
                  variant="secondary"
                  onClick={() => handleFinish(false)}
                  className="w-full sm:w-1/2"
                />
                <PrimaryButton
                  label={uploadedQuotes.length > 0 ? "Save & start quoting" : "Start making quotes"}
                  onClick={() => handleFinish(uploadedQuotes.length > 0)}
                  className="w-full sm:w-1/2"
                />
              </div>
            </ActionBottomBar>
          </div>
        )}
      </main>

      {/* Country Bottom Sheet */}
      <BottomSheet
        isOpen={showCountrySheet}
        onClose={() => setShowCountrySheet(false)}
        title="Select Country / Region"
        options={COUNTRY_OPTIONS}
        selectedValue={country}
        onSelect={(val) => setCountry(val)}
      />
    </div>
  );
};

