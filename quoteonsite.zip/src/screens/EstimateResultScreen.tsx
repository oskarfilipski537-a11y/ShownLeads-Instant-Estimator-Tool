import React, { useState } from 'react';
import {
  ChevronLeft,
  Share2,
  Download,
  CheckCircle2,
  XCircle,
  Plus,
  Trash2,
  ChevronDown,
  ChevronUp,
  ShieldCheck,
  Check,
  Copy,
  Clock,
  Layers,
  Sparkles,
  Award,
  Zap,
  ArrowRight
} from 'lucide-react';
import confetti from 'canvas-confetti';
import jsPDF from 'jspdf';
import {
  CompanyProfile,
  Estimate,
  PricingProfile,
  PricingRule,
} from '../types';
import { getTradePack } from '../tradePacks';
import { formatMoney } from '../lib/units';
import { SegmentedControl } from '../components/apple/SegmentedControl';
import { PrimaryButton } from '../components/apple/PrimaryButton';
import { ActionBottomBar } from '../components/apple/ActionBottomBar';
import { saveEstimateToSupabase } from '../services/supabaseData';

interface EstimateResultScreenProps {
  estimate: Estimate;
  company: CompanyProfile;
  pricingProfile: PricingProfile;
  activeRules: PricingRule[];
  onBack: () => void;
  onUpdateEstimate: (updated: Estimate) => void;
  onMarkOutcome: (id: string, status: 'won' | 'lost', soldPrice?: number) => void;
}

export const EstimateResultScreen: React.FC<EstimateResultScreenProps> = ({
  estimate: initialEstimate,
  company,
  pricingProfile,
  activeRules,
  onBack,
  onUpdateEstimate,
  onMarkOutcome,
}) => {
  const pack = getTradePack(company.primaryTrade);
  const [estimate, setEstimate] = useState<Estimate>(initialEstimate);
  const [viewMode, setViewMode] = useState<'you' | 'customer'>('you');
  const [priceType, setPriceType] = useState<'exact' | 'range'>('exact');
  const [selectedTier, setSelectedTier] = useState<'basic' | 'nice' | 'top'>('nice');
  const [showCompareSheet, setShowCompareSheet] = useState(false);
  const [showMarkAsMenu, setShowMarkAsMenu] = useState(false);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Triggered Risk Checks with "Done" status
  const triggeredRisks = pack.riskChecks.filter((rc) =>
    rc.triggeredIf(estimate.answers || {}, estimate.measurements || {})
  );
  const [resolvedRisks, setResolvedRisks] = useState<Record<string, boolean>>({});

  // Active package details
  const activePackage =
    estimate.options?.[selectedTier === 'basic' ? 'good' : selectedTier === 'nice' ? 'better' : 'best'];

  // Current numbers strictly reconciling: price = costs + profit
  const currentPrice = activePackage?.total || estimate.total || 0;
  const currentCostBase = activePackage?.breakdown?.subtotalCosts || estimate.costBreakdown?.subtotalCosts || Math.round(currentPrice * 0.65);
  const currentProfit = currentPrice - currentCostBase;
  const currentMarginPct = currentPrice > 0 ? Number(((currentProfit / currentPrice) * 100).toFixed(1)) : 35;
  const crewDays = activePackage?.breakdown?.crewDays || estimate.costBreakdown?.crewDays || 12;

  // Confidence
  const confidenceLevel = estimate.costBreakdown?.confidence || 'medium';
  const confidenceScore = estimate.costBreakdown?.confidenceScore || 75;
  const confidenceReason = estimate.costBreakdown?.confidenceReasons?.[0] || 'Take 2 more photos to reach High.';

  // Customer View Signature
  const [typedSignName, setTypedSignName] = useState('');
  const [signedDate, setSignedDate] = useState<string | null>(null);

  const handleSignQuote = () => {
    if (!typedSignName.trim()) return;
    const nowStr = new Date().toLocaleDateString('en-US', {
      month: 'long',
      day: 'numeric',
      year: 'numeric',
    });
    setSignedDate(nowStr);
    try {
      confetti({ particleCount: 70, spread: 70 });
    } catch (e) {}

    const updated: Estimate = {
      ...estimate,
      status: 'won',
      signature: {
        signerName: typedSignName,
        signatureDataUrl: 'typed',
        timestamp: Date.now(),
      },
    };
    setEstimate(updated);
    onUpdateEstimate(updated);
    saveEstimateToSupabase(updated);
  };

  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const generateShoppingListText = () => {
    const lines = [`Shopping List for ${estimate.customerName}:`];
    estimate.lineItems
      .filter((li) => li.category === 'materials')
      .forEach((li) => {
        lines.push(`• ${li.name}: ${li.quantity} ${li.unit}`);
      });
    return lines.join('\n');
  };

  const generateCrewPlanText = () => {
    const lines = [
      `Crew Plan for ${estimate.customerName}:`,
      `• Work time: ${crewDays} days`,
      `• Crew size: ${company.crewSize || 2} workers`,
      `• Job type: ${estimate.measurements?.jobTypeName || pack.jobTypes[0]?.name}`,
      `• Site address: ${estimate.customerAddress}`,
    ];
    return lines.join('\n');
  };

  const handleExportPDF = () => {
    const doc = new jsPDF();
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(22);
    doc.text(company.companyName, 20, 25);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(12);
    doc.text(`Customer: ${estimate.customerName || estimate.customer?.name || 'Customer'}`, 20, 38);
    doc.text(`Job Address: ${estimate.customerAddress || estimate.customer?.address || 'On-site'}`, 20, 46);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 54);

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(18);
    doc.text(`Total Investment: ${formatMoney(currentPrice)}`, 20, 70);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.text("What's Included:", 20, 85);
    const included = pack.customerWording.whatsIncluded(
      estimate.measurements?.jobTypeId || 'bedroom',
      selectedTier
    );
    included.forEach((item, i) => {
      doc.text(`• ${item}`, 24, 95 + i * 8);
    });

    doc.text(`Warranty: ${company.warranty || '10-Year'} warranty on all materials and labour.`, 20, 160);
    doc.text(`Payment: ${company.paymentTerms || 'Pay when the job is done.'}`, 20, 170);

    const safeFileName = (estimate.customerName || estimate.customer?.name || 'Customer').replace(/\s+/g, '_');
    doc.save(`${safeFileName}_Quote.pdf`);
  };

  return (
    <div className="min-h-screen text-white pb-28 select-none">
      {/* Top Header Row with Glass Blur */}
      <header className="sticky top-0 z-30 apple-nav-blur border-b border-white/15 px-4 py-3">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1 text-cyan-300 text-[17px] font-bold active:opacity-70 -ml-1 py-1"
          >
            <ChevronLeft className="w-6 h-6 stroke-[2.5]" />
            <span>Quotes</span>
          </button>

          {/* Segmented Control: You | Customer */}
          <div className="w-44">
            <SegmentedControl
              size="sm"
              value={viewMode}
              onChange={(val) => setViewMode(val as any)}
              options={[
                { value: 'you', label: 'You' },
                { value: 'customer', label: 'Customer' },
              ]}
            />
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={handleExportPDF}
              className="p-2 rounded-full bg-white/10 border border-white/20 text-white active:scale-95 shadow-sm"
              title="Download PDF"
              aria-label="Download PDF"
            >
              <Download className="w-5 h-5 stroke-[2]" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-md mx-auto px-4 pt-4 space-y-5">
        {/* Customer & Address Header (Crisp White Text) */}
        <div>
          <h1 className="text-[28px] sm:text-[30px] font-extrabold text-white truncate leading-tight tracking-tight">
            {estimate.customerName || estimate.customer?.name || 'Customer quote'}
          </h1>
          <p className="text-[15px] text-white/90 font-medium truncate mt-0.5">
            {estimate.customerAddress || estimate.customer?.address || 'On-site property inspection'}
          </p>
        </div>

        {/* ================= YOU VIEW ================= */}
        {viewMode === 'you' && (
          <div className="space-y-5">
            {/* 1. HERO CARD: Atmospheric Glass with Glowing Accents */}
            <div className="p-5 rounded-[22px] glass-panel border-white/20 shadow-xl relative overflow-hidden space-y-4">
              <div className="absolute -top-12 -right-12 w-44 h-44 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />

              <div className="flex items-center justify-between">
                <span className="text-[13px] font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
                  <span>Your price</span>
                </span>
                <div className="w-32">
                  <SegmentedControl
                    size="sm"
                    value={priceType}
                    onChange={(val) => setPriceType(val as any)}
                    options={[
                      { value: 'exact', label: 'Exact' },
                      { value: 'range', label: 'Range' },
                    ]}
                  />
                </div>
              </div>

              {/* Big Luminous Price */}
              <div>
                <div className="text-[44px] sm:text-[48px] font-black tracking-tight text-white tabular-nums leading-none drop-shadow-md">
                  {priceType === 'exact'
                    ? formatMoney(currentPrice)
                    : `${formatMoney(Math.round(currentPrice * 0.95))} – ${formatMoney(Math.round(currentPrice * 1.05))}`}
                </div>
              </div>

              {/* Reconciled Stats Pill Row */}
              <div className="grid grid-cols-3 gap-2 pt-3 border-t border-white/15">
                <div className="p-2.5 rounded-[14px] bg-white/[0.06] border border-white/10 text-left">
                  <span className="text-[12px] text-white/80 font-medium block">
                    Your costs
                  </span>
                  <span className="text-[18px] font-extrabold text-white tabular-nums block mt-0.5">
                    {formatMoney(currentCostBase)}
                  </span>
                </div>

                <div className="p-2.5 rounded-[14px] bg-emerald-500/15 border border-emerald-400/30 text-left">
                  <span className="text-[12px] text-emerald-200 font-semibold block">
                    Your profit
                  </span>
                  <span className="text-[18px] font-extrabold text-emerald-300 tabular-nums block mt-0.5">
                    {formatMoney(currentProfit)} <span className="text-[12px] font-bold">({currentMarginPct}%)</span>
                  </span>
                </div>

                <div className="p-2.5 rounded-[14px] bg-blue-500/15 border border-blue-400/30 text-left">
                  <span className="text-[12px] text-cyan-200 font-semibold block">
                    Work time
                  </span>
                  <span className="text-[18px] font-extrabold text-cyan-300 tabular-nums block mt-0.5">
                    {crewDays} days
                  </span>
                </div>
              </div>
            </div>

            {/* Confidence Banner with White Text */}
            <div className="p-4 rounded-[18px] glass-panel border-white/15 shadow-md flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[15px] font-bold text-white">
                    Confidence:
                  </span>
                  <span
                    className={`text-[13px] font-extrabold uppercase tracking-wide px-2.5 py-0.5 rounded-full ${
                      confidenceLevel === 'high'
                        ? 'bg-emerald-500/25 border border-emerald-400/50 text-emerald-300'
                        : confidenceLevel === 'medium'
                        ? 'bg-amber-500/25 border border-amber-400/50 text-amber-300'
                        : 'bg-rose-500/25 border border-rose-400/50 text-rose-300'
                    }`}
                  >
                    {confidenceLevel} ({confidenceScore}%)
                  </span>
                </div>
                <p className="text-[13px] text-white font-medium mt-1">
                  {confidenceReason}
                </p>
              </div>
            </div>

            {/* 4. OPTION PACKAGES: Colourful, Glassy, Animated Columns */}
            <div className="space-y-2.5">
              <div className="flex items-center justify-between px-1">
                <h2 className="text-[14px] font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-purple-400" />
                  <span>Pick a package</span>
                </h2>
                <button
                  type="button"
                  onClick={() => setShowCompareSheet(!showCompareSheet)}
                  className="text-[13px] text-cyan-300 font-bold active:opacity-75"
                >
                  {showCompareSheet ? 'Hide compare' : 'Compare'}
                </button>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                {(['basic', 'nice', 'top'] as const).map((tierKey) => {
                  const isSelected = selectedTier === tierKey;
                  const tierOption =
                    estimate.options?.[tierKey === 'basic' ? 'good' : tierKey === 'nice' ? 'better' : 'best'];
                  const tierPrice = tierOption?.total || currentPrice;
                  const tierBullets = tierOption?.inclusions || [];

                  let borderGradient = 'border-white/15';
                  let headerColor = 'text-white';
                  let bgTint = 'bg-white/[0.06]';

                  if (tierKey === 'basic') {
                    borderGradient = isSelected ? 'border-cyan-400 ring-2 ring-cyan-400/60 shadow-lg shadow-cyan-950/40' : 'border-cyan-400/30';
                    bgTint = isSelected ? 'bg-gradient-to-b from-cyan-500/25 via-blue-500/10 to-white/[0.08]' : 'bg-gradient-to-b from-cyan-500/10 to-white/[0.04]';
                    headerColor = 'text-cyan-300';
                  } else if (tierKey === 'nice') {
                    borderGradient = isSelected ? 'border-purple-400 ring-2 ring-purple-400/60 shadow-lg shadow-purple-950/50' : 'border-purple-400/35';
                    bgTint = isSelected ? 'bg-gradient-to-b from-purple-500/30 via-indigo-500/15 to-white/[0.08]' : 'bg-gradient-to-b from-purple-500/15 to-white/[0.04]';
                    headerColor = 'text-purple-300';
                  } else if (tierKey === 'top') {
                    borderGradient = isSelected ? 'border-amber-400 ring-2 ring-amber-400/60 shadow-lg shadow-amber-950/40' : 'border-amber-400/35';
                    bgTint = isSelected ? 'bg-gradient-to-b from-amber-500/25 via-orange-500/10 to-white/[0.08]' : 'bg-gradient-to-b from-amber-500/10 to-white/[0.04]';
                    headerColor = 'text-amber-300';
                  }

                  return (
                    <button
                      key={tierKey}
                      type="button"
                      onClick={() => setSelectedTier(tierKey)}
                      className={`p-3.5 rounded-[20px] text-left transition-all duration-200 flex flex-col justify-between min-h-[160px] border backdrop-blur-xl relative overflow-hidden active:scale-[0.97] ${borderGradient} ${bgTint}`}
                    >
                      <div>
                        {/* Only ONE badge max */}
                        {tierKey === 'nice' && (
                          <span className="inline-block text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-purple-500 text-white shadow-sm mb-1.5">
                            Popular
                          </span>
                        )}
                        {tierKey === 'top' && (
                          <span className="inline-block text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-500/90 text-white shadow-sm mb-1.5">
                            Luxury
                          </span>
                        )}
                        {tierKey === 'basic' && (
                          <span className="inline-block text-[10px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/80 text-white shadow-sm mb-1.5">
                            Essential
                          </span>
                        )}
                        <span className={`text-[16px] font-extrabold block capitalize leading-tight ${headerColor}`}>
                          {tierKey}
                        </span>
                        <span className="text-[18px] font-black text-white tabular-nums block mt-1">
                          {formatMoney(tierPrice)}
                        </span>
                      </div>

                      <div className="text-[12px] text-white font-medium space-y-1 mt-2.5 line-clamp-3">
                        {tierBullets.slice(0, 2).map((b: string, i: number) => (
                          <div key={i} className="truncate text-white/90">
                            • {b}
                          </div>
                        ))}
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Compare Sheet Table */}
              {showCompareSheet && (
                <div className="p-4 rounded-[18px] glass-panel border-white/20 text-[13px] space-y-2 mt-2">
                  <div className="font-bold text-white pb-1.5 border-b border-white/15">
                    Package Scope Comparison
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[12px] font-semibold text-white/90">
                    <div className="p-2 rounded-[10px] bg-cyan-500/10 border border-cyan-400/20">Basic: essentials & boards</div>
                    <div className="p-2 rounded-[10px] bg-purple-500/10 border border-purple-400/20">Nice: dormer window & heating</div>
                    <div className="p-2 rounded-[10px] bg-amber-500/10 border border-amber-400/20">Top: private ensuite bathroom</div>
                  </div>
                </div>
              )}
            </div>

            {/* 5. Check before you start (Triggered items only, White text) */}
            {triggeredRisks.length > 0 && (
              <div className="space-y-2">
                <h2 className="text-[14px] font-bold text-white uppercase tracking-wider px-1 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Check before you start</span>
                </h2>
                <div className="glass-panel rounded-[18px] border-white/15 divide-y divide-white/10 overflow-hidden shadow-lg">
                  {triggeredRisks.map((risk) => {
                    const isDone = !!resolvedRisks[risk.id];
                    return (
                      <div key={risk.id} className="p-4 flex items-center justify-between">
                        <div className="flex-1 pr-3">
                          <span
                            className={`text-[16px] font-bold block leading-tight ${
                              isDone ? 'line-through text-white/50' : 'text-white'
                            }`}
                          >
                            {risk.title}
                          </span>
                          <span className="text-[13px] text-white/90 block mt-0.5 leading-snug font-medium">
                            {risk.detail}
                          </span>
                        </div>
                        <button
                          type="button"
                          onClick={() =>
                            setResolvedRisks((prev) => ({
                              ...prev,
                              [risk.id]: !prev[risk.id],
                            }))
                          }
                          className={`h-10 px-4 rounded-[12px] font-bold text-[13px] transition-all shrink-0 active:scale-95 ${
                            isDone
                              ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/30'
                              : 'bg-white/15 border border-white/25 text-white active:bg-white/25'
                          }`}
                        >
                          {isDone ? 'Done' : 'Mark done'}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 6. Where the money goes: Glassy list with White text */}
            <div className="space-y-2">
              <h2 className="text-[14px] font-bold text-white uppercase tracking-wider px-1">
                Where the money goes
              </h2>
              <div className="glass-panel rounded-[18px] border-white/15 divide-y divide-white/10 overflow-hidden shadow-lg">
                {estimate.lineItems.map((item) => (
                  <div key={item.id} className="p-4 flex items-center justify-between">
                    <div>
                      <span className="text-[16px] font-bold text-white block truncate max-w-[220px]">
                        {item.name}
                      </span>
                      <span className="text-[13px] text-white/80 block font-medium">
                        {item.quantity} {item.unit} · {item.category}
                      </span>
                    </div>
                    <span className="text-[17px] font-extrabold text-white tabular-nums">
                      {formatMoney(item.total)}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* 7. Shopping List & Crew Plan Sharing (Glass buttons with White text) */}
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => handleCopyText(generateShoppingListText(), 'materials')}
                className="p-4 rounded-[16px] glass-panel-interactive border-white/20 text-left shadow-md"
              >
                <span className="text-[15px] font-bold text-white block">
                  Shopping list
                </span>
                <span className="text-[13px] text-cyan-300 font-bold block mt-1">
                  {copiedText === 'materials' ? 'Copied!' : 'Copy to text'}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handleCopyText(generateCrewPlanText(), 'crew')}
                className="p-4 rounded-[16px] glass-panel-interactive border-white/20 text-left shadow-md"
              >
                <span className="text-[15px] font-bold text-white block">
                  Crew plan
                </span>
                <span className="text-[13px] text-cyan-300 font-bold block mt-1">
                  {copiedText === 'crew' ? 'Copied!' : 'Copy to text'}
                </span>
              </button>
            </div>

            {/* Bottom Action Bar: Send Quote & Mark As */}
            <ActionBottomBar>
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setViewMode('customer')}
                  className="flex-1 h-[52px] rounded-[16px] bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white font-extrabold text-[17px] flex items-center justify-center gap-2 shadow-lg shadow-blue-900/40 border border-white/25 active:scale-[0.98]"
                >
                  <span>Send quote</span>
                  <ArrowRight className="w-5 h-5 stroke-[2.5]" />
                </button>
                <button
                  type="button"
                  onClick={() => setShowMarkAsMenu(!showMarkAsMenu)}
                  className="h-[52px] px-4 rounded-[16px] glass-panel text-white font-bold text-[15px] flex items-center justify-center shrink-0 border border-white/25 active:scale-95"
                >
                  <span>Mark as</span>
                </button>
              </div>

              {/* Mark As Menu */}
              {showMarkAsMenu && (
                <div className="mt-2.5 p-2 glass-panel border-white/25 rounded-[16px] shadow-2xl flex items-center justify-around">
                  <button
                    type="button"
                    onClick={() => {
                      onMarkOutcome(estimate.id, 'won', currentPrice);
                      setShowMarkAsMenu(false);
                    }}
                    className="flex-1 py-2.5 text-[15px] font-extrabold text-emerald-300 text-center active:opacity-75"
                  >
                    Won
                  </button>
                  <div className="w-[1px] h-6 bg-white/20" />
                  <button
                    type="button"
                    onClick={() => {
                      onMarkOutcome(estimate.id, 'lost');
                      setShowMarkAsMenu(false);
                    }}
                    className="flex-1 py-2.5 text-[15px] font-extrabold text-rose-400 text-center active:opacity-75"
                  >
                    Lost
                  </button>
                </div>
              )}
            </ActionBottomBar>
          </div>
        )}

        {/* ================= CUSTOMER VIEW (Crisp White Text, Polished Proposal) ================= */}
        {viewMode === 'customer' && (
          <div className="space-y-5">
            <div className="p-6 rounded-[22px] glass-panel border-white/20 shadow-2xl space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between border-b border-white/15 pb-4">
                <div>
                  <h2 className="text-[22px] font-extrabold text-white">
                    {company.companyName}
                  </h2>
                  <p className="text-[14px] text-cyan-300 font-semibold mt-0.5">
                    {pack.displayName}
                  </p>
                </div>
                <div className="text-right text-[13px] text-white/80 font-medium">
                  <div>Valid for 30 days</div>
                  <div className="font-bold text-white">#{estimate.id.slice(-6).toUpperCase()}</div>
                </div>
              </div>

              {/* Big Customer Price */}
              <div className="text-center py-2">
                <span className="text-[13px] font-bold text-white uppercase tracking-wider block mb-1">
                  Fixed Investment
                </span>
                <span className="text-[48px] font-black tracking-tight text-white tabular-nums block drop-shadow-md">
                  {formatMoney(currentPrice)}
                </span>
                <span className="text-[14px] text-white/90 font-medium block mt-1">
                  All labor, materials and site cleanup included.
                </span>
              </div>

              {/* What's Included */}
              <div className="space-y-2.5 border-t border-white/15 pt-4">
                <h3 className="text-[16px] font-extrabold text-white">
                  What's included
                </h3>
                <div className="space-y-2">
                  {pack.customerWording
                    .whatsIncluded(estimate.measurements?.jobTypeId || 'bedroom', selectedTier)
                    .map((item, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 text-[15px] text-white font-medium leading-snug">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5 stroke-[3]" />
                        <span>{item}</span>
                      </div>
                    ))}
                </div>
              </div>

              {/* What's Not Included */}
              <div className="space-y-2 border-t border-white/15 pt-4">
                <h3 className="text-[16px] font-extrabold text-white">
                  What's not included
                </h3>
                <div className="space-y-1.5 text-[14px] text-white/80 font-medium">
                  {pack.customerWording.whatsNotIncluded.map((item, idx) => (
                    <div key={idx}>• {item}</div>
                  ))}
                </div>
              </div>

              {/* Work Schedule & Pay */}
              <div className="grid grid-cols-2 gap-3 border-t border-white/15 pt-4 text-[14px]">
                <div>
                  <span className="font-bold text-white block">Work schedule</span>
                  <span className="text-white/80 font-medium">
                    Starts in 1–2 weeks · Takes ~{crewDays} working days
                  </span>
                </div>
                <div>
                  <span className="font-bold text-white block">Payment</span>
                  <span className="text-white/80 font-medium">
                    {company.paymentTerms || 'Pay when the job is done.'}
                  </span>
                </div>
              </div>

              {/* Warranty */}
              <div className="border-t border-white/15 pt-4 text-[14px]">
                <span className="font-bold text-white block">Warranty</span>
                <span className="text-white/80 font-medium">
                  {company.warranty || '10-Year'} full warranty on materials and workmanship.
                </span>
              </div>

              {/* Sign & Accept */}
              <div className="border-t border-white/15 pt-4 space-y-3">
                <h3 className="text-[16px] font-extrabold text-white">
                  Accept quote
                </h3>

                {signedDate ? (
                  <div className="p-4 rounded-[14px] bg-emerald-500/25 border border-emerald-400/40 text-emerald-200 text-[15px] font-bold text-center shadow-lg">
                    Accepted and signed by {typedSignName} on {signedDate}
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    <input
                      type="text"
                      value={typedSignName}
                      onChange={(e) => setTypedSignName(e.target.value)}
                      placeholder="Type your full name to sign"
                      className="w-full h-12 px-4 rounded-[14px] bg-white/10 text-[16px] text-white placeholder:text-white/50 outline-none border border-white/20 focus:border-cyan-400"
                    />
                    <PrimaryButton
                      label="Sign & accept"
                      onClick={handleSignQuote}
                      disabled={!typedSignName.trim()}
                    />
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
