import React, { useState, useRef } from 'react';
import {
  Upload,
  Check,
  Plus,
  Trash2,
  Edit2,
  DollarSign,
  Layers,
  ChevronRight,
  X
} from 'lucide-react';
import { PastQuote, PriceListItem, PricingProfile, PricingRule, CompanyProfile } from '../types';
import { getTradePack } from '../tradePacks';
import { formatMoney } from '../lib/units';
import { InsetGroup, InsetRow } from '../components/apple/InsetGroup';
import { SegmentedControl } from '../components/apple/SegmentedControl';
import { PrimaryButton } from '../components/apple/PrimaryButton';
import { uploadPastQuote } from '../lib/supabase';
import { savePastQuoteToSupabase } from '../services/supabaseData';

interface PricingBrainScreenProps {
  company: CompanyProfile;
  pricingProfile: PricingProfile;
  priceList: PriceListItem[];
  rules: PricingRule[];
  userId?: string;
  companyId?: string;
  onUpdatePricingProfile: (profile: PricingProfile) => void;
  onUpdatePriceList: (items: PriceListItem[]) => void;
  onUpdateRules: (rules: PricingRule[]) => void;
}

export const PricingBrainScreen: React.FC<PricingBrainScreenProps> = ({
  company,
  pricingProfile,
  priceList,
  rules,
  userId,
  companyId,
  onUpdatePricingProfile,
  onUpdatePriceList,
  onUpdateRules,
}) => {
  const pack = getTradePack(company.primaryTrade);
  const [activeTab, setActiveTab] = useState<'quotes' | 'rates' | 'materials' | 'rules'>('quotes');
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // New Rule form modal
  const [showAddRuleModal, setShowAddRuleModal] = useState(false);
  const [ruleCondition, setRuleCondition] = useState('');
  const [ruleAmount, setRuleAmount] = useState('');

  // Editing Material modal
  const [editingItem, setEditingItem] = useState<PriceListItem | null>(null);

  const pastQuotes = pricingProfile.pastQuotes || [];
  const quotesCount = pastQuotes.length;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      if (userId) {
        await uploadPastQuote(userId, file, file.name);
      }

      const newQuote: PastQuote = {
        id: `pq_${Date.now()}`,
        title: file.name.replace(/\.[^/.]+$/, ''),
        fileName: file.name,
        date: new Date().toISOString().split('T')[0],
        jobType: pack.jobTypes[0]?.name || 'Standard Job',
        customerName: 'Customer',
        totalAmount: 4500,
        sqFt: 20,
        scopeNotes: '',
        lineItems: [],
        confirmed: true,
      };

      const updatedQuotes = [...pastQuotes, newQuote];
      onUpdatePricingProfile({
        ...pricingProfile,
        pastQuotes: updatedQuotes,
      });

      if (companyId) {
        savePastQuoteToSupabase(companyId, newQuote);
      }
    } catch (err) {
      console.warn('File upload warning:', err);
    } finally {
      setIsUploading(false);
    }
  };

  const handleAddRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleCondition.trim() || !ruleAmount) return;

    const newRule: PricingRule = {
      id: `rule_${Date.now()}`,
      name: `If ${ruleCondition.trim()}, add $${ruleAmount}`,
      condition: ruleCondition.trim(),
      adjustmentType: 'fixed_dollar',
      adjustmentValue: parseFloat(ruleAmount) || 0,
      active: true,
      category: 'materials',
    };

    onUpdateRules([...rules, newRule]);
    setShowAddRuleModal(false);
    setRuleCondition('');
    setRuleAmount('');
  };

  const handleDeleteRule = (id: string) => {
    onUpdateRules(rules.filter((r) => r.id !== id));
  };

  return (
    <div className="min-h-screen text-white pb-32 px-4 pt-4 max-w-md mx-auto w-full">
      {/* Large Title */}
      <div className="pt-2 pb-3">
        <h1 className="text-[34px] font-extrabold tracking-tight text-white drop-shadow-sm">
          Your prices
        </h1>
        <p className="text-[14px] text-white/80 font-normal mt-0.5">
          Tune your rates, trade materials, and custom rules
        </p>
      </div>

      <div className="space-y-4">
        {/* Top Card in Plain Words */}
        <div className="p-5 rounded-[22px] glass-panel border border-white/15 shadow-xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-cyan-500/20 to-transparent rounded-bl-full pointer-events-none" />
          <p className="text-[17px] font-bold text-white leading-snug drop-shadow-sm">
            {quotesCount > 0
              ? `I know your prices from ${quotesCount} quotes. Add ${Math.max(1, 5 - quotesCount)} more to be more sure.`
              : 'Add old quotes. I will learn your prices.'}
          </p>
          <div className="flex items-center gap-2 mt-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_rgba(34,211,238,0.8)]" />
            <p className="text-[13px] text-cyan-300 font-semibold tracking-wide">
              Active trade: {pack.displayName}
            </p>
          </div>
        </div>

        {/* Tab Selection */}
        <SegmentedControl
          size="sm"
          value={activeTab}
          onChange={(val) => setActiveTab(val as any)}
          options={[
            { value: 'quotes', label: 'Old quotes' },
            { value: 'rates', label: 'Your rates' },
            { value: 'materials', label: 'Materials' },
            { value: 'rules', label: 'My rules' },
          ]}
        />

        {/* 1. Old Quotes */}
        {activeTab === 'quotes' && (
          <div className="space-y-3">
            <div className="glass-panel rounded-[20px] p-6 text-center border border-white/15 shadow-xl space-y-3">
              <p className="text-[16px] font-bold text-white">
                Upload invoices, quotes or scans
              </p>
              <p className="text-[13px] text-white/80 max-w-xs mx-auto">
                AI extracts your labor rates and material margins automatically.
              </p>
              <label className="inline-flex items-center gap-2 h-12 px-6 rounded-[14px] bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-[15px] cursor-pointer active:scale-95 transition-all shadow-[0_0_20px_rgba(56,189,248,0.4)] hover:shadow-[0_0_28px_rgba(56,189,248,0.6)]">
                <Upload className="w-4 h-4 stroke-[2.5]" />
                <span>{isUploading ? 'Reading quote…' : 'Add old quote'}</span>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="application/pdf,image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>

            {pastQuotes.length > 0 ? (
              <InsetGroup title="Learned Habits">
                {pastQuotes.map((q) => (
                  <InsetRow
                    key={q.id}
                    label={q.title || 'Past Quote'}
                    helper={`You charged about $${q.totalAmount.toLocaleString()} · ${q.jobType}`}
                    control={
                      <span className="text-[16px] font-extrabold text-cyan-300 tabular-nums">
                        {formatMoney(q.totalAmount)}
                      </span>
                    }
                  />
                ))}
              </InsetGroup>
            ) : (
              <div className="p-5 rounded-[20px] glass-panel border border-white/15 text-center text-[14px] text-white/80 font-medium">
                No past quotes added yet.
              </div>
            )}
          </div>
        )}

        {/* 2. Your Rates */}
        {activeTab === 'rates' && (
          <div className="space-y-3">
            <InsetGroup title="Productivity & Labor">
              <InsetRow
                label="Worker rate"
                helper="Hourly rate per technician"
                control={
                  <span className="text-[17px] font-extrabold text-cyan-300 tabular-nums">
                    ${company.loadedHourlyRate || pack.labourRates.hourlyRate} / hr
                  </span>
                }
              />
              <InsetRow
                label="Crew size"
                helper="Typical workers on site"
                control={
                  <span className="text-[17px] font-bold text-white tabular-nums">
                    {company.crewSize || pack.labourRates.crewSize} people
                  </span>
                }
              />
              <InsetRow
                label="Target profit"
                helper="Profit you want from each job"
                control={
                  <span className="text-[17px] font-extrabold text-emerald-400 tabular-nums">
                    {company.targetMargin || 35}%
                  </span>
                }
              />
              <InsetRow
                label="Overhead"
                helper="Van, tools and insurance"
                isLast
                control={
                  <span className="text-[17px] font-bold text-amber-300 tabular-nums">
                    {company.overheadPct || 15}%
                  </span>
                }
              />
            </InsetGroup>
          </div>
        )}

        {/* 3. Your Materials */}
        {activeTab === 'materials' && (
          <div className="space-y-3">
            <InsetGroup title="Price Book" footer="Default unit costs used for your estimates.">
              {pack.priceBook.map((item, idx) => (
                <InsetRow
                  key={item.id}
                  label={item.name}
                  helper={`Per ${item.unit} · ${item.category}`}
                  isLast={idx === pack.priceBook.length - 1}
                  control={
                    <span className="text-[16px] font-extrabold text-cyan-300 tabular-nums">
                      ${item.defaultCost}
                    </span>
                  }
                />
              ))}
            </InsetGroup>
          </div>
        )}

        {/* 4. My Rules */}
        {activeTab === 'rules' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between px-2">
              <span className="text-[13px] font-bold text-white/90 tracking-wider uppercase">
                My rules
              </span>
              <button
                type="button"
                onClick={() => setShowAddRuleModal(true)}
                className="text-[13px] text-cyan-400 font-bold flex items-center gap-1 active:opacity-75"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>Add rule</span>
              </button>
            </div>

            <div className="glass-panel rounded-[20px] border border-white/15 divide-y divide-white/10 shadow-xl overflow-hidden">
              {/* Example rule */}
              <div className="p-4 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[15px] font-bold text-white">
                      If stairs need a turn, add $1,800.
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                      Example
                    </span>
                  </div>
                  <span className="text-[13px] text-white/80 block mt-1 font-normal">
                    Added to stairs line item
                  </span>
                </div>
              </div>

              {rules.map((rule) => (
                <div key={rule.id} className="p-4 flex items-center justify-between">
                  <div>
                    <span className="text-[15px] font-bold text-white block">
                      {rule.name}
                    </span>
                    <span className="text-[13px] text-emerald-300 font-semibold block mt-1">
                      Adds ${rule.adjustmentValue ?? rule.effectValue ?? 0}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDeleteRule(rule.id)}
                    className="p-2 text-white/70 active:text-rose-400 transition-colors"
                  >
                    <Trash2 className="w-4 h-4 stroke-[1.8]" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Add Rule Modal */}
      {showAddRuleModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-md">
          <div className="bg-slate-900/95 backdrop-blur-2xl rounded-[24px] max-w-sm w-full p-6 shadow-2xl border border-white/20 space-y-4 animate-slide-up">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-[18px] font-bold text-white">
                New Rule
              </h3>
              <button
                type="button"
                onClick={() => setShowAddRuleModal(false)}
                className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/90"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddRule} className="space-y-4">
              <div>
                <label className="text-[13px] font-bold text-white/90 block mb-1.5">
                  When (Condition)
                </label>
                <input
                  type="text"
                  value={ruleCondition}
                  onChange={(e) => setRuleCondition(e.target.value)}
                  placeholder="e.g. Roof has steep pitch"
                  className="w-full h-12 px-3.5 rounded-[14px] glass-panel text-[16px] text-white placeholder:text-white/40 outline-none border border-white/20 focus:border-cyan-400"
                  required
                />
              </div>

              <div>
                <label className="text-[13px] font-bold text-white/90 block mb-1.5">
                  Add Amount ($)
                </label>
                <input
                  type="number"
                  inputMode="decimal"
                  value={ruleAmount}
                  onChange={(e) => setRuleAmount(e.target.value)}
                  placeholder="e.g. 1200"
                  className="w-full h-12 px-3.5 rounded-[14px] glass-panel text-[16px] text-white placeholder:text-white/40 outline-none border border-white/20 focus:border-cyan-400"
                  required
                />
              </div>

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddRuleModal(false)}
                  className="flex-1 h-12 rounded-[14px] bg-white/10 text-white font-bold text-[15px] active:scale-95 transition-transform"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 h-12 rounded-[14px] bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold text-[15px] shadow-[0_0_16px_rgba(56,189,248,0.4)] active:scale-95 transition-transform"
                >
                  Save rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
