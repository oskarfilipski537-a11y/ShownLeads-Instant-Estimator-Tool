import React from 'react';
import { Plus, ChevronRight, Phone, MessageSquare, Clock, TrendingUp, CheckCircle, FileText, Sparkles } from 'lucide-react';
import { CompanyProfile, Estimate } from '../types';
import { getTradePack } from '../tradePacks';
import { formatMoney } from '../lib/units';

interface HomeScreenProps {
  company: CompanyProfile;
  estimates: Estimate[];
  draftEstimate?: Estimate | null;
  onNewEstimate: () => void;
  onSelectEstimate: (estimate: Estimate) => void;
  onResumeDraft?: (draft: Estimate) => void;
  onFilterQuotes?: (status: 'all' | 'sent' | 'won' | 'lost') => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  company,
  estimates,
  draftEstimate,
  onNewEstimate,
  onSelectEstimate,
  onResumeDraft,
  onFilterQuotes
}) => {
  const pack = getTradePack(company.primaryTrade);

  // Metrics: This Month
  const now = new Date();
  const currentMonthEstimates = estimates.filter((e) => {
    const d = new Date(e.createdAt || Date.now());
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  });

  const sentCount = estimates.filter((e) => e.status === 'sent' || e.status === 'presented').length;
  const wonCount = estimates.filter((e) => e.status === 'won').length;
  const moneyWon = estimates
    .filter((e) => e.status === 'won')
    .reduce((sum, e) => sum + (e.costBreakdown?.totalExact || e.total || 0), 0);

  // Needs follow-up: Sent 3+ days ago
  const threeDaysAgo = Date.now() - 3 * 24 * 60 * 60 * 1000;
  const followUpEstimates = estimates.filter((e) => {
    const isSent = e.status === 'sent' || e.status === 'presented';
    const createdTime = new Date(e.createdAt || Date.now()).getTime();
    const isOlderThan3Days = createdTime < threeDaysAgo;
    return isSent && isOlderThan3Days;
  });

  // Recent 5 quotes
  const recentEstimates = [...estimates]
    .sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime())
    .slice(0, 5);

  const formatJobDescription = (est: Estimate) => {
    const jobName = est.measurements?.jobTypeName || pack.jobTypes[0]?.name || 'Loft room';
    const area = est.measurements?.squareFootage
      ? `${Math.round(est.measurements.squareFootage)} m²`
      : est.measurements?.length && est.measurements?.width
      ? `${Math.round(Number(est.measurements.length) * Number(est.measurements.width))} m²`
      : '14 m²';
    return `${jobName} · ${area}`;
  };

  return (
    <div className="min-h-screen text-white pb-28 px-4 pt-4 max-w-md mx-auto w-full select-none">
      {/* 1. Header: Replace "Hi [Name]" with the Company Name */}
      <div className="pt-2 pb-4 space-y-1.5">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-blue-500/25 to-purple-500/25 border border-blue-400/30 text-white text-[12px] font-semibold tracking-wide">
          <Sparkles className="w-3.5 h-3.5 text-cyan-300" />
          <span>{pack.displayName}</span>
        </div>
        <h1 className="text-[32px] sm:text-[34px] font-extrabold tracking-tight text-white leading-tight drop-shadow-sm truncate">
          {company.companyName || 'ShownLeads Estimator'}
        </h1>
        <p className="text-[14px] text-white/80 font-medium">
          Instant on-site quoting
        </p>
      </div>

      <div className="space-y-5">
        {/* Draft Banner if any exists */}
        {draftEstimate && (
          <div
            onClick={() => onResumeDraft && onResumeDraft(draftEstimate)}
            className="flex items-center justify-between p-4 glass-panel-interactive rounded-[18px] border-cyan-400/30 cursor-pointer active:scale-[0.98] transition-all bg-gradient-to-r from-cyan-500/15 via-blue-500/10 to-transparent shadow-lg shadow-cyan-950/20"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-full bg-cyan-500/20 border border-cyan-400/40 text-cyan-300 flex items-center justify-center shrink-0 shadow-inner">
                <Clock className="w-5 h-5 stroke-[2.2]" />
              </div>
              <div>
                <span className="text-[16px] font-bold text-white block">
                  Continue {draftEstimate.customerName || draftEstimate.customer?.name || 'Customer'}'s quote
                </span>
                <span className="text-[13px] text-white/80 block font-medium">
                  Draft saved on site · Tap to resume
                </span>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-white/70" />
          </div>
        )}

        {/* Primary Action Button: Colourful, Animated New Quote */}
        <button
          type="button"
          onClick={onNewEstimate}
          className="w-full h-[58px] rounded-[18px] bg-gradient-to-r from-[#007AFF] via-[#3B82F6] to-[#8B5CF6] text-white font-bold text-[18px] flex items-center justify-center gap-2.5 active:scale-[0.98] shadow-lg shadow-blue-600/30 border border-white/25 transition-all select-none hover:brightness-110"
        >
          <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center">
            <Plus className="w-5 h-5 stroke-[2.8] text-white" />
          </div>
          <span className="tracking-tight text-white font-bold">New quote</span>
        </button>

        {/* 2. Colorful, Glassy Columns: "This month" */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-[14px] font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <TrendingUp className="w-4 h-4 text-cyan-400" />
              <span>This month</span>
            </h2>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            {/* Column 1: Sent (Electric Blue / Cyan Glow) */}
            <button
              type="button"
              onClick={() => onFilterQuotes && onFilterQuotes('sent')}
              className="p-3.5 rounded-[18px] text-left transition-all glass-panel-interactive border-cyan-400/30 bg-gradient-to-b from-cyan-500/15 to-transparent relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-12 h-12 bg-cyan-400/10 rounded-full blur-xl group-hover:scale-150 transition-transform" />
              <div className="flex items-center gap-1.5 mb-1">
                <FileText className="w-3.5 h-3.5 text-cyan-300" />
                <span className="text-[13px] text-white font-semibold">
                  Sent
                </span>
              </div>
              <span className="text-[28px] font-extrabold text-white tabular-nums block leading-tight">
                {sentCount}
              </span>
              <span className="text-[11px] text-white/70 block font-medium mt-0.5">
                Quotes out
              </span>
            </button>

            {/* Column 2: Won (Emerald Green Glow) */}
            <button
              type="button"
              onClick={() => onFilterQuotes && onFilterQuotes('won')}
              className="p-3.5 rounded-[18px] text-left transition-all glass-panel-interactive border-emerald-400/35 bg-gradient-to-b from-emerald-500/15 to-transparent relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-12 h-12 bg-emerald-400/15 rounded-full blur-xl group-hover:scale-150 transition-transform" />
              <div className="flex items-center gap-1.5 mb-1">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-300" />
                <span className="text-[13px] text-white font-semibold">
                  Won
                </span>
              </div>
              <span className="text-[28px] font-extrabold text-emerald-300 tabular-nums block leading-tight">
                {wonCount}
              </span>
              <span className="text-[11px] text-white/70 block font-medium mt-0.5">
                Jobs closed
              </span>
            </button>

            {/* Column 3: Money Won (Gold / Violet Gradient Glow) */}
            <button
              type="button"
              onClick={() => onFilterQuotes && onFilterQuotes('won')}
              className="p-3.5 rounded-[18px] text-left transition-all glass-panel-interactive border-amber-400/35 bg-gradient-to-b from-amber-500/15 via-purple-500/10 to-transparent relative overflow-hidden group"
            >
              <div className="absolute top-0 right-0 w-12 h-12 bg-amber-400/15 rounded-full blur-xl group-hover:scale-150 transition-transform" />
              <span className="text-[13px] text-white font-semibold block mb-1 truncate">
                Money won
              </span>
              <span className="text-[22px] font-extrabold text-amber-300 tabular-nums block leading-tight truncate">
                {formatMoney(moneyWon)}
              </span>
              <span className="text-[11px] text-white/70 block font-medium mt-0.5 truncate">
                Contract value
              </span>
            </button>
          </div>
        </div>

        {/* Needs follow-up (quotes sent 3+ days ago) */}
        {followUpEstimates.length > 0 && (
          <div className="space-y-2">
            <h2 className="text-[14px] font-bold text-white uppercase tracking-wider px-1 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-amber-400" />
              <span>Needs follow-up</span>
            </h2>
            <div className="glass-panel rounded-[18px] divide-y divide-white/10 overflow-hidden shadow-md">
              {followUpEstimates.slice(0, 3).map((est) => {
                const phone = est.customerPhone || est.customer?.phone;
                const createdTime = new Date(est.createdAt || Date.now()).getTime();
                const daysAgo = Math.max(1, Math.round((Date.now() - createdTime) / (24 * 60 * 60 * 1000)));
                return (
                  <div key={est.id} className="p-4 flex items-center justify-between">
                    <div>
                      <span className="text-[17px] font-bold text-white block">
                        {est.customerName || est.customer?.name}
                      </span>
                      <span className="text-[13px] text-white/80 block mt-0.5 font-medium">
                        Sent {daysAgo} days ago · <span className="text-cyan-300 font-bold">{formatMoney(est.costBreakdown?.totalExact || est.total || 0)}</span>
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {phone && (
                        <a
                          href={`tel:${phone}`}
                          className="h-10 px-3.5 rounded-[12px] bg-gradient-to-r from-blue-600 to-cyan-600 text-white font-bold text-[13px] flex items-center gap-1.5 active:scale-95 shadow-md shadow-blue-900/30"
                        >
                          <Phone className="w-3.5 h-3.5 fill-current" />
                          <span>Call</span>
                        </a>
                      )}
                      {phone && (
                        <a
                          href={`sms:${phone}`}
                          className="h-10 px-3.5 rounded-[12px] bg-white/15 border border-white/20 text-white font-bold text-[13px] flex items-center gap-1.5 active:scale-95"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Text</span>
                        </a>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Recent Quotes */}
        <div className="space-y-2">
          <div className="flex items-center justify-between px-1">
            <h2 className="text-[14px] font-bold text-white uppercase tracking-wider">
              Recent quotes
            </h2>
            {estimates.length > 5 && (
              <button
                type="button"
                onClick={() => onFilterQuotes && onFilterQuotes('all')}
                className="text-[13px] text-cyan-300 font-semibold active:opacity-75"
              >
                See all ({estimates.length})
              </button>
            )}
          </div>

          {recentEstimates.length === 0 ? (
            <div className="glass-panel rounded-[20px] p-8 text-center space-y-3.5 border-dashed border-white/20">
              <p className="text-[17px] font-bold text-white">
                No quotes yet. Make your first one.
              </p>
              <p className="text-[14px] text-white/80 font-medium">
                Produce itemized quotes before leaving the driveway.
              </p>
              <button
                type="button"
                onClick={onNewEstimate}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-[14px] bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold text-[15px] active:scale-95 shadow-md"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>Make a quote</span>
              </button>
            </div>
          ) : (
            <div className="glass-panel rounded-[18px] divide-y divide-white/10 overflow-hidden shadow-lg">
              {recentEstimates.map((est) => {
                const total = est.costBreakdown?.totalExact || est.total || 0;
                const statusDotColor =
                  est.status === 'won'
                    ? 'bg-emerald-400 shadow-sm shadow-emerald-400/80'
                    : est.status === 'lost'
                    ? 'bg-rose-500'
                    : 'bg-cyan-400 shadow-sm shadow-cyan-400/80';

                return (
                  <button
                    key={est.id}
                    type="button"
                    onClick={() => onSelectEstimate(est)}
                    className="w-full p-4 flex items-center justify-between text-left active:bg-white/[0.08] transition-colors min-h-[64px]"
                  >
                    <div className="flex-1 pr-3">
                      <div className="flex items-center gap-2.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${statusDotColor} shrink-0`} />
                        <span className="text-[17px] font-bold text-white truncate">
                          {est.customerName || est.customer?.name || 'Customer quote'}
                        </span>
                      </div>
                      <span className="text-[14px] text-white/80 block mt-0.5 ml-5 font-medium">
                        {formatJobDescription(est)}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[18px] font-extrabold text-white tabular-nums block">
                        {formatMoney(total)}
                      </span>
                      <span className="text-[12px] font-semibold text-cyan-300 capitalize block">
                        {est.status}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
