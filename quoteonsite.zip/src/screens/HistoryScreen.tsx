import React, { useState } from 'react';
import { Search, Trash2, CheckCircle2, XCircle, X } from 'lucide-react';
import { Estimate } from '../types';
import { formatMoney } from '../lib/units';
import { SegmentedControl } from '../components/apple/SegmentedControl';

interface HistoryScreenProps {
  estimates: Estimate[];
  onSelectEstimate: (estimate: Estimate) => void;
  onDeleteEstimate: (id: string) => void;
  onMarkOutcome: (id: string, status: 'won' | 'lost', soldPrice?: number) => void;
}

export const HistoryScreen: React.FC<HistoryScreenProps> = ({
  estimates,
  onSelectEstimate,
  onDeleteEstimate,
  onMarkOutcome,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<'all' | 'open' | 'won' | 'lost'>('all');
  const [deletedEstimate, setDeletedEstimate] = useState<Estimate | null>(null);
  const [toastTimeout, setToastTimeout] = useState<any>(null);

  // Compute counts for segmented control tabs
  const allCount = estimates.length;
  const openCount = estimates.filter(
    (e) => e.status === 'draft' || e.status === 'presented' || e.status === 'sent'
  ).length;
  const wonCount = estimates.filter((e) => e.status === 'won').length;
  const lostCount = estimates.filter((e) => e.status === 'lost').length;

  const filtered = estimates.filter((est) => {
    const status = est.status;
    const matchesFilter =
      filter === 'all' ||
      (filter === 'open' && (status === 'draft' || status === 'presented' || status === 'sent')) ||
      (filter === 'won' && status === 'won') ||
      (filter === 'lost' && status === 'lost');

    const q = searchQuery.toLowerCase().trim();
    const customer = est.customerName || est.customer?.name || '';
    const address = est.customerAddress || est.customer?.address || '';
    const job = est.measurements?.jobTypeName || '';

    const matchesSearch =
      !q ||
      customer.toLowerCase().includes(q) ||
      address.toLowerCase().includes(q) ||
      job.toLowerCase().includes(q);

    return matchesFilter && matchesSearch;
  });

  const handleDeleteWithUndo = (est: Estimate, e: React.MouseEvent) => {
    e.stopPropagation();
    setDeletedEstimate(est);
    onDeleteEstimate(est.id);

    if (toastTimeout) clearTimeout(toastTimeout);
    const timeout = setTimeout(() => {
      setDeletedEstimate(null);
    }, 4500);
    setToastTimeout(timeout);
  };

  const handleMarkWon = (est: Estimate, e: React.MouseEvent) => {
    e.stopPropagation();
    const total = est.costBreakdown?.totalExact || est.total || 0;
    onMarkOutcome(est.id, 'won', total);
  };

  const formatDate = (timestamp?: number | string) => {
    if (!timestamp) return 'Recent';
    const date = new Date(timestamp);
    return isNaN(date.getTime()) ? 'Recent' : date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  return (
    <div className="min-h-screen text-white pb-32 px-4 pt-4 max-w-md mx-auto w-full">
      {/* Large Title */}
      <div className="pt-2 pb-3">
        <h1 className="text-[34px] font-extrabold tracking-tight text-white drop-shadow-sm">
          Quotes
        </h1>
        <p className="text-[14px] text-white/80 font-normal mt-0.5">
          Track and close your on-site bids
        </p>
      </div>

      {/* Search Field */}
      <div className="mb-4">
        <div className="relative flex items-center glass-panel rounded-[14px] px-3.5 h-11 border border-white/15 shadow-sm">
          <Search className="w-4 h-4 text-white/70 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by customer name, job, or address..."
            className="w-full bg-transparent px-2.5 text-[15px] text-white placeholder:text-white/50 outline-none"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="text-white/70 active:text-white p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Segmented Filter (All, Open, Won, Lost with counts) */}
      <div className="mb-4">
        <SegmentedControl
          size="sm"
          value={filter}
          onChange={(val) => setFilter(val as any)}
          options={[
            { value: 'all', label: `All (${allCount})` },
            { value: 'open', label: `Open (${openCount})` },
            { value: 'won', label: `Won (${wonCount})` },
            { value: 'lost', label: `Lost (${lostCount})` },
          ]}
        />
      </div>

      {/* Quotes Inset List */}
      {filtered.length === 0 ? (
        <div className="glass-panel rounded-[20px] p-8 text-center border border-white/15 shadow-lg">
          <p className="text-[16px] font-semibold text-white/90">
            No quotes match this filter.
          </p>
          <p className="text-[13px] text-white/70 mt-1">
            Tap the + button below to create your first quote.
          </p>
        </div>
      ) : (
        <div className="glass-panel rounded-[20px] border border-white/15 divide-y divide-white/10 shadow-xl overflow-hidden">
          {filtered.map((est) => {
            const customerName = est.customerName || est.customer?.name || 'Quote';
            const total = est.costBreakdown?.totalExact || est.total || 0;
            const jobName = est.measurements?.jobTypeName || 'Project';
            const area = est.measurements?.squareFootage
              ? `${Math.round(est.measurements.squareFootage)} m²`
              : est.measurements?.length && est.measurements?.width
              ? `${Math.round(Number(est.measurements.length) * Number(est.measurements.width))} m²`
              : '14 m²';
            const subtitle = `${jobName} · ${area}`;

            const statusDotColor =
              est.status === 'won'
                ? 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]'
                : est.status === 'lost'
                ? 'bg-rose-500 shadow-[0_0_10px_rgba(244,63,94,0.7)]'
                : 'bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)]';

            const statusBadgeText =
              est.status === 'won'
                ? 'Won'
                : est.status === 'lost'
                ? 'Lost'
                : 'Draft';

            const statusBadgeStyle =
              est.status === 'won'
                ? 'text-emerald-300 bg-emerald-500/20 border-emerald-500/30'
                : est.status === 'lost'
                ? 'text-rose-300 bg-rose-500/20 border-rose-500/30'
                : 'text-cyan-300 bg-cyan-500/20 border-cyan-500/30';

            return (
              <div
                key={est.id}
                onClick={() => onSelectEstimate(est)}
                className="p-4 flex items-center justify-between active:bg-white/10 cursor-pointer transition-all hover:bg-white/[0.04] min-h-[68px]"
              >
                <div className="flex-1 pr-3">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${statusDotColor} shrink-0`} />
                    <span className="text-[17px] font-bold text-white truncate">
                      {customerName}
                    </span>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${statusBadgeStyle} shrink-0`}>
                      {statusBadgeText}
                    </span>
                  </div>
                  <span className="text-[13px] text-white/80 block mt-1 ml-4.5 font-normal">
                    {subtitle}
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="text-[18px] font-extrabold text-white tabular-nums block drop-shadow-sm">
                      {formatMoney(total)}
                    </span>
                    <span className="text-[12px] text-white/70 block font-medium">
                      {est.status === 'won' ? `Sold · ${formatDate(est.createdAt)}` : formatDate(est.createdAt)}
                    </span>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-1.5">
                    {est.status !== 'won' && (
                      <button
                        type="button"
                        onClick={(e) => handleMarkWon(est, e)}
                        className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-300 active:scale-90 transition-transform shadow-sm"
                        title="Mark won"
                        aria-label="Mark won"
                      >
                        <CheckCircle2 className="w-4 h-4 stroke-[2.2]" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={(e) => handleDeleteWithUndo(est, e)}
                      className="w-8 h-8 rounded-full bg-white/10 border border-white/15 flex items-center justify-center text-white/70 active:text-rose-400 active:scale-90 transition-all"
                      title="Delete"
                      aria-label="Delete"
                    >
                      <Trash2 className="w-4 h-4 stroke-[1.8]" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Undo Delete Toast */}
      {deletedEstimate && (
        <div className="fixed bottom-24 left-4 right-4 max-w-md mx-auto z-40 glass-panel border border-white/20 shadow-2xl rounded-[16px] p-3.5 flex items-center justify-between animate-slide-up">
          <span className="text-[15px] font-semibold text-white">
            Quote for {deletedEstimate.customerName || 'customer'} deleted.
          </span>
          <button
            type="button"
            onClick={() => {
              setDeletedEstimate(null);
            }}
            className="text-[15px] font-bold text-cyan-400 px-2 py-1 active:opacity-60"
          >
            Undo
          </button>
        </div>
      )}
    </div>
  );
};
