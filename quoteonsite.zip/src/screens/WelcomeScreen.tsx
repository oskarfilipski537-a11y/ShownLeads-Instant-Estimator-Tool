import React, { useState } from 'react';
import { ChevronRight, ShieldCheck, Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { ALL_TRADE_PACKS } from '../tradePacks';
import { InsetGroup, InsetRow } from '../components/apple/InsetGroup';
import { SegmentedControl } from '../components/apple/SegmentedControl';
import { PrimaryButton } from '../components/apple/PrimaryButton';
import { ActionBottomBar } from '../components/apple/ActionBottomBar';
import { BottomSheet } from '../components/apple/BottomSheet';

interface WelcomeScreenProps {
  onAuthSuccess?: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onAuthSuccess }) => {
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [selectedTrade, setSelectedTrade] = useState('attic');
  const [showTradeSheet, setShowTradeSheet] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  const selectedTradePack = ALL_TRADE_PACKS.find((t) => t.id === selectedTrade) || ALL_TRADE_PACKS[0];

  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setSuccessMessage(null);

    const cleanEmail = email.trim();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      setAuthError('Add your work email address.');
      return;
    }

    if (!password || password.length < 6) {
      setAuthError('Password must be at least 6 characters.');
      return;
    }

    setIsLoading(true);

    try {
      if (authMode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email: cleanEmail,
          password: password,
          options: {
            data: {
              company_name: companyName.trim() || 'My Business',
              primary_trade: selectedTrade,
            },
          },
        });

        if (error) {
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }

        if (data.session) {
          if (onAuthSuccess) onAuthSuccess();
        } else if (data.user) {
          setSuccessMessage('Account created! Please sign in below.');
          setAuthMode('signin');
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: cleanEmail,
          password: password,
        });

        if (error) {
          setAuthError(error.message);
          setIsLoading(false);
          return;
        }

        if (data.session && onAuthSuccess) {
          onAuthSuccess();
        }
      }
    } catch (err: any) {
      setAuthError(err.message || 'Could not sign in. Try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen text-white flex flex-col justify-between px-4 pt-10 pb-28 max-w-md mx-auto w-full">
      <div className="space-y-6">
        {/* App Title Header */}
        <div className="text-center pt-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-500/15 border border-cyan-400/30 text-cyan-300 text-[12px] font-bold mb-3 shadow-sm">
            <Sparkles className="w-3.5 h-3.5" />
            <span>On-Site Estimating for Contractors</span>
          </div>
          <h1 className="text-[34px] sm:text-[38px] font-extrabold text-white tracking-tight drop-shadow-sm">
            ShownLeads
          </h1>
          <p className="text-[17px] font-semibold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-300 mt-0.5">
            Instant Estimator
          </p>
        </div>

        {/* Sign In vs Sign Up Segmented Control */}
        <div className="pt-1">
          <SegmentedControl
            options={[
              { value: 'signin', label: 'Sign In' },
              { value: 'signup', label: 'New Account' },
            ]}
            value={authMode}
            onChange={(val) => {
              setAuthMode(val);
              setAuthError(null);
              setSuccessMessage(null);
            }}
          />
        </div>

        {/* Error / Success Banners */}
        {authError && (
          <div className="p-3.5 rounded-[14px] bg-rose-500/20 border border-rose-500/40 text-rose-200 text-[14px] font-medium leading-snug">
            {authError}
          </div>
        )}

        {successMessage && (
          <div className="p-3.5 rounded-[14px] bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-[14px] font-medium leading-snug">
            {successMessage}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleAuthSubmit} className="space-y-4">
          <InsetGroup title="Account Credentials">
            <InsetRow
              label="Email"
              control={
                <input
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="contractor@work.com"
                  className="text-right text-[17px] text-white placeholder:text-white/40 bg-transparent outline-none w-48 font-medium"
                  required
                />
              }
            />
            <InsetRow
              label="Password"
              isLast={authMode === 'signin'}
              control={
                <input
                  type="password"
                  autoComplete={authMode === 'signin' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="text-right text-[17px] text-white placeholder:text-white/40 bg-transparent outline-none w-36 font-medium"
                  required
                />
              }
            />

            {authMode === 'signup' && (
              <>
                <InsetRow
                  label="Company"
                  control={
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => setCompanyName(e.target.value)}
                      placeholder="Your Business Name"
                      className="text-right text-[17px] text-white placeholder:text-white/40 bg-transparent outline-none w-44 font-medium"
                      required
                    />
                  }
                />
                <InsetRow
                  label="Your Trade"
                  isLast
                  onClick={() => setShowTradeSheet(true)}
                  control={
                    <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-[16px]">
                      <span>{selectedTradePack.displayName}</span>
                      <ChevronRight className="w-4 h-4 text-white/70" />
                    </div>
                  }
                />
              </>
            )}
          </InsetGroup>

          <ActionBottomBar>
            <PrimaryButton
              label={authMode === 'signup' ? 'Create Account' : 'Sign In'}
              loading={isLoading}
              onClick={(e) => handleAuthSubmit(e as any)}
            />
          </ActionBottomBar>
        </form>
      </div>

      <div className="text-center pt-6 space-y-1">
        <p className="text-[13px] text-white/80 font-medium flex items-center justify-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Quotes on site in under 3 minutes · Direct to Supabase</span>
        </p>
      </div>

      {/* Trade Selector Bottom Sheet */}
      <BottomSheet
        isOpen={showTradeSheet}
        onClose={() => setShowTradeSheet(false)}
        title="Select Your Trade"
        options={ALL_TRADE_PACKS.map((t) => ({
          value: t.id,
          label: t.displayName,
          description: `${t.jobTypes.length} job types configured`,
        }))}
        selectedValue={selectedTrade}
        onSelect={(val) => setSelectedTrade(val)}
      />
    </div>
  );
};

