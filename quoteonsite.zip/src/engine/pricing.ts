import {
  CompanyProfile,
  CostBreakdown,
  EstimateLineItem,
  PricingProfile,
  PricingRule,
  TierOption,
} from '../types';
import { getTradePack } from '../tradePacks';
import { calculateEstimate, EngineResult, verifyEngineReconciliation } from './estimateEngine';

export * from './estimateEngine';

export interface PricingEngineInput {
  lineItems: EstimateLineItem[];
  companyProfile: CompanyProfile;
  pricingProfile?: PricingProfile;
  activeRules?: PricingRule[];
  squareFootage?: number;
  oneWayMiles?: number;
  confidenceRating?: 'high' | 'medium' | 'low';
  contingencyPct?: number;
  wasteFactorPct?: number;
  photosCount?: number;
  answers?: Record<string, string>;
  measurements?: Record<string, any>;
  jobTypeId?: string;
}

/**
 * Single source of truth calculation engine
 */
export function calculateDeterministicEstimate(input: PricingEngineInput): {
  costBreakdown: CostBreakdown;
  updatedLineItems: EstimateLineItem[];
  engineResult: EngineResult;
} {
  const {
    lineItems,
    companyProfile,
    pricingProfile,
    squareFootage = 20,
    photosCount = 0,
    answers = {},
    measurements = {},
    jobTypeId = 'bedroom',
  } = input;

  const pack = getTradePack(companyProfile.primaryTrade);

  // Run the single deterministic engine
  const engineResult = calculateEstimate({
    pack,
    company: companyProfile,
    jobTypeId,
    measurements: {
      ...measurements,
      length: measurements.length || Math.sqrt(squareFootage * (pack.defaultUnitSystem === 'imperial' ? 0.0929 : 1)),
      width: measurements.width || Math.sqrt(squareFootage * (pack.defaultUnitSystem === 'imperial' ? 0.0929 : 1))
    },
    answers,
    photosCount,
    pastQuotesCount: pricingProfile?.pastQuotes?.length || 0,
  });

  // Verify mathematical reconciliation
  verifyEngineReconciliation(engineResult);

  // Map to legacy line items format for UI consumers
  const updatedLineItems: EstimateLineItem[] = engineResult.lineItems.map(item => ({
    id: item.id,
    category: item.category === 'labor' ? 'labor' : item.category === 'extras' ? 'other' : 'materials',
    name: item.name,
    quantity: item.quantity,
    unit: item.unit,
    unitCost: item.unitCost,
    markupPct: 0,
    total: item.total,
    aiSuggested: false,
    reasoningTag: item.source
  }));

  const costBreakdown: CostBreakdown = {
    materialsBase: engineResult.materials,
    materialsMarkedUp: engineResult.materials,
    laborCost: engineResult.labour,
    laborHours: engineResult.crewHours,
    crewDays: engineResult.labourDays,
    travelCost: 0,
    equipmentCost: engineResult.extras,
    permitsCost: engineResult.fees,
    subtotalCosts: engineResult.directCost,
    overheadAmount: engineResult.overheadAmount,
    profitAmount: engineResult.profit,
    contingencyAmount: engineResult.contingencyTotal,
    preTaxTotal: engineResult.price,
    taxAmount: engineResult.taxAmount,
    totalExact: engineResult.price,
    rangeLow: Math.round((engineResult.price * (engineResult.confidenceLevel === 'high' ? 0.95 : engineResult.confidenceLevel === 'medium' ? 0.90 : 0.82)) / 5) * 5,
    rangeHigh: Math.round((engineResult.price * (engineResult.confidenceLevel === 'high' ? 1.05 : engineResult.confidenceLevel === 'medium' ? 1.10 : 1.18)) / 5) * 5,
    confidence: engineResult.confidenceLevel,
    confidenceScore: engineResult.confidenceScore,
    confidenceReasons: [engineResult.confidenceReason],
    appliedRules: [],
  };

  return { costBreakdown, updatedLineItems, engineResult };
}

export function generateGoodBetterBestTiers(
  baseEstimate: {
    lineItems: EstimateLineItem[];
    companyProfile: CompanyProfile;
    costBreakdown: CostBreakdown;
    squareFootage: number;
    tradeId: string;
    engineResult?: EngineResult;
    measurements?: Record<string, any>;
  }
): { good: TierOption; better: TierOption; best: TierOption } {
  const { companyProfile, tradeId, engineResult, measurements = {} } = baseEstimate;
  const pack = getTradePack(tradeId || companyProfile.primaryTrade);

  // If engineResult already computed the packages with real scope differences
  if (engineResult && engineResult.packages && engineResult.packages.length >= 3) {
    const [basic, nice, top] = engineResult.packages;
    return {
      good: {
        name: basic.name,
        badge: 'Basic',
        subtitle: basic.bullets.slice(0, 2).join(' · '),
        total: basic.price,
        breakdown: {
          ...baseEstimate.costBreakdown,
          totalExact: basic.price,
          profitAmount: basic.profit,
          subtotalCosts: basic.costBase,
          crewDays: basic.days,
        },
        inclusions: basic.bullets,
        warrantyYears: parseInt(companyProfile.warranty || '10', 10) || 10,
        timelineWeeks: `${Math.ceil(basic.days / 5)} weeks`,
      },
      better: {
        name: nice.name,
        badge: 'Nice',
        subtitle: nice.bullets.slice(0, 2).join(' · '),
        total: nice.price,
        breakdown: {
          ...baseEstimate.costBreakdown,
          totalExact: nice.price,
          profitAmount: nice.profit,
          subtotalCosts: nice.costBase,
          crewDays: nice.days,
        },
        inclusions: nice.bullets,
        warrantyYears: parseInt(companyProfile.warranty || '10', 10) || 10,
        timelineWeeks: `${Math.ceil(nice.days / 5)} weeks`,
      },
      best: {
        name: top.name,
        badge: 'Top',
        subtitle: top.bullets.slice(0, 2).join(' · '),
        total: top.price,
        breakdown: {
          ...baseEstimate.costBreakdown,
          totalExact: top.price,
          profitAmount: top.profit,
          subtotalCosts: top.costBase,
          crewDays: top.days,
        },
        inclusions: top.bullets,
        warrantyYears: parseInt(companyProfile.warranty || '10', 10) || 10,
        timelineWeeks: `${Math.ceil(top.days / 5)} weeks`,
      }
    };
  }

  // Fallback if no precomputed engine result
  const calculated = calculateEstimate({
    pack,
    company: companyProfile,
    jobTypeId: 'bedroom',
    measurements,
    answers: {},
    photosCount: 2
  });

  const [basic, nice, top] = calculated.packages;
  return {
    good: {
      name: basic.name,
      badge: 'Basic',
      subtitle: basic.bullets[0] || 'Standard setup',
      total: basic.price,
      breakdown: { ...baseEstimate.costBreakdown, totalExact: basic.price },
      inclusions: basic.bullets,
      warrantyYears: 10,
      timelineWeeks: `${Math.ceil(basic.days / 5)} weeks`,
    },
    better: {
      name: nice.name,
      badge: 'Nice',
      subtitle: nice.bullets[0] || 'Enhanced setup',
      total: nice.price,
      breakdown: { ...baseEstimate.costBreakdown, totalExact: nice.price },
      inclusions: nice.bullets,
      warrantyYears: 10,
      timelineWeeks: `${Math.ceil(nice.days / 5)} weeks`,
    },
    best: {
      name: top.name,
      badge: 'Top',
      subtitle: top.bullets[0] || 'Premium setup',
      total: top.price,
      breakdown: { ...baseEstimate.costBreakdown, totalExact: top.price },
      inclusions: top.bullets,
      warrantyYears: 10,
      timelineWeeks: `${Math.ceil(top.days / 5)} weeks`,
    }
  };
}
