import { TradePack, TradePackage } from '../tradePacks/types';
import { CompanyProfile } from '../types';

export interface CalculatedLineItem {
  id: string;
  name: string;
  category: 'materials' | 'labor' | 'extras' | 'fees';
  quantity: number;
  unit: string;
  unitCost: number;
  total: number;
  source: 'price_book' | 'pack_default' | 'user_rule' | 'contingency' | 'custom';
  sourceDetail?: string;
}

export interface EngineResult {
  materials: number;
  labour: number;
  extras: number;
  fees: number;
  directCost: number;
  overheadAmount: number;
  overheadPct: number;
  costBase: number;
  profitMarginPct: number;
  price: number;
  profit: number;
  actualMarginPct: number;
  taxPct: number;
  taxAmount: number;
  totalWithTax: number;
  labourDays: number;
  crewHours: number;
  lineItems: CalculatedLineItem[];
  contingencyTotal: number;
  confidenceScore: number;
  confidenceLevel: 'low' | 'medium' | 'high';
  confidenceReason: string;
  sanityCheck: {
    inBand: boolean;
    minExpected: number;
    maxExpected: number;
    message?: string;
  };
  packages: Array<{
    id: 'basic' | 'nice' | 'top';
    name: string;
    price: number;
    profit: number;
    costBase: number;
    days: number;
    bullets: string[];
  }>;
}

/**
 * Deterministic calculation engine strictly implementing Section 7 specification
 */
export function calculateEstimate(params: {
  pack: TradePack;
  company: CompanyProfile;
  jobTypeId: string;
  measurements: Record<string, any>;
  answers: Record<string, string>;
  photosCount: number;
  pastQuotesCount?: number;
  selectedPackageId?: 'basic' | 'nice' | 'top';
}): EngineResult {
  const {
    pack,
    company,
    jobTypeId,
    measurements,
    answers,
    photosCount,
    pastQuotesCount = 0,
    selectedPackageId = 'nice'
  } = params;

  const jobType = pack.jobTypes.find(j => j.id === jobTypeId) || pack.jobTypes[0];
  const areaSqM = Number(measurements.length || 0) * Number(measurements.width || 0) || jobType.defaultSqM || 20;

  const hourlyRate = company.loadedHourlyRate || company.billableHourlyRate || pack.labourRates.hourlyRate || 55;
  const crewSize = company.crewSize || pack.labourRates.crewSize || 2;
  const profitMarginPct = (company.targetMargin || 35) / 100; // e.g. 0.35
  const overheadPct = (company.overheadPct || 15) / 100; // e.g. 0.15

  // 1. Build Base Line Items from Trade Pack & Measurements
  const lineItems: CalculatedLineItem[] = [];

  // Add items from pack's priceBook scaled to measurements
  pack.priceBook.forEach(pb => {
    let qty = 0;
    if (pb.unit === 'm²') {
      qty = Math.round(areaSqM);
    } else if (pb.unit === 'item' || pb.unit === 'job' || pb.unit === 'pack') {
      // Scale specific items
      if (pb.id.includes('roof_window')) {
        qty = Number(measurements.roof_windows ?? 2);
      } else if (pb.id.includes('staircase')) {
        qty = measurements.stairs === 'existing' ? 0 : 1;
      } else if (pb.id.includes('dormer')) {
        qty = measurements.dormer === 'none' || !measurements.dormer ? 0 : (measurements.dormer === 'two' ? 2 : 1);
      } else if (pb.id.includes('scaffold') || pb.id.includes('skip') || pb.id.includes('building_notice')) {
        qty = 1;
      } else if (pb.id.includes('electrics') || pb.id.includes('internal_door')) {
        qty = pb.id.includes('internal_door') ? 2 : 1;
      } else {
        qty = 1;
      }
    } else if (pb.unit === 'tonne' || pb.unit === 'm³') {
      qty = Math.max(1, Math.round(areaSqM * 0.15));
    } else {
      qty = 1;
    }

    if (qty > 0) {
      const wasteFactor = 1 + (pb.wastePct || 0) / 100;
      const total = Math.round(qty * pb.defaultCost * wasteFactor);
      lineItems.push({
        id: pb.id,
        name: pb.name,
        category: pb.category,
        quantity: qty,
        unit: pb.unit,
        unitCost: pb.defaultCost,
        total,
        source: pb.isDefault ? 'pack_default' : 'price_book'
      });
    }
  });

  // 2. Apply Measurement Option Extra Costs
  pack.measureFields.forEach(field => {
    const val = measurements[field.id];
    if (field.options) {
      const opt = field.options.find(o => o.value === val);
      if (opt && opt.extraCost && opt.extraCost > 0) {
        lineItems.push({
          id: `opt_${field.id}_${opt.value}`,
          name: `${field.label}: ${opt.label}`,
          category: 'materials',
          quantity: 1,
          unit: 'item',
          unitCost: opt.extraCost,
          total: opt.extraCost,
          source: 'pack_default'
        });
      }
    }
  });

  // 3. Apply Question Answers (Section 7.3 & Bug #18)
  let contingencyTotal = 0;
  let notSureCount = 0;

  pack.questions.forEach(q => {
    const ansVal = answers[q.id];
    if (!ansVal) return;
    const opt = q.options.find(o => o.value === ansVal);
    if (!opt) return;

    if (ansVal === 'not_sure') {
      notSureCount++;
    }

    if (opt.priceEffect) {
      const amount = opt.priceEffect.amount || (opt.priceEffect.perSqM ? opt.priceEffect.perSqM * areaSqM : 0);
      if (amount > 0) {
        const isContingency = ansVal === 'not_sure';
        if (isContingency) {
          contingencyTotal += amount;
        }
        lineItems.push({
          id: `q_${q.id}_effect`,
          name: opt.priceEffect.description,
          category: opt.priceEffect.category || (isContingency ? 'extras' : 'materials'),
          quantity: 1,
          unit: 'item',
          unitCost: amount,
          total: amount,
          source: isContingency ? 'contingency' : 'pack_default',
          sourceDetail: q.text
        });
      }
    }
  });

  // 4. Calculate Labour Hours & Days
  // Base days from job type + area factor + complexity factors
  let baseHours = (jobType.baseLabourDays * 8) || (areaSqM * pack.labourRates.hoursPerSqM);
  
  // Complexity factors (steep pitch, high floor, etc.)
  let complexityMultiplier = 1.0;
  if (measurements.roof_pitch === 'steep' || measurements.ground_levels === 'steep') {
    complexityMultiplier += 0.15;
  }
  if (measurements.tallest_height && Number(measurements.tallest_height) < 2.2) {
    complexityMultiplier += 0.10;
  }
  if (answers.roof_supports === 'trusses') {
    complexityMultiplier += 0.20;
  }

  const totalLabourHours = Math.round(baseHours * complexityMultiplier);
  const labourCost = totalLabourHours * hourlyRate * (crewSize > 1 ? 1.5 : 1.0);
  const labourDays = Math.max(1, Math.ceil(totalLabourHours / (crewSize * 8)));

  lineItems.push({
    id: 'labour_work_time',
    name: `Work time (${labourDays} crew days)`,
    category: 'labor',
    quantity: totalLabourHours,
    unit: 'hours',
    unitCost: hourlyRate,
    total: Math.round(labourCost),
    source: 'pack_default'
  });

  // 5. Aggregate Categories
  let materials = 0;
  let labour = 0;
  let extras = 0;
  let fees = 0;

  lineItems.forEach(item => {
    if (item.category === 'materials') materials += item.total;
    else if (item.category === 'labor') labour += item.total;
    else if (item.category === 'extras') extras += item.total;
    else if (item.category === 'fees') fees += item.total;
  });

  const directCost = materials + labour + extras + fees;
  const overheadAmount = Math.round(directCost * overheadPct);
  const costBase = directCost + overheadAmount;

  // Formula: price = costBase / (1 - profitMargin%)
  // Ensure profitMarginPct < 1
  const safeMargin = Math.min(0.85, Math.max(0.05, profitMarginPct));
  let rawPrice = costBase / (1 - safeMargin);
  // Round to nearest 5
  let price = Math.round(rawPrice / 5) * 5;
  if (company.avgJobValue && price < 500) {
    price = 500;
  }

  const profit = price - costBase;
  const actualMarginPct = Number(((profit / price) * 100).toFixed(1));

  // Tax
  const taxPct = company.taxRatePct || 0;
  const taxAmount = Math.round(price * (taxPct / 100));
  const totalWithTax = price + taxAmount;

  // 6. Confidence Score Calculation (Section 7.6)
  let confidenceScore = 100;
  const penaltyReasons: Array<{ penalty: number; reason: string }> = [];

  const requiredPhotos = pack.photoShots.filter(p => p.required);
  const missingPhotos = Math.max(0, requiredPhotos.length - photosCount);
  if (missingPhotos > 0) {
    const photoPenalty = Math.min(40, missingPhotos * 20);
    confidenceScore -= photoPenalty;
    penaltyReasons.push({
      penalty: photoPenalty,
      reason: `Add ${missingPhotos} more ${missingPhotos === 1 ? 'photo' : 'photos'} to reach High.`
    });
  }

  if (notSureCount > 0) {
    const notSurePenalty = notSureCount * 10;
    confidenceScore -= notSurePenalty;
    penaltyReasons.push({
      penalty: notSurePenalty,
      reason: `Confirm ${notSureCount} "Not sure" ${notSureCount === 1 ? 'answer' : 'answers'} on site.`
    });
  }

  if (pastQuotesCount < 3) {
    confidenceScore -= 15;
    penaltyReasons.push({
      penalty: 15,
      reason: 'Add old quotes to sharpen your prices.'
    });
  }

  // Check sanity bands
  const band = pack.sanityBands[jobTypeId] || pack.sanityBands[Object.keys(pack.sanityBands)[0]];
  let inBand = true;
  let minExpected = 0;
  let maxExpected = 0;
  if (band && areaSqM > 0) {
    minExpected = Math.round(band.minPerSqM * areaSqM);
    maxExpected = Math.round(band.maxPerSqM * areaSqM);
    if (price < minExpected) {
      inBand = false;
      confidenceScore -= 10;
      penaltyReasons.push({
        penalty: 10,
        reason: 'This price is lower than your usual band. Check line items.'
      });
    } else if (price > maxExpected * 1.3) {
      inBand = false;
      confidenceScore -= 5;
      penaltyReasons.push({
        penalty: 5,
        reason: 'This price is higher than your usual band.'
      });
    }
  }

  // Cap at Medium if 0 photos (Bug #8)
  if (photosCount === 0 && confidenceScore >= 80) {
    confidenceScore = 75;
    penaltyReasons.unshift({
      penalty: 25,
      reason: 'Take at least 1 photo to reach High confidence.'
    });
  }

  confidenceScore = Math.max(25, Math.min(100, confidenceScore));
  const confidenceLevel = confidenceScore >= 80 ? 'high' : confidenceScore >= 50 ? 'medium' : 'low';
  
  // Pick the reason with highest penalty
  penaltyReasons.sort((a, b) => b.penalty - a.penalty);
  const confidenceReason = penaltyReasons[0]?.reason || 'Great! All details and photos confirmed.';

  // 7. Calculate Packages with Real Scope (Section 7.4)
  const packages = pack.packages.map(pkg => {
    const mods = pkg.scopeModifiers(measurements);
    let pkgCostBase = costBase;
    let pkgDays = labourDays;

    if (mods.addedItems) {
      const addedDirect = mods.addedItems.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);
      const addedOverhead = addedDirect * overheadPct;
      pkgCostBase += Math.round(addedDirect + addedOverhead);
    }
    if (mods.extraDays) {
      const extraLabourCost = mods.extraDays * 8 * hourlyRate * (crewSize > 1 ? 1.5 : 1.0);
      const extraOverhead = extraLabourCost * overheadPct;
      pkgCostBase += Math.round(extraLabourCost + extraOverhead);
      pkgDays += mods.extraDays;
    }

    const pkgRawPrice = pkgCostBase / (1 - safeMargin);
    const pkgPrice = Math.round(pkgRawPrice / 5) * 5;
    const pkgProfit = pkgPrice - pkgCostBase;

    return {
      id: pkg.id,
      name: pkg.name,
      price: pkgPrice,
      profit: pkgProfit,
      costBase: pkgCostBase,
      days: pkgDays,
      bullets: pkg.bullets
    };
  });

  return {
    materials,
    labour: Math.round(labourCost),
    extras,
    fees,
    directCost,
    overheadAmount,
    overheadPct: Number((overheadPct * 100).toFixed(1)),
    costBase,
    profitMarginPct: Number((safeMargin * 100).toFixed(1)),
    price,
    profit,
    actualMarginPct,
    taxPct,
    taxAmount,
    totalWithTax,
    labourDays,
    crewHours: totalLabourHours,
    lineItems,
    contingencyTotal,
    confidenceScore,
    confidenceLevel,
    confidenceReason,
    sanityCheck: {
      inBand,
      minExpected,
      maxExpected,
      message: inBand ? undefined : 'This quote is outside your typical price band.'
    },
    packages
  };
}

/**
 * Unit Test Runner to guarantee mathematical reconciliation:
 * price - costBase = profit
 * margin% = profit / price
 * lineItems sum to subtotal
 */
export function verifyEngineReconciliation(result: EngineResult): { passed: boolean; message: string } {
  const diff = Math.abs((result.costBase + result.profit) - result.price);
  if (diff > 1) {
    return { passed: false, message: `Failed price = costBase + profit: ${result.price} vs ${result.costBase} + ${result.profit}` };
  }
  const expectedMargin = (result.profit / result.price) * 100;
  if (Math.abs(expectedMargin - result.actualMarginPct) > 0.2) {
    return { passed: false, message: `Failed margin%: ${expectedMargin.toFixed(1)} vs ${result.actualMarginPct}` };
  }
  return { passed: true, message: 'Engine math reconciles perfectly.' };
}
