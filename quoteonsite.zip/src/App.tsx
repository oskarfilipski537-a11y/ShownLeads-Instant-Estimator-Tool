import React, { useState, useEffect } from 'react';
import { Session } from '@supabase/supabase-js';
import { supabase } from './lib/supabase';
import {
  fetchCompanyFromSupabase,
  saveCompanyToSupabase,
  fetchEstimatesFromSupabase,
  saveEstimateToSupabase,
  deleteEstimateFromSupabase,
  fetchPriceListFromSupabase,
  fetchPricingRulesFromSupabase,
  fetchPastQuotesFromSupabase,
} from './services/supabaseData';
import { DEFAULT_COMPANY_PROFILE, StorageService } from './services/storage';
import {
  AppSettings,
  CompanyProfile,
  Estimate,
  PriceListItem,
  PricingProfile,
  PricingRule,
} from './types';
import { getTradePack } from './tradePacks';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { OnboardingWizard } from './screens/OnboardingWizard';
import { HomeScreen } from './screens/HomeScreen';
import { NewEstimateWizard } from './screens/NewEstimateWizard';
import { EstimateResultScreen } from './screens/EstimateResultScreen';
import { HistoryScreen } from './screens/HistoryScreen';
import { PricingBrainScreen } from './screens/PricingBrainScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { TabBar, TabId } from './components/apple/TabBar';

export function App() {
  // Supabase Auth Session
  const [session, setSession] = useState<Session | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [dataLoading, setDataLoading] = useState(false);

  // App Data State (Backed by Supabase tables)
  const [company, setCompany] = useState<CompanyProfile>(DEFAULT_COMPANY_PROFILE);
  const [pricingProfile, setPricingProfile] = useState<PricingProfile>(() =>
    StorageService.getPricingProfile()
  );
  const [priceList, setPriceList] = useState<PriceListItem[]>([]);
  const [rules, setRules] = useState<PricingRule[]>([]);
  const [estimates, setEstimates] = useState<Estimate[]>([]);
  const [settings, setSettings] = useState<AppSettings>(() => StorageService.getSettings());

  // Navigation State
  const [isOnboarding, setIsOnboarding] = useState(false);
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [isCreatingEstimate, setIsCreatingEstimate] = useState(false);
  const [selectedEstimate, setSelectedEstimate] = useState<Estimate | null>(null);
  const [draftEstimate, setDraftEstimate] = useState<Estimate | null>(null);

  // Appearance Theme Handling (System / Light / Dark - Bug #5)
  useEffect(() => {
    const root = document.documentElement;
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const applyTheme = () => {
      const mode = settings.theme || 'system';
      const isDark = mode === 'dark' || (mode === 'system' && mediaQuery.matches);
      if (isDark) {
        root.classList.add('dark');
        root.classList.remove('light');
      } else {
        root.classList.remove('dark');
        root.classList.add('light');
      }
    };

    applyTheme();
    mediaQuery.addEventListener('change', applyTheme);
    return () => mediaQuery.removeEventListener('change', applyTheme);
  }, [settings.theme]);

  // Load user data from Supabase tables
  const loadUserData = async (userId: string) => {
    setDataLoading(true);
    try {
      // 1. Fetch Company from `companies` table where owner_id = userId
      const { company: existingCompany } = await fetchCompanyFromSupabase(userId);

      // Section 0.2: If user has no company row, route them to onboarding
      if (!existingCompany || !existingCompany.isOnboarded) {
        setCompany({
          ...DEFAULT_COMPANY_PROFILE,
          companyName: existingCompany?.companyName || '',
          primaryTrade: existingCompany?.primaryTrade || 'attic',
          isOnboarded: false,
        });
        setIsOnboarding(true);
        setDataLoading(false);
        return;
      }

      setCompany(existingCompany);

      // 2. Load Estimates, Price Lists, Rules, and Past Quotes from Supabase
      const companyId = existingCompany.id || userId;
      const [dbEstimates, dbPriceList, dbRules, dbPastQuotes] = await Promise.all([
        fetchEstimatesFromSupabase(companyId),
        fetchPriceListFromSupabase(companyId, existingCompany.primaryTrade),
        fetchPricingRulesFromSupabase(companyId),
        fetchPastQuotesFromSupabase(companyId),
      ]);

      setEstimates(dbEstimates);
      setPriceList(dbPriceList);
      setRules(dbRules);

      // Find draft estimate
      const draft = dbEstimates.find((e) => e.status === 'draft') || null;
      setDraftEstimate(draft);

      setPricingProfile((prev) => ({
        ...prev,
        pastQuotes: dbPastQuotes.length > 0 ? dbPastQuotes : prev.pastQuotes,
      }));
    } catch (err) {
      console.error('Error loading Supabase data:', err);
    } finally {
      setDataLoading(false);
    }
  };

  // Supabase Auth listener
  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data: { session: initialSession }, error }) => {
      if (mounted) {
        if (error) console.warn('Supabase getSession error:', error.message);
        setSession(initialSession);
        setAuthLoading(false);
        if (initialSession?.user) {
          loadUserData(initialSession.user.id);
        }
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, newSession) => {
      if (mounted) {
        setSession(newSession);
        setAuthLoading(false);
        if (newSession?.user) {
          loadUserData(newSession.user.id);
        } else {
          setCompany(DEFAULT_COMPANY_PROFILE);
          setEstimates([]);
          setIsOnboarding(false);
          setActiveTab('home');
        }
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  // Onboarding completion
  const handleOnboardingComplete = async (newProfile: CompanyProfile, goToBrain?: boolean) => {
    if (!session?.user) return;
    setDataLoading(true);

    const completedProfile: CompanyProfile = {
      ...newProfile,
      isOnboarded: true,
    };

    const { company: savedCompany } = await saveCompanyToSupabase(
      completedProfile,
      session.user.id
    );

    setCompany(savedCompany || completedProfile);
    setIsOnboarding(false);
    setDataLoading(false);

    if (goToBrain) {
      setActiveTab('brain');
    } else {
      setActiveTab('home');
    }
  };

  // Estimate Lifecycle Handlers
  const handleEstimateGenerated = async (newEstimate: Estimate) => {
    const companyId = company.id || session?.user?.id || 'default';
    setEstimates((prev) => [newEstimate, ...prev.filter((e) => e.id !== newEstimate.id)]);
    setIsCreatingEstimate(false);
    setSelectedEstimate(newEstimate);
    setDraftEstimate(null);
    await saveEstimateToSupabase(companyId, newEstimate);
  };

  const handleUpdateEstimate = async (updated: Estimate) => {
    const companyId = company.id || session?.user?.id || 'default';
    setEstimates((prev) => prev.map((e) => (e.id === updated.id ? updated : e)));
    setSelectedEstimate(updated);
    await saveEstimateToSupabase(companyId, updated);
  };

  const handleDeleteEstimate = async (id: string) => {
    setEstimates((prev) => prev.filter((e) => e.id !== id));
    if (selectedEstimate?.id === id) {
      setSelectedEstimate(null);
    }
    if (draftEstimate?.id === id) {
      setDraftEstimate(null);
    }
    await deleteEstimateFromSupabase(id);
  };

  const handleMarkOutcome = async (id: string, status: 'won' | 'lost', soldPrice?: number) => {
    const companyId = company.id || session?.user?.id || 'default';
    const target = estimates.find((e) => e.id === id);
    if (!target) return;

    const updated: Estimate = {
      ...target,
      status: status,
      total: soldPrice || target.total,
      updatedAt: Date.now(),
    };

    setEstimates((prev) => prev.map((e) => (e.id === id ? updated : e)));
    if (selectedEstimate?.id === id) {
      setSelectedEstimate(updated);
    }
    await saveEstimateToSupabase(companyId, updated);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setSession(null);
    setCompany(DEFAULT_COMPANY_PROFILE);
    setEstimates([]);
    setSelectedEstimate(null);
    setIsCreatingEstimate(false);
    setActiveTab('home');
  };

  // 1. Initial Loading Spinner
  if (authLoading) {
    return (
      <div className="min-h-screen bg-[var(--apple-bg)] flex items-center justify-center p-4">
        <div className="w-8 h-8 rounded-full border-2 border-[var(--apple-accent)] border-t-transparent animate-spin" />
      </div>
    );
  }

  // 2. Unauthenticated: Real Supabase Auth Welcome Screen
  if (!session) {
    return <WelcomeScreen onAuthSuccess={() => {}} />;
  }

  // 3. Authenticated but Needs Onboarding
  if (isOnboarding || !company.isOnboarded) {
    return (
      <OnboardingWizard
        initialProfile={company}
        userId={session.user.id}
        onComplete={handleOnboardingComplete}
        onBackToWelcome={() => handleSignOut()}
      />
    );
  }

  // 4. In Estimate Creation Wizard
  if (isCreatingEstimate) {
    return (
      <NewEstimateWizard
        company={company}
        pricingProfile={pricingProfile}
        userId={session.user.id}
        initialDraft={draftEstimate}
        onEstimateGenerated={handleEstimateGenerated}
        onCancel={() => {
          setIsCreatingEstimate(false);
          setActiveTab('home');
        }}
      />
    );
  }

  // 5. Viewing Generated Estimate Result Screen
  if (selectedEstimate) {
    return (
      <EstimateResultScreen
        estimate={selectedEstimate}
        company={company}
        pricingProfile={pricingProfile}
        activeRules={rules}
        onBack={() => setSelectedEstimate(null)}
        onUpdateEstimate={handleUpdateEstimate}
        onMarkOutcome={handleMarkOutcome}
      />
    );
  }

  // 6. Main App Screens with Apple TabBar
  return (
    <div className="min-h-screen bg-[var(--apple-bg)] flex flex-col">
      <main className="flex-1">
        {activeTab === 'home' && (
          <HomeScreen
            company={company}
            estimates={estimates}
            draftEstimate={draftEstimate}
            onNewEstimate={() => setIsCreatingEstimate(true)}
            onSelectEstimate={(est) => setSelectedEstimate(est)}
            onResumeDraft={(draft) => {
              setDraftEstimate(draft);
              setIsCreatingEstimate(true);
            }}
            onFilterQuotes={(status) => {
              setActiveTab('history');
            }}
          />
        )}

        {activeTab === 'history' && (
          <HistoryScreen
            estimates={estimates}
            onSelectEstimate={(est) => setSelectedEstimate(est)}
            onDeleteEstimate={handleDeleteEstimate}
            onMarkOutcome={handleMarkOutcome}
          />
        )}

        {activeTab === 'brain' && (
          <PricingBrainScreen
            company={company}
            pricingProfile={pricingProfile}
            priceList={priceList}
            rules={rules}
            userId={session.user.id}
            companyId={company.id}
            onUpdatePricingProfile={(p) => {
              setPricingProfile(p);
              StorageService.savePricingProfile(p);
            }}
            onUpdatePriceList={setPriceList}
            onUpdateRules={setRules}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsScreen
            company={company}
            settings={settings}
            estimates={estimates}
            onUpdateCompany={(updated) => {
              setCompany(updated);
              saveCompanyToSupabase(updated, session.user.id);
            }}
            onUpdateSettings={(updated) => {
              setSettings(updated);
              StorageService.saveSettings(updated);
            }}
            onSignOut={handleSignOut}
          />
        )}
      </main>

      {/* Modern Apple TabBar (Home, Quotes, + New, Prices, Settings) */}
      <TabBar
        activeTab={activeTab}
        onTabChange={(tab) => {
          if (tab === 'wizard') {
            setIsCreatingEstimate(true);
          } else {
            setActiveTab(tab);
          }
        }}
      />
    </div>
  );
}

export default App;
