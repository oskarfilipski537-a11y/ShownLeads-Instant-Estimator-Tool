export interface CompanyProfile {
  id?: string;
  companyName: string;
  logoUrl?: string;
  primaryTrade: string;
  otherTrades: string[];
  location: {
    city: string;
    state: string;
    country: string;
    zip: string;
    lat?: number;
    lng?: number;
  };
  serviceRadius: number;
  radiusUnit: 'miles' | 'km';
  companyType: string;
  crewSize: number;
  crewsRunning: number;
  avgJobValue: number;
  targetMargin: number; // e.g. 35 for 35%
  overheadPct: number; // e.g. 15 for 15%
  laborModel: 'hourly' | 'piece_rate' | 'subcontractor' | 'mix';
  loadedHourlyRate: number; // cost per worker hour
  billableHourlyRate?: number;
  travelPricing: {
    type: 'free' | 'flat' | 'per_mile' | 'per_mile_after_x';
    flatFee: number;
    perMileRate: number;
    freeRadiusMiles: number;
  };
  materialMarkupPct: number; // e.g. 25
  quoteStyle: 'single' | 'range' | 'options' | 'itemized';
  chargeAddons: {
    permits: { enabled: boolean; amount: number };
    dumpster: { enabled: boolean; amount: number };
    equipmentRental: { enabled: boolean; amount: number };
    mobilizationFee: { enabled: boolean; amount: number };
  };
  taxRatePct: number;
  paymentTerms: string;
  warranty: string;
  spotDiscount: {
    enabled: boolean;
    amount: number;
    label: string;
  };
  termsAndConditions: string;
  customerDisclaimer: string;
  isOnboarded: boolean;
}

export interface PhotoAsset {
  id: string;
  dataUrl: string;
  caption?: string;
  shotType: string;
  timestamp: number;
}

export interface QuestionAnswer {
  id: string;
  question: string;
  answer: string;
  reasonTag: string;
  options: string[];
}

export interface Flag {
  id: string;
  type: 'warning' | 'info' | 'risk' | 'code';
  title: string;
  detail: string;
  resolved: boolean;
  resolveField?: string;
  resolveActionLabel?: string;
}

export interface EstimateLineItem {
  id: string;
  category: 'materials' | 'labor' | 'travel' | 'equipment' | 'permits' | 'other';
  name: string;
  description?: string;
  quantity: number;
  unit: string;
  unitCost: number;
  markupPct: number;
  total: number;
  aiSuggested?: boolean;
  reasoningTag?: string;
}

export interface CostBreakdown {
  materialsBase: number;
  materialsMarkedUp: number;
  laborCost: number;
  laborHours: number;
  crewDays: number;
  travelCost: number;
  equipmentCost: number;
  permitsCost: number;
  subtotalCosts: number;
  overheadAmount: number;
  profitAmount: number;
  contingencyAmount: number;
  preTaxTotal: number;
  taxAmount: number;
  totalExact: number;
  rangeLow: number;
  rangeHigh: number;
  confidence: 'high' | 'medium' | 'low';
  confidenceScore: number;
  confidenceReasons: string[];
  appliedRules: string[];
  historicalDeviationPct?: number;
}

export interface TierOption {
  name: string;
  badge: string;
  subtitle: string;
  total: number;
  scopeSummary?: string[];
  specHighlights?: string[];
  lineItems?: EstimateLineItem[];
  breakdown: CostBreakdown;
  isPopular?: boolean;
  inclusions?: string[];
  warrantyYears?: number;
  timelineWeeks?: string;
}

export interface CustomerInfo {
  name: string;
  phone: string;
  email: string;
  address: string;
  oneWayMiles?: number;
}

export interface Estimate {
  id: string;
  companyId?: string;
  estimateNumber?: string;
  createdAt: any;
  updatedAt: any;
  status: 'draft' | 'sent' | 'won' | 'lost' | 'presented';
  soldPrice?: number;
  total?: number;
  customer?: CustomerInfo;
  customerName?: string;
  customerAddress?: string;
  customerPhone?: string;
  customerEmail?: string;
  jobType?: string;
  subTypes?: string[];
  photos: PhotoAsset[];
  description?: string;
  notes?: string;
  measurements: {
    squareFootage: number;
    length?: number;
    width?: number;
    existingDepthInches?: number;
    targetRValue?: number;
    ceilingHeightFeet?: number;
    roofPitch?: string;
    accessPointCount?: number;
    storyCount?: number;
    [key: string]: any;
  };
  measurementConfirmed?: Record<string, boolean>;
  measurementAiSuggested?: Record<string, boolean>;
  questions?: QuestionAnswer[];
  answers?: Record<string, string>;
  flags?: Flag[];
  lineItems: EstimateLineItem[];
  costBreakdown: CostBreakdown;
  scopeBullets?: string[];
  goodBetterBest?: {
    good: TierOption;
    better: TierOption;
    best: TierOption;
  };
  options?: any;
  selectedTier?: 'good' | 'better' | 'best';
  viewMode?: 'contractor' | 'customer';
  priceDisplayMode?: 'exact' | 'range';
  spotDiscountApplied?: boolean;
  validDays?: number;
  signature?: {
    name?: string;
    signerName?: string;
    date?: string;
    dataUrl?: string;
    signatureDataUrl?: string;
    timestamp?: number;
  };
}

export interface PastQuote {
  id: string;
  title: string;
  fileName?: string;
  date: string;
  jobType: string;
  customerName?: string;
  totalAmount: number;
  sqFt?: number;
  scopeNotes: string;
  lineItems: EstimateLineItem[];
  confirmed: boolean;
}

export interface PriceListItem {
  id: string;
  trade: string;
  category: 'materials' | 'labor' | 'equipment' | 'services';
  name: string;
  unit: string;
  unitCost: number;
  defaultMarkup: number;
  notes?: string;
}

export interface PricingRule {
  id: string;
  name: string;
  description?: string;
  enabled?: boolean;
  active?: boolean;
  conditionType?: 'access_difficulty' | 'min_job_charge' | 'vermiculite_sanitizing' | 'low_headroom' | 'multi_story';
  parameter?: any;
  condition?: string;
  effectType?: 'surcharge_fixed' | 'surcharge_pct' | 'minimum_total';
  effectValue?: number;
  adjustmentType?: string;
  adjustmentValue?: number;
  category?: string;
}

export interface PricingProfile {
  tradeKey: string;
  pricePerSqFtRanges: Record<string, { min: number; avg: number; max: number }>;
  typicalMaterialMarkup: number;
  laborHoursPerSqFt: Record<string, number>;
  typicalAddons: string[];
  pastQuotes: PastQuote[];
  wonDeltaRecords: Array<{ estimateId: string; quoted: number; sold: number; deltaPct: number; date: string }>;
  accuracyLevel: number; // 0 to 100
}

export interface SupabaseConfig {
  url: string;
  anonKey: string;
  tableName?: string;
  isConnected?: boolean;
  lastSyncTime?: string;
  syncStatus?: 'idle' | 'syncing' | 'success' | 'error';
  errorMessage?: string;
  autoSync?: boolean;
}

export interface GoogleAuthConfig {
  clientId: string;
  clientSecret?: string;
  isConnected?: boolean;
  userEmail?: string;
  userName?: string;
  userAvatar?: string;
  lastLoginAt?: string;
  authError?: string;
}

export interface AppSettings {
  theme: 'dark' | 'light' | 'system';
  units: 'imperial' | 'metric';
  unitSystem?: 'imperial' | 'metric';
  currency: string;
  currencySymbol: string;
  defaultValidityDays: number;
  showLineItemsToCustomer: boolean;
  allowRangeToCustomer: boolean;
  userEmail?: string;
  isAuthenticated: boolean;
  supabase?: SupabaseConfig;
  googleAuth?: GoogleAuthConfig;
}

