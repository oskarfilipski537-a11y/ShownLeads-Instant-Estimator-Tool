export const APP_CONFIG = {
  name: 'ShownLeads Instant Estimator',
  tagline: 'Quote on the spot. Win the job.',
  version: '1.0.0',
  primaryTrade: 'Kitchen & Bath Remodel',
  defaultCurrency: '$',
  themeAccentGradient: 'from-[#5B6CFF] to-[#8A5CFF]',
  themeAccentColor: '#5B6CFF',
  supportEmail: 'support@shownleads.com',
  geminiModel: 'gemini-3.8-flash',
};
