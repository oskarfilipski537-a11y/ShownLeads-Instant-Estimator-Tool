import { PriceListItem, PricingRule } from '../types';

export interface TradeConfig {
  id: string;
  name: string;
  category: 'insulation' | 'remodel' | 'roofing' | 'flooring' | 'painting' | 'general';
  iconName: string;
  subtypes: string[];
  photoShotList: Array<{ id: string; label: string; description: string; required: boolean }>;
  defaultPriceList: PriceListItem[];
  defaultRules: PricingRule[];
  defaultProductivity: {
    sqFtPerCrewHour: number;
    defaultCrewSize: number;
  };
  keyHazards: string[];
  climateZones?: Array<{ zone: string; states: string; rValueTarget: number; recommendedInches: number }>;
  goodBetterBestTemplates?: {
    good: { name: string; spec: string; multiplier: number };
    better: { name: string; spec: string; multiplier: number };
    best: { name: string; spec: string; multiplier: number };
  };
}

export const TRADES: Record<string, TradeConfig> = {
  'kitchen-bath': {
    id: 'kitchen-bath',
    name: 'Kitchen & Bath Remodel',
    category: 'remodel',
    iconName: 'Bath',
    subtypes: [
      'Master bathroom renovation',
      'Guest bath refresh',
      'Custom kitchen remodel',
      'Walk-in tile shower conversion',
      'Cabinetry & quartz replacement',
      'Plumbing & electrical relocation',
    ],
    photoShotList: [
      { id: 'overview', label: 'Room overview', description: 'Wide perspective showing layout and fixture placement', required: true },
      { id: 'wet-area', label: 'Shower / vanity / wet wall', description: 'Existing plumbing fixture locations and valves', required: true },
      { id: 'cabinets', label: 'Cabinets & countertop run', description: 'Linear cabinet layout and existing appliances', required: true },
      { id: 'electrical', label: 'Electrical switches & panel', description: 'GFCI locations and home electrical panel clearance', required: false },
      { id: 'flooring', label: 'Subfloor transition', description: 'Doorway threshold and height difference to adjoining room', required: false },
    ],
    defaultProductivity: { sqFtPerCrewHour: 25, defaultCrewSize: 2 },
    keyHazards: [
      'Subfloor moisture rot under toilet or shower pan',
      'Galvanized or polybutylene supply piping requiring repipe',
      'Load-bearing wall removal requiring engineered structural beam',
      'Sub-panel required for high-draw induction or double ovens',
    ],
    goodBetterBestTemplates: {
      good: {
        name: 'Essential Refresh',
        spec: 'Stock vanity/cabinetry, acrylic tub/shower surround, quartz vanity top, and standard plumbing trim.',
        multiplier: 0.75,
      },
      better: {
        name: 'Semi-Custom Upgrade',
        spec: 'Solid maple cabinetry, Schluter-Kerdi waterproof tiled shower with frameless glass, quartz counters, and LED lighting.',
        multiplier: 1.0,
      },
      best: {
        name: 'Luxury Designer Suite',
        spec: 'Full layout reconfiguration, curbless walk-in shower with linear drain, custom Amish cabinetry, heated tile floor, and high-end fixtures.',
        multiplier: 1.65,
      },
    },
    defaultRules: [
      {
        id: 'rule-min-remodel',
        name: 'Minimum Remodel Mobilization',
        description: 'Minimum charge for bathroom or kitchen scope is $4,500',
        enabled: true,
        conditionType: 'min_job_charge',
        effectType: 'minimum_total',
        effectValue: 4500,
      },
    ],
    defaultPriceList: [
      { id: 'mat-tile-sq', trade: 'kitchen-bath', category: 'materials', name: 'Designer Porcelain Tile & Setting Materials', unit: 'sq-ft', unitCost: 9.5, defaultMarkup: 25 },
      { id: 'mat-quartz-sq', trade: 'kitchen-bath', category: 'materials', name: 'Prefab Quartz Slab Countertops (per sq ft fabricated)', unit: 'sq-ft', unitCost: 65.0, defaultMarkup: 25 },
      { id: 'mat-shower-pan', trade: 'kitchen-bath', category: 'materials', name: 'Schluter-Kerdi Waterproof Shower Pan & Drain System', unit: 'kit', unitCost: 680.0, defaultMarkup: 30 },
      { id: 'mat-vanity-combo', trade: 'kitchen-bath', category: 'materials', name: 'Solid Wood Vanity & Undermount Sink Combo', unit: 'ea', unitCost: 1250.0, defaultMarkup: 25 },
      { id: 'mat-cabinets-lf', trade: 'kitchen-bath', category: 'materials', name: 'Plywood-Box Soft-Close Cabinetry (Linear Foot)', unit: 'linear-ft', unitCost: 195.0, defaultMarkup: 25 },
    ],
  },

  'attic-conversion': {
    id: 'attic-conversion',
    name: 'Attic Conversion / Remodel',
    category: 'remodel',
    iconName: 'Home',
    subtypes: [
      'Finished bonus room',
      'Master bedroom suite',
      'Home office buildout',
      'Dormer addition',
      'Staircase installation',
      'Full conversion with bathroom',
    ],
    photoShotList: [
      { id: 'overall', label: 'Attic overall space', description: 'Full view showing span between knee walls and ridge', required: true },
      { id: 'rafters', label: 'Rafters & framing', description: 'Conventional 2x rafters vs engineered trusses', required: true },
      { id: 'joists', label: 'Floor joist size & spacing', description: 'Lumber depth (2x6 vs 2x8+)', required: true },
      { id: 'height', label: 'Ceiling height ridge measure', description: 'Center ridge clearance showing 7ft code zone', required: true },
      { id: 'stair-below', label: 'Stair location from below', description: 'Landing area for code-compliant staircase', required: true },
    ],
    defaultProductivity: { sqFtPerCrewHour: 45, defaultCrewSize: 3 },
    keyHazards: [
      'Undersized floor joists (2x6 ceiling joists cannot carry 30 psf live load without sistering)',
      'Headroom code violation: less than 50% of finished area at 7ft clearance',
      'Emergency egress window net clear opening under 5.7 sq ft or sill > 44"',
      'No viable code-compliant staircase run (requires 36" width, 6\'8" head clearance)',
    ],
    goodBetterBestTemplates: {
      good: {
        name: 'Basic Finished Flex Space',
        spec: 'Knee-wall framing, drywall, LED lighting, basic trim, subfloor reinforcement, and mini-split heating/cooling.',
        multiplier: 0.8,
      },
      better: {
        name: 'Finished Suite with Egress Dormer',
        spec: 'Shed dormer addition for expanded headroom, code egress casement windows, luxury vinyl plank flooring, and custom closet built-ins.',
        multiplier: 1.0,
      },
      best: {
        name: 'Luxury Primary Suite with Full Bath',
        spec: 'Engineered joist reinforcement, full 3-piece designer bath with tile shower, custom staircase, twin dormers, and spray-foam hot roof.',
        multiplier: 1.75,
      },
    },
    defaultRules: [
      {
        id: 'rule-min-conversion',
        name: 'Minimum Conversion Scope',
        description: 'Minimum mobilization for conversion project is $12,500',
        enabled: true,
        conditionType: 'min_job_charge',
        effectType: 'minimum_total',
        effectValue: 12500,
      },
    ],
    defaultPriceList: [
      { id: 'mat-framing-lumber', trade: 'attic-conversion', category: 'materials', name: 'Framing Lumber Pack (2x4 & 2x6 SPF)', unit: 'lot', unitCost: 1850.0, defaultMarkup: 25 },
      { id: 'mat-drywall', trade: 'attic-conversion', category: 'materials', name: 'Drywall 1/2" Sheetrock & Finishing Compound', unit: 'sq-ft', unitCost: 1.85, defaultMarkup: 25 },
      { id: 'mat-subfloor', trade: 'attic-conversion', category: 'materials', name: '3/4" T&G OSB Subfloor & Structural Adhesive', unit: 'sq-ft', unitCost: 2.4, defaultMarkup: 25 },
      { id: 'mat-minisplit', trade: 'attic-conversion', category: 'materials', name: 'Ductless Heat Pump Mini-Split (12,000 BTU 20 SEER)', unit: 'unit', unitCost: 1650.0, defaultMarkup: 30 },
      { id: 'mat-egress-win', trade: 'attic-conversion', category: 'materials', name: 'Code Egress Casement Window & Flashing Kit', unit: 'ea', unitCost: 650.0, defaultMarkup: 25 },
    ],
  },

  'attic-insulation': {
    id: 'attic-insulation',
    name: 'Attic Insulation',
    category: 'insulation',
    iconName: 'ShieldAlert',
    subtypes: [
      'Blown-in cellulose',
      'Blown-in fiberglass',
      'Spray foam (open cell)',
      'Spray foam (closed cell)',
      'Batt insulation',
      'Insulation removal & vac',
      'Perimeter air sealing',
      'Baffles & ventilation chutes',
      'Rodent proofing & sanitizing',
    ],
    photoShotList: [
      { id: 'overview', label: 'Attic overview', description: 'Wide shot from access hatch showing floor and rafters', required: true },
      { id: 'depth', label: 'Insulation depth ruler', description: 'Close-up of tape measure in existing insulation', required: true },
      { id: 'access', label: 'Access hatch / opening', description: 'Attic stairway or ceiling scuttle frame', required: true },
      { id: 'eaves', label: 'Eaves & soffit vents', description: 'Perimeter where roof meets wall top plate', required: false },
      { id: 'penetrations', label: 'Can lights & flues', description: 'Recessed lights, exhaust fans, chimneys', required: false },
    ],
    climateZones: [
      { zone: 'Zones 1-2 (Deep South)', states: 'FL, South TX, Gulf Coast', rValueTarget: 38, recommendedInches: 10.5 },
      { zone: 'Zones 3-4 (Mid-Atlantic & Central)', states: 'NC, VA, TN, MO, KS, KY', rValueTarget: 49, recommendedInches: 13.5 },
      { zone: 'Zones 5-8 (North & Mountain)', states: 'NY, PA, OH, MI, IL, MN, CO, New England', rValueTarget: 60, recommendedInches: 16.5 },
    ],
    defaultProductivity: { sqFtPerCrewHour: 400, defaultCrewSize: 2 },
    keyHazards: [
      'Active knob-and-tube electrical wiring (fire hazard if buried)',
      'Suspected vermiculite / zonolite insulation (possible asbestos)',
      'Non-IC rated recessed fixtures without fire-rated covers',
      'Bathroom exhaust vents dumping moisture directly into attic',
      'Drywall ceiling sagging under excess cellulose weight',
    ],
    goodBetterBestTemplates: {
      good: {
        name: 'Standard R-38 Upgrade',
        spec: 'Blowing R-38 Borate-treated cellulose over existing layer with hatch weatherstrip.',
        multiplier: 0.85,
      },
      better: {
        name: 'High-Performance R-49 Air Seal',
        spec: 'Comprehensive polyurethane air sealing of top plates & penetrations, raft baffles, and R-49 blown-in cellulose.',
        multiplier: 1.0,
      },
      best: {
        name: 'Complete Sanitization & R-60 Thermal Shield',
        spec: 'Full HEPA removal of contaminated old material, anti-microbial fogging, complete air seal, and R-60 premium blown insulation.',
        multiplier: 1.65,
      },
    },
    defaultRules: [
      {
        id: 'rule-min-job',
        name: 'Minimum Job Ticket',
        description: 'Enforce minimum price of $1,450 for any truck mobilization',
        enabled: true,
        conditionType: 'min_job_charge',
        effectType: 'minimum_total',
        effectValue: 1450,
      },
    ],
    defaultPriceList: [
      { id: 'mat-cell-bag', trade: 'attic-insulation', category: 'materials', name: 'Blown-In Cellulose Insulation (25 lb bag)', unit: 'bag', unitCost: 18.5, defaultMarkup: 25 },
      { id: 'mat-fg-bag', trade: 'attic-insulation', category: 'materials', name: 'Blown-In Fiberglass Insulation (30 lb bag)', unit: 'bag', unitCost: 22.0, defaultMarkup: 25 },
      { id: 'mat-airseal-foam', trade: 'attic-insulation', category: 'materials', name: 'Polyurethane Air Seal Expanding Foam Kit', unit: 'kit', unitCost: 145.0, defaultMarkup: 30 },
      { id: 'mat-baffle', trade: 'attic-insulation', category: 'materials', name: 'Rafter-Vent Soffit Baffle (22"x48")', unit: 'piece', unitCost: 4.25, defaultMarkup: 35 },
      { id: 'mat-hatch-cover', trade: 'attic-insulation', category: 'materials', name: 'Attic Stair/Hatch Insulated Cover Box (R-13)', unit: 'ea', unitCost: 85.0, defaultMarkup: 40 },
    ],
  },

  'roofing': {
    id: 'roofing',
    name: 'Roofing',
    category: 'roofing',
    iconName: 'Layers',
    subtypes: [
      'Architectural asphalt shingles',
      'Standing seam metal roof',
      'Flat roof TPO / EPDM',
      'Complete tear-off & re-deck',
      'Emergency leak repair & flashing',
    ],
    photoShotList: [
      { id: 'overview', label: 'Full roofline elevation', description: 'All roof planes from ground', required: true },
      { id: 'shingle', label: 'Shingle wear & granular loss', description: 'Curling, missing tabs, or hail damage', required: true },
      { id: 'valleys', label: 'Valleys and flashing', description: 'Chimney, wall step flashing, and vent pipe boots', required: true },
    ],
    defaultProductivity: { sqFtPerCrewHour: 250, defaultCrewSize: 4 },
    keyHazards: ['Steep pitch > 8/12 requires roof harness tie-offs', 'Rotted decking around chimney and valleys'],
    defaultRules: [],
    defaultPriceList: [
      { id: 'mat-shingle-sq', trade: 'roofing', category: 'materials', name: 'Architectural Shingles (per Square / 100 sq ft)', unit: 'sq', unitCost: 135.0, defaultMarkup: 25 },
      { id: 'mat-underlay', trade: 'roofing', category: 'materials', name: 'Synthetic Underlayment & Ice/Water Shield', unit: 'sq', unitCost: 38.0, defaultMarkup: 25 },
      { id: 'mat-drip-edge', trade: 'roofing', category: 'materials', name: 'Aluminum Drip Edge (10ft piece)', unit: 'pc', unitCost: 12.5, defaultMarkup: 30 },
    ],
  },

  'spray-foam': {
    id: 'spray-foam',
    name: 'Spray Foam Insulation',
    category: 'insulation',
    iconName: 'Shield',
    subtypes: ['Open cell attic roof deck', 'Closed cell pole barn', 'Crawl space encapsulation', 'Rim joist sealing'],
    photoShotList: [
      { id: 'cavity', label: 'Stud/rafter cavity depth', description: 'Depth of framing members', required: true },
      { id: 'decking', label: 'Underside of roof deck', description: 'Substrate condition and dryness', required: true },
    ],
    defaultProductivity: { sqFtPerCrewHour: 300, defaultCrewSize: 2 },
    keyHazards: ['Chemical off-gassing requires 24h occupant vacancy', 'Substrate moisture > 18%'],
    defaultRules: [],
    defaultPriceList: [
      { id: 'mat-foam-oc', trade: 'spray-foam', category: 'materials', name: 'Open-Cell Spray Foam Formulation', unit: 'bd-ft', unitCost: 0.85, defaultMarkup: 30 },
      { id: 'mat-foam-cc', trade: 'spray-foam', category: 'materials', name: 'Closed-Cell Spray Foam Formulation', unit: 'bd-ft', unitCost: 1.55, defaultMarkup: 30 },
    ],
  },

  'flooring': {
    id: 'flooring',
    name: 'Flooring',
    category: 'flooring',
    iconName: 'Square',
    subtypes: ['Luxury vinyl plank (LVP)', 'Solid hardwood installation', 'Engineered hardwood', 'Porcelain tile', 'Carpet tear-out & replace'],
    photoShotList: [
      { id: 'room-view', label: 'Room floor overview', description: 'Wide view of floor area and thresholds', required: true },
      { id: 'subfloor', label: 'Subfloor & transition', description: 'Transition heights and subfloor condition', required: true },
    ],
    defaultProductivity: { sqFtPerCrewHour: 100, defaultCrewSize: 2 },
    keyHazards: ['Uneven subfloor requiring self-leveling compound', 'Moisture emission on concrete slab'],
    defaultRules: [],
    defaultPriceList: [
      { id: 'mat-lvp', trade: 'flooring', category: 'materials', name: '20-Mil Waterproof Luxury Vinyl Plank', unit: 'sq-ft', unitCost: 3.25, defaultMarkup: 25 },
      { id: 'mat-underlay-floor', trade: 'flooring', category: 'materials', name: 'Acoustic Sound & Moisture Underlayment', unit: 'sq-ft', unitCost: 0.55, defaultMarkup: 30 },
      { id: 'mat-baseboard', trade: 'flooring', category: 'materials', name: 'Primed MDF Baseboard & Quarter Round (Linear Ft)', unit: 'linear-ft', unitCost: 1.85, defaultMarkup: 25 },
    ],
  },

  'painting': {
    id: 'painting',
    name: 'Painting',
    category: 'painting',
    iconName: 'Paintbrush',
    subtypes: ['Interior walls & ceilings', 'Exterior siding & trim', 'Cabinet spraying & refinishing', 'Drywall repair & texturing'],
    photoShotList: [
      { id: 'walls', label: 'Wall and ceiling condition', description: 'Lighting, patches, or peeling areas', required: true },
      { id: 'trim', label: 'Doors and trim detail', description: 'Baseboards, casings, and crown molding', required: true },
    ],
    defaultProductivity: { sqFtPerCrewHour: 150, defaultCrewSize: 2 },
    keyHazards: ['Pre-1978 lead paint regulations', 'Water stains requiring shellac primer'],
    defaultRules: [],
    defaultPriceList: [
      { id: 'mat-paint-gal', trade: 'painting', category: 'materials', name: 'Premium Interior Acrylic Latex Paint (per Gallon)', unit: 'gal', unitCost: 55.0, defaultMarkup: 25 },
      { id: 'mat-primer', trade: 'painting', category: 'materials', name: 'Stain-Blocking Bonding Primer', unit: 'gal', unitCost: 38.0, defaultMarkup: 25 },
    ],
  },

  'general-contractor': {
    id: 'general-contractor',
    name: 'General Contractor',
    category: 'general',
    iconName: 'Hammer',
    subtypes: ['Full home remodel', 'Room addition', 'Basement finish', 'Structural repair & beam install'],
    photoShotList: [
      { id: 'overall', label: 'Overall project area', description: 'Wide shot of scope', required: true },
      { id: 'mep', label: 'Mechanical, electrical & plumbing', description: 'Panel, lines, and structural walls', required: false },
    ],
    defaultProductivity: { sqFtPerCrewHour: 50, defaultCrewSize: 3 },
    keyHazards: ['Load-bearing wall removal requires engineer stamp', 'Asbestos or lead paint'],
    defaultRules: [],
    defaultPriceList: [
      { id: 'mat-misc-gc', trade: 'general-contractor', category: 'materials', name: 'Standard Construction Material Allowance', unit: 'sq-ft', unitCost: 28.0, defaultMarkup: 25 },
    ],
  },
};

export const ALL_TRADE_OPTIONS = [
  { id: 'kitchen-bath', name: 'Kitchen & Bath Remodel', icon: 'Bath', highlight: true },
  { id: 'attic-conversion', name: 'Attic Conversion / Remodel', icon: 'Home', highlight: true },
  { id: 'attic-insulation', name: 'Attic Insulation', icon: 'ShieldAlert', highlight: true },
  { id: 'roofing', name: 'Roofing', icon: 'Layers' },
  { id: 'spray-foam', name: 'Spray Foam', icon: 'Shield' },
  { id: 'flooring', name: 'Flooring', icon: 'Square' },
  { id: 'painting', name: 'Painting', icon: 'Paintbrush' },
  { id: 'general-contractor', name: 'General Contractor', icon: 'Hammer' },
  { id: 'windows-doors', name: 'Windows & Doors', icon: 'Maximize' },
  { id: 'siding', name: 'Siding', icon: 'LayoutGrid' },
  { id: 'hvac', name: 'HVAC', icon: 'Thermometer' },
  { id: 'plumbing', name: 'Plumbing', icon: 'Droplets' },
  { id: 'electrical', name: 'Electrical', icon: 'Zap' },
  { id: 'decks', name: 'Decks & Porches', icon: 'Maximize2' },
];

export function getTradeConfig(tradeIdOrName: string): TradeConfig {
  const normalized = (tradeIdOrName || '').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  if (TRADES[normalized]) return TRADES[normalized];
  if (normalized.includes('kitchen') || normalized.includes('bath')) return TRADES['kitchen-bath'];
  if (normalized.includes('conversion') || normalized.includes('remodel')) return TRADES['attic-conversion'];
  if (normalized.includes('insulation')) return TRADES['attic-insulation'];
  if (normalized.includes('roof')) return TRADES['roofing'];
  if (normalized.includes('foam')) return TRADES['spray-foam'];
  if (normalized.includes('floor')) return TRADES['flooring'];
  if (normalized.includes('paint')) return TRADES['painting'];
  return TRADES['general-contractor'];
}

export function getTradeCategory(tradeIdOrName: string): 'insulation' | 'remodel' | 'roofing' | 'flooring' | 'painting' | 'general' {
  const config = getTradeConfig(tradeIdOrName);
  return config.category;
}
