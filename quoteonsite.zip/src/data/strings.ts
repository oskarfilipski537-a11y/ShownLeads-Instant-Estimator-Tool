/**
 * String Table for ShownLeads Instant Estimator
 * Reading level: Grade 3 or lower. Words a child knows.
 * Short sentences. Max 8 words per label, 12 words per sentence.
 * No banned words.
 */

export const UI_STRINGS = {
  app: {
    name: 'ShownLeads Instant Estimator',
    tagline: 'Quotes in under 3 minutes'
  },
  tabs: {
    home: 'Home',
    quotes: 'Quotes',
    newQuote: 'New',
    prices: 'Prices',
    settings: 'Settings'
  },
  home: {
    greeting: (name: string) => `Hi ${name || 'there'}`,
    newQuoteButton: 'New quote',
    continueDraft: (customerName: string) => `Continue ${customerName}'s quote`,
    monthTitle: 'This month',
    statSent: 'Sent',
    statWon: 'Won',
    statEarned: 'Won money',
    followUpTitle: 'Needs follow-up',
    followUpEmpty: 'No quotes need follow-up today.',
    callButton: 'Call',
    messageButton: 'Message',
    recentQuotesTitle: 'Recent quotes',
    noQuotesYet: 'No quotes yet. Make your first one.',
    makeQuoteBtn: 'Make a quote'
  },
  quotes: {
    title: 'Quotes',
    searchPlaceholder: 'Search by customer name...',
    all: 'All',
    open: 'Open',
    won: 'Won',
    lost: 'Lost',
    noMatchingQuotes: 'No quotes match this filter.',
    deleteUndo: 'Quote deleted. Tap to undo.',
    markWon: 'Mark won',
    markLost: 'Mark lost',
    markSent: 'Mark sent'
  },
  wizard: {
    steps: {
      who: 'Who & where',
      photos: 'Photos & notes',
      measure: 'Size of the job',
      questions: 'Questions'
    },
    step1Title: 'Who & where',
    step1Helper: 'Enter the customer and pick the job.',
    customerNameLabel: 'Customer name',
    customerNamePlaceholder: 'First and last name',
    addressLabel: 'Job address',
    addressPlaceholder: 'Street, city, postcode',
    phoneLabel: 'Phone (optional)',
    phonePlaceholder: 'Mobile number',
    emailLabel: 'Email (optional)',
    emailPlaceholder: 'customer@example.com',
    jobTypeLabel: 'Job type',

    step2Title: 'Photos & notes',
    step2Helper: 'Take a few photos. They set your price.',
    takePhotoButton: 'Take photo',
    choosePhotoButton: 'Pick photo',
    retakePhotoButton: 'Retake',
    notesLabel: 'Job notes',
    notesHelper: 'Tell me about the job. Talk or type.',
    notesPlaceholder: 'Type or speak notes about this job...',
    voiceStart: 'Talk note',
    voiceStop: 'Stop listening',

    step3Title: 'Size of the job',
    step3Helper: 'Enter the main sizes below.',
    floorAreaLive: (area: string) => `Floor area: ${area}`,
    usableAreaLive: (pct: number) => `${pct}% of floor has full head height`,
    lowHeadroomWarning: 'Head height is low. Check local rules.',

    step4Title: 'Questions',
    step4Helper: 'Answer these to get your exact price.',
    answered: 'Answered',
    questionsLeft: (n: number) => `${n} ${n === 1 ? 'question' : 'questions'} left`,
    getPriceButton: 'Get price',

    buttons: {
      next: 'Next',
      back: 'Back',
      cancel: 'Cancel',
      saveAndExit: 'Save draft'
    },
    autosave: {
      saved: 'Saved',
      offline: 'Offline – will sync'
    }
  },
  estimate: {
    youTab: 'You',
    customerTab: 'Customer',
    yourPrice: 'Your price',
    yourCosts: 'Your costs',
    yourProfit: 'Your profit',
    workTime: 'Work time',
    days: (n: number) => `${n} days`,
    confidenceTitle: 'How sure am I?',
    confidenceLevels: {
      high: 'High',
      medium: 'Medium',
      low: 'Low'
    },
    viewMode: {
      exact: 'Exact',
      range: 'Range'
    },
    pickPackage: 'Pick a package',
    comparePackages: 'Compare packages',
    checkBeforeStart: 'Check before you start',
    doneButton: 'Done',
    whereMoneyGoes: 'Where the money goes',
    materialsGroup: 'Materials',
    laborGroup: 'Work time',
    extrasGroup: 'Extras',
    feesGroup: 'Fees',
    addItem: 'Add item',
    shoppingListTitle: 'Shopping list',
    crewPlanTitle: 'Crew plan',
    shareListButton: 'Share shopping list',
    shareCrewButton: 'Share crew plan',
    sendQuoteButton: 'Send quote',
    markAsMenu: 'Mark as',

    customerView: {
      quoteTitle: 'Quote',
      validFor30Days: 'Valid for 30 days',
      preparedFor: 'Prepared for',
      jobLocation: 'Job address',
      includedTitle: "What's included",
      notIncludedTitle: "What's not included",
      scheduleTitle: 'Work time & schedule',
      startsWithin: 'Starts in 1–2 weeks',
      durationText: (d: number) => `About ${d} working days`,
      paymentTitle: 'How you pay',
      warrantyTitle: 'Warranty',
      acceptButton: 'Accept this quote',
      signPrompt: 'Type your full name to sign:',
      signPlaceholder: 'Your full legal name',
      signDate: (d: string) => `Signed on ${d}`,
      signedSuccess: 'Thank you! Quote accepted.'
    }
  },
  prices: {
    title: 'Your prices',
    introCard: (n: number) => n > 0
      ? `I know your prices from ${n} quotes. Add more to get sharper.`
      : 'Add old quotes. I will learn your prices.',
    ratesTitle: 'Your rates',
    hourlyRateLabel: 'Hourly rate per worker',
    crewSizeLabel: 'Crew size',
    materialsTitle: 'Your materials',
    oldQuotesTitle: 'Old quotes',
    uploadQuoteBtn: 'Add old quote',
    myRulesTitle: 'My rules',
    addRuleBtn: 'Add rule',
    ruleExampleFlag: 'Example'
  },
  settings: {
    title: 'Settings',
    businessGroup: 'Business',
    companyName: 'Company name',
    contractorName: 'Your name',
    phone: 'Phone number',
    trade: 'Trade',
    changeTradeWarning: 'Changing trade changes your price book and questions.',
    country: 'Country & Currency',
    numbersGroup: 'My numbers',
    hourlyRate: 'Hourly rate',
    hourlyHelper: 'Cost per worker hour',
    crewSize: 'Crew size',
    crewHelper: 'People on a job',
    marginWanted: 'Profit wanted (%)',
    marginHelper: 'Profit you want from each job',
    overheadPct: 'Overhead (%)',
    overheadHelper: 'Van, tools, insurance',
    minJobPrice: 'Minimum job price',
    minJobHelper: 'Smallest job you will take',
    travelFee: 'Travel fee',
    taxRate: 'Tax rate (%)',
    termsGroup: 'Quote terms',
    paymentPlan: 'Payment plan',
    warranty: 'Warranty text',
    disclaimer: 'Customer disclaimer',
    displayGroup: 'Display',
    appearance: 'Appearance',
    units: 'Units',
    dataGroup: 'Data & Account',
    exportBackup: 'Export backup (JSON)',
    signOut: 'Sign out',
    developerTitle: 'Developer options'
  },
  onboarding: {
    step1Title: 'What work do you do?',
    step1Helper: 'Pick your trade. Everything adapts to it.',
    step2Title: 'Your business',
    step2Helper: 'Enter your business details.',
    step3Title: 'Your numbers',
    step3Helper: 'Set your rates. You can edit anytime.',
    step4Title: 'Teach me your prices',
    step4Helper: 'Add old quotes, or skip for now.',
    skipButton: 'Skip for now',
    finishButton: 'Start making quotes'
  },
  errors: {
    requiredField: 'This field is required.',
    addLength: 'Add the length.',
    addWidth: 'Add the width.',
    addCustomerName: 'Add the customer name.',
    addAddress: 'Add the job address.',
    photoFailed: "Photo didn't send. Try again.",
    retry: 'Retry'
  }
};
