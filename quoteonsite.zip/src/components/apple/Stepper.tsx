import React from 'react';
import { Minus, Plus } from 'lucide-react';

interface StepperProps {
  value: number;
  onChange: (val: number) => void;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  decimals?: number;
  className?: string;
}

export const Stepper: React.FC<StepperProps> = ({
  value,
  onChange,
  min = 0,
  max = 99999,
  step = 1,
  unit = '',
  decimals = 1,
  className = ''
}) => {
  const triggerHaptic = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(10);
      } catch (e) {
        // Safe fallback
      }
    }
  };

  const handleDecrement = (e: React.MouseEvent) => {
    e.preventDefault();
    triggerHaptic();
    const next = Math.max(min, Number((value - step).toFixed(decimals)));
    onChange(next);
  };

  const handleIncrement = (e: React.MouseEvent) => {
    e.preventDefault();
    triggerHaptic();
    const next = Math.min(max, Number((value + step).toFixed(decimals)));
    onChange(next);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    if (raw === '') {
      onChange(min);
      return;
    }
    const parsed = parseFloat(raw);
    if (!isNaN(parsed)) {
      onChange(parsed);
    }
  };

  return (
    <div className={`flex items-center gap-1.5 ${className}`}>
      {/* Minus button */}
      <button
        type="button"
        onClick={handleDecrement}
        disabled={value <= min}
        className="w-10 h-10 rounded-[10px] bg-[var(--apple-elevated)] flex items-center justify-center text-[var(--apple-label)] disabled:opacity-30 active:bg-[var(--apple-separator)] transition-colors min-h-[44px] min-w-[44px]"
        aria-label="Decrease"
      >
        <Minus className="w-5 h-5 stroke-[2.2]" />
      </button>

      {/* Number input box */}
      <div className="relative flex items-center justify-center bg-[var(--apple-elevated)] rounded-[10px] px-2.5 py-1 min-w-[76px] h-11 border border-[var(--apple-separator)]">
        <input
          type="number"
          inputMode="decimal"
          value={isNaN(value) ? '' : value}
          onChange={handleInputChange}
          step={step}
          min={min}
          max={max}
          className="w-full bg-transparent text-center font-semibold text-[17px] text-[var(--apple-label)] tabular-nums outline-none"
        />
        {unit && (
          <span className="ml-1 text-[13px] text-[var(--apple-secondary)] font-medium select-none pointer-events-none">
            {unit}
          </span>
        )}
      </div>

      {/* Plus button */}
      <button
        type="button"
        onClick={handleIncrement}
        disabled={value >= max}
        className="w-10 h-10 rounded-[10px] bg-[var(--apple-elevated)] flex items-center justify-center text-[var(--apple-label)] disabled:opacity-30 active:bg-[var(--apple-separator)] transition-colors min-h-[44px] min-w-[44px]"
        aria-label="Increase"
      >
        <Plus className="w-5 h-5 stroke-[2.2]" />
      </button>
    </div>
  );
};
