import React from 'react';

export interface SegmentOption<T extends string = string> {
  value: T;
  label: string;
  badge?: string;
}

interface SegmentedControlProps<T extends string = string> {
  options: SegmentOption<T>[];
  value: T;
  onChange: (val: T) => void;
  className?: string;
  size?: 'sm' | 'md';
}

export function SegmentedControl<T extends string = string>({
  options,
  value,
  onChange,
  className = '',
  size = 'md'
}: SegmentedControlProps<T>) {
  const triggerHaptic = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(10);
      } catch (e) {
        // Ignore vibration errors
      }
    }
  };

  const padClass = size === 'sm' ? 'py-1 px-2 text-[14px]' : 'py-2 px-3 text-[15px]';

  return (
    <div
      role="tablist"
      className={`flex items-center bg-white/[0.07] backdrop-blur-xl p-1 rounded-[14px] border border-white/15 select-none w-full shadow-inner ${className}`}
    >
      {options.map((opt) => {
        const isSelected = opt.value === value;
        return (
          <button
            key={opt.value}
            type="button"
            role="tab"
            aria-selected={isSelected}
            onClick={() => {
              triggerHaptic();
              onChange(opt.value);
            }}
            className={`flex-1 flex items-center justify-center font-semibold rounded-[10px] transition-all duration-200 min-h-[38px] ${padClass} ${
              isSelected
                ? 'bg-gradient-to-b from-white/25 to-white/15 text-white shadow-[0_2px_12px_rgba(0,0,0,0.3)] border border-white/30 backdrop-blur-md'
                : 'text-white/80 hover:text-white active:scale-98'
            }`}
          >
            <span className="truncate">{opt.label}</span>
            {opt.badge && (
              <span className="ml-1.5 text-[11px] px-2 py-0.5 rounded-full bg-cyan-500 text-white font-bold shadow-sm">
                {opt.badge}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

