import React from 'react';
import { Home, FileText, Plus, Tag, Settings } from 'lucide-react';

export type TabId = 'home' | 'history' | 'wizard' | 'brain' | 'settings';

interface TabBarProps {
  activeTab: TabId;
  onTabChange: (tab: TabId) => void;
  className?: string;
}

export const TabBar: React.FC<TabBarProps> = ({
  activeTab,
  onTabChange,
  className = ''
}) => {
  const triggerHaptic = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(8);
      } catch (e) {
        // Fallback
      }
    }
  };

  const handleSelect = (tab: TabId) => {
    triggerHaptic();
    onTabChange(tab);
  };

  return (
    <nav
      className={`fixed bottom-0 left-0 right-0 z-30 bg-slate-950/80 backdrop-blur-2xl border-t border-white/10 pb-safe ${className}`}
      aria-label="Main Navigation"
    >
      <div className="flex items-center justify-around h-[56px] max-w-md mx-auto px-2">
        {/* Home */}
        <button
          type="button"
          onClick={() => handleSelect('home')}
          className={`flex-1 flex flex-col items-center justify-center h-full active:scale-95 transition-all ${
            activeTab === 'home'
              ? 'text-cyan-400 font-bold drop-shadow-[0_0_8px_rgba(34,211,238,0.6)]'
              : 'text-white/70 hover:text-white'
          }`}
          aria-label="Home"
        >
          <Home className="w-5 h-5 stroke-[2]" />
          <span className="text-[11px] font-semibold tracking-tight mt-1">Home</span>
        </button>

        {/* Quotes */}
        <button
          type="button"
          onClick={() => handleSelect('history')}
          className={`flex-1 flex flex-col items-center justify-center h-full active:scale-95 transition-all ${
            activeTab === 'history'
              ? 'text-emerald-400 font-bold drop-shadow-[0_0_8px_rgba(52,211,153,0.6)]'
              : 'text-white/70 hover:text-white'
          }`}
          aria-label="Quotes"
        >
          <FileText className="w-5 h-5 stroke-[2]" />
          <span className="text-[11px] font-semibold tracking-tight mt-1">Quotes</span>
        </button>

        {/* + New Vibrant Action Tab */}
        <button
          type="button"
          onClick={() => handleSelect('wizard')}
          className="flex-1 flex flex-col items-center justify-center h-full active:scale-90 transition-transform group"
          aria-label="New Quote"
        >
          <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 via-blue-500 to-indigo-600 text-white flex items-center justify-center shadow-[0_0_20px_rgba(56,189,248,0.5)] border border-white/20 group-hover:shadow-[0_0_28px_rgba(56,189,248,0.8)] transition-all">
            <Plus className="w-5 h-5 stroke-[2.8]" />
          </div>
          <span className="text-[10px] font-bold tracking-tight mt-0.5 text-cyan-300">New</span>
        </button>

        {/* Prices */}
        <button
          type="button"
          onClick={() => handleSelect('brain')}
          className={`flex-1 flex flex-col items-center justify-center h-full active:scale-95 transition-all ${
            activeTab === 'brain'
              ? 'text-amber-400 font-bold drop-shadow-[0_0_8px_rgba(251,191,36,0.6)]'
              : 'text-white/70 hover:text-white'
          }`}
          aria-label="Prices"
        >
          <Tag className="w-5 h-5 stroke-[2]" />
          <span className="text-[11px] font-semibold tracking-tight mt-1">Prices</span>
        </button>

        {/* Settings */}
        <button
          type="button"
          onClick={() => handleSelect('settings')}
          className={`flex-1 flex flex-col items-center justify-center h-full active:scale-95 transition-all ${
            activeTab === 'settings'
              ? 'text-purple-400 font-bold drop-shadow-[0_0_8px_rgba(192,132,252,0.6)]'
              : 'text-white/70 hover:text-white'
          }`}
          aria-label="Settings"
        >
          <Settings className="w-5 h-5 stroke-[2]" />
          <span className="text-[11px] font-semibold tracking-tight mt-1">Settings</span>
        </button>
      </div>
    </nav>
  );
};
