import React, { useEffect } from 'react';
import { X, Check } from 'lucide-react';

export interface SheetOption {
  value: string;
  label: string;
  description?: string;
  extraCost?: number;
}

interface BottomSheetProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  options: SheetOption[];
  selectedValue: string;
  onSelect: (val: string) => void;
  currency?: string;
}

export const BottomSheet: React.FC<BottomSheetProps> = ({
  isOpen,
  onClose,
  title,
  options,
  selectedValue,
  onSelect,
  currency = '$'
}) => {
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isOpen]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      {/* Sheet Content */}
      <div className="relative w-full max-w-lg bg-slate-900/95 backdrop-blur-2xl rounded-t-[24px] shadow-[0_-8px_32px_rgba(0,0,0,0.6)] border-t border-white/20 animate-slide-up pb-safe max-h-[85dvh] flex flex-col z-10">
        {/* Grabber handle */}
        <div className="flex justify-center pt-3 pb-1 cursor-grab" onClick={onClose}>
          <div className="w-10 h-1.5 rounded-full bg-white/30" />
        </div>

        {/* Header */}
        <div className="flex items-center justify-between px-5 pb-3 border-b border-white/10">
          <h3 className="text-[18px] font-bold text-white tracking-tight">
            {title}
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/90 active:scale-95 transition-transform"
            aria-label="Close"
          >
            <X className="w-4 h-4 stroke-[2.5]" />
          </button>
        </div>

        {/* Options List */}
        <div className="overflow-y-auto px-4 py-2 divide-y divide-white/10">
          {options.map((opt) => {
            const isSelected = opt.value === selectedValue;
            return (
              <button
                key={opt.value}
                type="button"
                onClick={() => {
                  onSelect(opt.value);
                  onClose();
                }}
                className={`w-full flex items-center justify-between py-3.5 px-3 rounded-[12px] text-left transition-all min-h-[52px] ${
                  isSelected ? 'bg-white/10' : 'active:bg-white/5 hover:bg-white/[0.04]'
                }`}
              >
                <div>
                  <div className="text-[16px] font-semibold text-white flex items-center gap-2">
                    {opt.label}
                    {opt.extraCost && opt.extraCost > 0 ? (
                      <span className="text-[13px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                        +{currency}{opt.extraCost}
                      </span>
                    ) : null}
                  </div>
                  {opt.description && (
                    <div className="text-[13px] text-white/80 mt-0.5 leading-snug">
                      {opt.description}
                    </div>
                  )}
                </div>

                {isSelected && (
                  <Check className="w-5 h-5 text-cyan-400 stroke-[3] shrink-0 ml-2 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]" />
                )}
              </button>
            );
          })}
        </div>
      </div>

    </div>
  );
};
