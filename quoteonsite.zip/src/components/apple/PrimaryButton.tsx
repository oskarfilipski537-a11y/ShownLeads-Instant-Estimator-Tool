import React from 'react';

interface PrimaryButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  loading?: boolean;
  variant?: 'primary' | 'secondary' | 'danger';
  icon?: React.ReactNode;
}

export const PrimaryButton: React.FC<PrimaryButtonProps> = ({
  label,
  loading = false,
  variant = 'primary',
  icon,
  className = '',
  disabled,
  onClick,
  ...props
}) => {
  const triggerHaptic = () => {
    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      try {
        navigator.vibrate(12);
      } catch (e) {
        // Fallback
      }
    }
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (loading || disabled) return;
    triggerHaptic();
    if (onClick) onClick(e);
  };

  let bgStyles = 'bg-[var(--apple-accent)] text-white active:bg-[var(--apple-accent-press)]';
  if (variant === 'secondary') {
    bgStyles = 'bg-[var(--apple-elevated)] text-[var(--apple-label)] active:bg-[var(--apple-separator)]';
  } else if (variant === 'danger') {
    bgStyles = 'bg-[var(--apple-danger)] text-white active:opacity-80';
  }

  return (
    <button
      type="button"
      disabled={disabled || loading}
      onClick={handleClick}
      className={`w-full h-[50px] min-h-[50px] rounded-[14px] font-semibold text-[17px] flex items-center justify-center gap-2 transition-all duration-150 select-none shadow-sm disabled:opacity-50 disabled:cursor-not-allowed ${bgStyles} ${className}`}
      {...props}
    >
      {loading ? (
        <span className="flex items-center gap-2 text-inherit">
          <svg className="animate-spin h-5 w-5 text-current" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z" />
          </svg>
          <span>Working…</span>
        </span>
      ) : (
        <>
          {icon}
          <span>{label}</span>
        </>
      )}
    </button>
  );
};
