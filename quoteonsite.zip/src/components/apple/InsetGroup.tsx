import React from 'react';

interface InsetGroupProps {
  title?: string;
  footer?: string;
  children: React.ReactNode;
  className?: string;
}

export const InsetGroup: React.FC<InsetGroupProps> = ({
  title,
  footer,
  children,
  className = ''
}) => {
  return (
    <div className={`mb-6 ${className}`}>
      {title && (
        <h2 className="px-4 mb-2 text-[13px] font-bold tracking-wider uppercase text-white/90 drop-shadow-sm">
          {title}
        </h2>
      )}
      <div className="glass-panel rounded-[20px] overflow-hidden divide-y divide-white/10">
        {children}
      </div>
      {footer && (
        <p className="px-4 mt-2 text-[13px] text-white/80 leading-relaxed font-normal">
          {footer}
        </p>
      )}
    </div>
  );
};

interface InsetRowProps {
  label: string;
  helper?: string;
  control?: React.ReactNode;
  onClick?: () => void;
  isLast?: boolean;
  className?: string;
}

export const InsetRow: React.FC<InsetRowProps> = ({
  label,
  helper,
  control,
  onClick,
  isLast = false,
  className = ''
}) => {
  const content = (
    <div
      onClick={onClick}
      className={`flex items-center justify-between px-4 min-h-[52px] py-3 transition-all ${
        onClick ? 'active:bg-white/10 cursor-pointer hover:bg-white/[0.04]' : ''
      } ${!isLast ? 'border-b border-white/10' : ''} ${className}`}
    >
      <div className="flex-1 pr-3">
        <span className="text-[16px] font-semibold text-white block leading-snug">
          {label}
        </span>
        {helper && (
          <span className="text-[13px] text-white/80 block mt-0.5 leading-tight font-normal">
            {helper}
          </span>
        )}
      </div>

      {control && (
        <div className="flex-shrink-0 flex items-center justify-end text-white">
          {control}
        </div>
      )}
    </div>
  );

  return content;
};

