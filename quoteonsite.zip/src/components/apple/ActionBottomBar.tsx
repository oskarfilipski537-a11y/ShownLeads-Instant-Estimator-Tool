import React from 'react';

interface ActionBottomBarProps {
  children: React.ReactNode;
  className?: string;
}

export const ActionBottomBar: React.FC<ActionBottomBarProps> = ({
  children,
  className = ''
}) => {
  return (
    <div className={`fixed bottom-0 left-0 right-0 z-40 apple-nav-blur border-t border-[var(--apple-separator)] px-4 pt-3 pb-safe ${className}`}>
      <div className="max-w-md mx-auto w-full">
        {children}
      </div>
    </div>
  );
};
