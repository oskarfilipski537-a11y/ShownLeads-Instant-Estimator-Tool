import React from 'react';
import { ChevronLeft } from 'lucide-react';

interface LargeNavBarProps {
  title: string;
  subtitle?: string;
  backLabel?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  progressPct?: number; // 0 to 100
}

export const LargeNavBar: React.FC<LargeNavBarProps> = ({
  title,
  subtitle,
  backLabel,
  onBack,
  rightAction,
  progressPct
}) => {
  return (
    <header className="sticky top-0 z-30 bg-slate-950/80 backdrop-blur-2xl border-b border-white/10">
      {/* Optional Progress Bar */}
      {typeof progressPct === 'number' && (
        <div className="w-full h-[2.5px] bg-white/10 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-500 shadow-[0_0_8px_rgba(56,189,248,0.5)] transition-all duration-300 ease-out"
            style={{ width: `${Math.min(100, Math.max(0, progressPct))}%` }}
          />
        </div>
      )}

      {/* Top action row with back button and right action */}
      <div className="flex items-center justify-between px-4 h-11">
        {onBack ? (
          <button
            type="button"
            onClick={onBack}
            className="flex items-center gap-1 text-cyan-400 text-[17px] font-semibold active:opacity-60 -ml-1 py-2 px-1 min-h-[44px]"
            aria-label={backLabel ? `Back to ${backLabel}` : 'Back'}
          >
            <ChevronLeft className="w-6 h-6 stroke-[2.2]" />
            {backLabel && <span>{backLabel}</span>}
          </button>
        ) : (
          <div className="w-6" />
        )}

        <div className="flex items-center gap-2 text-white/85 text-[13px] font-medium">
          {rightAction}
        </div>
      </div>

      {/* Large Title Area */}
      <div className="px-4 pb-3 pt-1">
        <h1 className="text-[30px] sm:text-[34px] leading-tight font-extrabold tracking-tight text-white drop-shadow-sm">
          {title}
        </h1>
        {subtitle && (
          <p className="text-[14px] sm:text-[15px] text-white/85 mt-1 leading-normal font-normal">
            {subtitle}
          </p>
        )}
      </div>
    </header>
  );
};

