import React from 'react';
import { Home, PlusCircle, History, BrainCircuit, Settings } from 'lucide-react';

interface BottomNavProps {
  activeTab: 'home' | 'new' | 'history' | 'brain' | 'settings';
  onChangeTab: (tab: 'home' | 'new' | 'history' | 'brain' | 'settings') => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onChangeTab }) => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#14171F]/90 dark:bg-[#14171F]/90 light:bg-white/90 backdrop-blur-xl border-t border-white/10 light:border-black/10 pb-safe">
      <div className="max-w-md mx-auto px-4 h-16 flex items-center justify-around relative">
        {/* Home */}
        <button
          onClick={() => onChangeTab('home')}
          className={`flex flex-col items-center justify-center w-14 h-full transition-colors active:scale-95 ${
            activeTab === 'home'
              ? 'text-[#5B6CFF]'
              : 'text-zinc-400 hover:text-zinc-200 light:text-zinc-500'
          }`}
          aria-label="Home Dashboard"
        >
          <Home className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-semibold tracking-wide">Home</span>
        </button>

        {/* History */}
        <button
          onClick={() => onChangeTab('history')}
          className={`flex flex-col items-center justify-center w-14 h-full transition-colors active:scale-95 ${
            activeTab === 'history'
              ? 'text-[#5B6CFF]'
              : 'text-zinc-400 hover:text-zinc-200 light:text-zinc-500'
          }`}
          aria-label="Estimate History"
        >
          <History className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-semibold tracking-wide">History</span>
        </button>

        {/* Big Center New Button */}
        <div className="relative -top-3">
          <button
            onClick={() => onChangeTab('new')}
            className="w-14 h-14 rounded-full electric-gradient text-white flex items-center justify-center shadow-lg shadow-[#5B6CFF]/30 active:scale-90 transition-transform focus:outline-none ring-4 ring-[#0B0D12] light:ring-white"
            aria-label="Create New Estimate"
          >
            <PlusCircle className="w-7 h-7" />
          </button>
        </div>

        {/* Pricing Brain */}
        <button
          onClick={() => onChangeTab('brain')}
          className={`flex flex-col items-center justify-center w-14 h-full transition-colors active:scale-95 ${
            activeTab === 'brain'
              ? 'text-[#5B6CFF]'
              : 'text-zinc-400 hover:text-zinc-200 light:text-zinc-500'
          }`}
          aria-label="Pricing Brain"
        >
          <BrainCircuit className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-semibold tracking-wide">Brain</span>
        </button>

        {/* Settings */}
        <button
          onClick={() => onChangeTab('settings')}
          className={`flex flex-col items-center justify-center w-14 h-full transition-colors active:scale-95 ${
            activeTab === 'settings'
              ? 'text-[#5B6CFF]'
              : 'text-zinc-400 hover:text-zinc-200 light:text-zinc-500'
          }`}
          aria-label="Settings"
        >
          <Settings className="w-5 h-5 mb-1" />
          <span className="text-[10px] font-semibold tracking-wide">Settings</span>
        </button>
      </div>
    </nav>
  );
};
