import React from 'react';
import { CompanyProfile } from '../../types';
import { Zap } from 'lucide-react';

interface TopHeaderProps {
  company: CompanyProfile;
}

export const TopHeader: React.FC<TopHeaderProps> = ({ company }) => {
  return (
    <header className="sticky top-0 z-30 bg-[#0B0D12]/80 light:bg-[#F5F5F7]/80 backdrop-blur-2xl border-b border-white/[0.06] light:border-black/[0.06] px-4 sm:px-6 h-14 flex items-center transition-colors">
      <div className="flex items-center justify-between max-w-4xl mx-auto w-full gap-3">
        <div className="flex items-center gap-2.5 truncate">
          {/* Logo badge with company or ShownLeads icon */}
          {company.logoUrl ? (
            <img
              src={company.logoUrl}
              alt={company.companyName}
              className="w-8 h-8 rounded-xl object-cover border border-white/10 shadow-sm shrink-0"
            />
          ) : (
            <div className="w-8 h-8 rounded-xl electric-gradient flex items-center justify-center text-white font-bold text-xs shadow-md shadow-[#5B6CFF]/20 shrink-0">
              <Zap className="w-4 h-4 fill-white" />
            </div>
          )}

          <div className="truncate">
            <h1 className="text-sm font-bold tracking-tight text-white light:text-zinc-900 truncate flex items-center gap-1.5">
              <span>ShownLeads Instant Estimator</span>
            </h1>
            <div className="text-[11px] text-zinc-400 light:text-zinc-500 truncate flex items-center gap-1.5">
              <span className="font-semibold text-zinc-300 light:text-zinc-700">
                {company.companyName || 'Apex Contractors'}
              </span>
              <span className="text-zinc-600">·</span>
              <span className="truncate">{company.primaryTrade || 'On-Site Estimating'}</span>
            </div>
          </div>
        </div>

        {/* Small trust indicator / contractor badge on right */}
        <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/[0.04] border border-white/10 text-[11px] text-zinc-400 shrink-0">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span className="font-medium text-zinc-300 truncate">{company.companyName}</span>
        </div>
      </div>
    </header>
  );
};
