import { TradePack } from './types';
import { atticPack } from './attic';
import { drivewaysPack } from './driveways';
import {
  roofingPack,
  insulationPack,
  kitchenPack,
  bathroomPack,
  paintingPack,
  sidingPack,
  landscapingPack,
  electricalPack,
  plumbingPack,
  hvacPack
} from './otherPacks';

export * from './types';
export { atticPack } from './attic';
export { drivewaysPack } from './driveways';

export const ALL_TRADE_PACKS: TradePack[] = [
  atticPack,
  drivewaysPack,
  roofingPack,
  insulationPack,
  kitchenPack,
  bathroomPack,
  paintingPack,
  sidingPack,
  landscapingPack,
  electricalPack,
  plumbingPack,
  hvacPack
];

const PACKS_BY_ID: Record<string, TradePack> = {
  attic: atticPack,
  driveways: drivewaysPack,
  roofing: roofingPack,
  insulation: insulationPack,
  kitchen: kitchenPack,
  bathroom: bathroomPack,
  painting: paintingPack,
  siding: sidingPack,
  landscaping: landscapingPack,
  electrical: electricalPack,
  plumbing: plumbingPack,
  hvac: hvacPack
};

// Aliases for user selection tolerance
const ALIASES: Record<string, string> = {
  'attic conversion': 'attic',
  'loft': 'attic',
  'loft conversion': 'attic',
  'attic conversion / remodel': 'attic',
  'driveway': 'driveways',
  'concrete': 'driveways',
  'driveways / concrete': 'driveways',
  'paving': 'driveways',
  'roof': 'roofing',
  'kitchen remodel': 'kitchen',
  'kitchens': 'kitchen',
  'bathroom remodel': 'bathroom',
  'bathrooms': 'bathroom',
  'paint': 'painting',
  'painter': 'painting',
  'painting & decorating': 'painting',
  'siding & cladding': 'siding',
  'landscaping / patios': 'landscaping',
  'electrician': 'electrical',
  'plumber': 'plumbing',
  'plumbing & heating': 'plumbing',
  'hvac & heat pumps': 'hvac',
  'air conditioning': 'hvac'
};

export function getTradePack(tradeIdOrName?: string): TradePack {
  if (!tradeIdOrName) return atticPack;
  const clean = tradeIdOrName.trim().toLowerCase();
  if (PACKS_BY_ID[clean]) {
    return PACKS_BY_ID[clean];
  }
  const aliasTarget = ALIASES[clean];
  if (aliasTarget && PACKS_BY_ID[aliasTarget]) {
    return PACKS_BY_ID[aliasTarget];
  }
  // Try partial search
  const found = ALL_TRADE_PACKS.find(p => 
    p.displayName.toLowerCase().includes(clean) ||
    clean.includes(p.id) ||
    clean.includes(p.jobWord.toLowerCase())
  );
  return found || atticPack;
}
