import { TradePack } from './types';

export const atticPack: TradePack = {
  id: 'attic',
  displayName: 'Attic conversion',
  jobWord: 'loft job',
  icon: 'Home',
  defaultUnitSystem: 'metric',
  jobTypes: [
    {
      id: 'bedroom',
      name: 'Bedroom loft',
      description: 'Full liveable bedroom with stairs, insulation and windows',
      baseLabourDays: 16,
      defaultSqM: 20
    },
    {
      id: 'office',
      name: 'Home office / bonus room',
      description: 'Quiet work space with internet cabling and plenty of power',
      baseLabourDays: 14,
      defaultSqM: 18
    },
    {
      id: 'ensuite',
      name: 'Bedroom + bathroom loft',
      description: 'Master suite with private toilet, shower and basin',
      baseLabourDays: 22,
      defaultSqM: 26
    },
    {
      id: 'playroom',
      name: 'Kids\' playroom',
      description: 'Bright open space with extra floor soundproofing',
      baseLabourDays: 15,
      defaultSqM: 22
    },
    {
      id: 'storage',
      name: 'Storage floor only',
      description: 'Strong floor boards, fold-down ladder and safety light',
      baseLabourDays: 4,
      defaultSqM: 25
    }
  ],
  photoShots: [
    {
      id: 'whole_attic',
      label: 'Whole attic',
      why: 'From the hatch or stairs to see width and height',
      required: true
    },
    {
      id: 'roof_timbers',
      label: 'Roof beams',
      why: 'Shows if roof has rafters or zigzag trusses',
      required: true
    },
    {
      id: 'floor_beams',
      label: 'Floor beams + tape',
      why: 'Tape measure shows beam depth and span',
      required: true
    },
    {
      id: 'stairs_spot',
      label: 'Where stairs will go',
      why: 'Shows room below to check landing space'
    },
    {
      id: 'fuse_box',
      label: 'Fuse box',
      why: 'Shows if you have space for new power circuits'
    }
  ],
  measureFields: [
    {
      id: 'length',
      label: 'Floor length',
      helper: 'Longest wall along the floor',
      type: 'number',
      unit: 'm',
      imperialUnit: 'ft',
      min: 2,
      max: 25,
      step: 0.1,
      defaultVal: 5.5,
      group: 'Room dimensions'
    },
    {
      id: 'width',
      label: 'Floor width',
      helper: 'Width across the roof slope',
      type: 'number',
      unit: 'm',
      imperialUnit: 'ft',
      min: 2,
      max: 20,
      step: 0.1,
      defaultVal: 4.0,
      group: 'Room dimensions'
    },
    {
      id: 'tallest_height',
      label: 'Tallest height',
      helper: 'Floor to the roof ridge in the middle',
      type: 'number',
      unit: 'm',
      imperialUnit: 'ft',
      min: 1.8,
      max: 5.0,
      step: 0.05,
      defaultVal: 2.4,
      group: 'Head room'
    },
    {
      id: 'low_height',
      label: 'Low side height',
      helper: 'Height where roof meets the floor',
      type: 'number',
      unit: 'm',
      imperialUnit: 'ft',
      min: 0,
      max: 2.0,
      step: 0.05,
      defaultVal: 0.6,
      group: 'Head room'
    },
    {
      id: 'standing_area',
      label: 'Standing area (2.1 m / 7 ft+)',
      helper: 'Floor area where you can stand upright',
      type: 'number',
      unit: 'm²',
      imperialUnit: 'sq ft',
      min: 2,
      max: 50,
      step: 0.5,
      defaultVal: 14.0,
      group: 'Head room'
    },
    {
      id: 'roof_pitch',
      label: 'Roof pitch',
      helper: 'Slope angle of the roof tiles',
      type: 'segmented',
      defaultVal: 'medium',
      options: [
        { value: 'low', label: 'Low (< 30°)', description: 'Tighter head room' },
        { value: 'medium', label: 'Medium (30-45°)', description: 'Good head room' },
        { value: 'steep', label: 'Steep (> 45°)', description: 'Plenty of head room' }
      ],
      group: 'Roof structure'
    },
    {
      id: 'roof_type',
      label: 'Roof structure type',
      helper: 'Rafters you walk between, or zigzag trusses',
      type: 'segmented',
      defaultVal: 'rafters',
      options: [
        { value: 'rafters', label: 'Rafters' },
        { value: 'trusses', label: 'Trusses', flag: 'Usually needs steel beams and engineer' }
      ],
      group: 'Roof structure'
    },
    {
      id: 'joist_depth',
      label: 'Floor beam depth',
      helper: 'Depth of current ceiling beams below',
      type: 'segmented',
      defaultVal: '6in',
      options: [
        { value: '4in', label: 'Under 6 in (100mm)', description: 'Needs new steel or deeper joists' },
        { value: '6in', label: '6 in (150mm)', description: 'Needs strengthening' },
        { value: '8in', label: '8 in+ (200mm)', description: 'Strong structure' }
      ],
      group: 'Floor structure'
    },
    {
      id: 'stairs',
      label: 'Stairs to attic',
      helper: 'How people will walk up to the loft',
      type: 'picker',
      defaultVal: 'straight',
      options: [
        { value: 'existing', label: 'Already there', extraCost: 0 },
        { value: 'straight', label: 'Straight stairs fit', extraCost: 2200 },
        { value: 'turn', label: 'Needs a turn / spiral', extraCost: 3400 },
        { value: 'no_room', label: 'No easy room', extraCost: 4800, flag: 'Needs careful space redesign' }
      ],
      group: 'Stairs & dormer'
    },
    {
      id: 'dormer',
      label: 'Dormer window',
      helper: 'Box out the roof to add head room',
      type: 'segmented',
      defaultVal: 'none',
      options: [
        { value: 'none', label: 'None' },
        { value: 'small', label: 'Small (1 window)', extraCost: 4200 },
        { value: 'big', label: 'Big (rear dormer)', extraCost: 7800 },
        { value: 'two', label: 'Two dormers', extraCost: 13500 }
      ],
      group: 'Stairs & dormer'
    },
    {
      id: 'roof_windows',
      label: 'Roof windows (skylights)',
      helper: 'How many Velux roof windows',
      type: 'stepper',
      min: 0,
      max: 6,
      step: 1,
      defaultVal: 2,
      group: 'Windows & finish'
    },
    {
      id: 'bathroom',
      label: 'Bathroom up there?',
      helper: 'Plumbing up to the loft',
      type: 'segmented',
      defaultVal: 'none',
      options: [
        { value: 'none', label: 'None' },
        { value: 'toilet_sink', label: 'Toilet + sink', extraCost: 3400 },
        { value: 'full_bath', label: 'Full bathroom', extraCost: 6500 }
      ],
      group: 'Plumbing & heat'
    },
    {
      id: 'heating',
      label: 'Heating',
      helper: 'How to warm the new room',
      type: 'segmented',
      defaultVal: 'radiators',
      options: [
        { value: 'radiators', label: 'Pipe radiators', extraCost: 1100 },
        { value: 'heat_pump', label: 'Heat pump A/C', extraCost: 2400 },
        { value: 'electric', label: 'Electric heat', extraCost: 650 },
        { value: 'none', label: 'None', extraCost: 0 }
      ],
      group: 'Plumbing & heat'
    },
    {
      id: 'floor_finish',
      label: 'Floor finish',
      helper: 'Walking surface over boards',
      type: 'segmented',
      defaultVal: 'carpet',
      options: [
        { value: 'boards', label: 'Bare boards' },
        { value: 'carpet', label: 'Carpet' },
        { value: 'laminate', label: 'Laminate' },
        { value: 'tile', label: 'Tile' }
      ],
      group: 'Windows & finish'
    },
    {
      id: 'finish_tier',
      label: 'Quality tier',
      helper: 'Standard of trim, doors and lighting',
      type: 'segmented',
      defaultVal: 'nice',
      options: [
        { value: 'basic', label: 'Basic', description: 'Clean functional builder spec' },
        { value: 'nice', label: 'Nice', description: 'Solid oak handrails, downlights, painted' },
        { value: 'top', label: 'Top', description: 'Bespoke joinery, designer fittings' }
      ],
      group: 'Windows & finish'
    }
  ],
  questions: [
    {
      id: 'roof_supports',
      text: 'What holds up the roof?',
      options: [
        { value: 'rafters', label: 'Rafters' },
        {
          value: 'trusses',
          label: 'Trusses',
          priceEffect: {
            description: 'Steel beam & truss conversion labour',
            amount: 3600,
            category: 'extras'
          },
          flagEffect: {
            id: 'trusses_flag',
            title: 'Trusses need structural steel',
            detail: 'Trusses cannot simply be cut. Steel ridge and rafters required.',
            type: 'risk'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Held back contingency for roof structure',
            amount: 900,
            category: 'extras'
          },
          flagEffect: {
            id: 'roof_unsure',
            title: 'Roof timbers need checking',
            detail: 'Take a close photo of the roof woodwork before ordering timber.',
            type: 'warning'
          }
        }
      ]
    },
    {
      id: 'floor_strength',
      text: 'How strong is the floor?',
      options: [
        { value: 'strong', label: 'Strong enough' },
        {
          value: 'needs_beams',
          label: 'Needs extra beams',
          priceEffect: {
            description: 'New structural floor joists and hangers',
            amount: 1800,
            category: 'materials'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Held back contingency for joists',
            amount: 600,
            category: 'extras'
          },
          flagEffect: {
            id: 'joist_unsure',
            title: 'Floor joist strength unconfirmed',
            detail: 'Measure joist thickness and span to confirm load rating.',
            type: 'warning'
          }
        }
      ]
    },
    {
      id: 'fuse_box_space',
      text: 'Is there room in the fuse box?',
      options: [
        { value: 'yes', label: 'Yes' },
        {
          value: 'needs_subpanel',
          label: 'No, needs bigger box',
          priceEffect: {
            description: 'Electrical sub-panel & supply cable',
            amount: 850,
            category: 'extras'
          },
          flagEffect: {
            id: 'subpanel_flag',
            title: 'Fuse box is full',
            detail: 'Book electrician to fit new sub-panel before first fix.',
            type: 'warning'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Held back contingency for fuse box',
            amount: 400,
            category: 'extras'
          }
        }
      ]
    },
    {
      id: 'loadbearing_wall',
      text: 'Taking out a wall that holds up the house?',
      options: [
        { value: 'no', label: 'No' },
        {
          value: 'yes',
          label: 'Yes',
          priceEffect: {
            description: 'Engineer calculations, steel lintel and Acrow props',
            amount: 2200,
            category: 'extras'
          },
          flagEffect: {
            id: 'wall_flag',
            title: 'Load-bearing wall removal',
            detail: 'Structural calculations and temporary acrow props required.',
            type: 'risk'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Held back contingency for wall check',
            amount: 500,
            category: 'extras'
          }
        }
      ]
    },
    {
      id: 'escape_window',
      text: 'Is there a window big enough to climb out?',
      relevantIf: (jobTypeId) => jobTypeId === 'bedroom' || jobTypeId === 'ensuite',
      options: [
        { value: 'yes', label: 'Yes' },
        {
          value: 'add_one',
          label: 'No, add one',
          priceEffect: {
            description: 'Fire escape roof window (egress hinge)',
            amount: 750,
            category: 'materials'
          },
          flagEffect: {
            id: 'egress_flag',
            title: 'Escape window added for safety',
            detail: 'Building rules require a wide escape window in every loft bedroom.',
            type: 'warning'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Held back contingency for egress',
            amount: 350,
            category: 'extras'
          }
        }
      ]
    },
    {
      id: 'stairs_spot',
      text: 'Where do the stairs go?',
      options: [
        { value: 'good_spot', label: 'Good spot' },
        {
          value: 'takes_space',
          label: 'Takes room space',
          priceEffect: {
            description: 'Landing partitioning and doorway alteration',
            amount: 950,
            category: 'labor'
          }
        },
        {
          value: 'no_spot',
          label: 'No clear spot',
          flagEffect: {
            id: 'stairs_blocked',
            title: 'Staircase access needs redesign',
            detail: 'No obvious stair run. Check head room on stairs or alternate entry.',
            type: 'blocker'
          }
        }
      ]
    }
  ],
  priceBook: [
    { id: 'floor_beams', name: 'Structural floor beams', category: 'materials', unit: 'm²', defaultCost: 45, wastePct: 10, isDefault: true },
    { id: 'floor_boards', name: 'T&G moisture-resistant boards', category: 'materials', unit: 'm²', defaultCost: 24, wastePct: 10, isDefault: true },
    { id: 'rafter_insulation', name: 'Rigid insulation & air barrier', category: 'materials', unit: 'm²', defaultCost: 52, wastePct: 8, isDefault: true },
    { id: 'plasterboard_skim', name: 'Fireline plasterboard & skim', category: 'materials', unit: 'm²', defaultCost: 38, wastePct: 10, isDefault: true },
    { id: 'roof_window', name: 'Velux roof window + flashing', category: 'materials', unit: 'item', defaultCost: 620, wastePct: 0, isDefault: true },
    { id: 'staircase', name: 'Custom pine staircase & rails', category: 'materials', unit: 'item', defaultCost: 2100, wastePct: 0, isDefault: true },
    { id: 'internal_door', name: 'Fire door, frame & ironmongery', category: 'materials', unit: 'item', defaultCost: 280, wastePct: 0, isDefault: true },
    { id: 'electrics_pack', name: 'Wiring, downlights & sockets', category: 'materials', unit: 'job', defaultCost: 1400, wastePct: 0, isDefault: true },
    { id: 'dormer_kit', name: 'Flat roof dormer envelope', category: 'materials', unit: 'item', defaultCost: 3800, wastePct: 5, isDefault: true },
    { id: 'steel_beam', name: 'Universal steel ridge / beam', category: 'extras', unit: 'item', defaultCost: 1250, wastePct: 0, isDefault: true },
    { id: 'engineer_fee', name: 'Structural engineer calcs', category: 'fees', unit: 'job', defaultCost: 850, wastePct: 0, isDefault: true },
    { id: 'scaffold_hire', name: 'Scaffolding & edge protection', category: 'extras', unit: 'job', defaultCost: 1600, wastePct: 0, isDefault: true },
    { id: 'skip_hire', name: 'Skip hire & rubbish carting', category: 'extras', unit: 'job', defaultCost: 750, wastePct: 0, isDefault: true },
    { id: 'building_notice', name: 'Building control notice & signoff', category: 'fees', unit: 'job', defaultCost: 650, wastePct: 0, isDefault: true }
  ],
  labourRates: {
    hourlyRate: 58,
    crewSize: 2,
    hoursPerSqM: 8.5
  },
  packages: [
    {
      id: 'basic',
      name: 'Basic',
      bullets: [
        'Floor beams + moisture boards',
        'Staircase, safety handrail & fire door',
        '2 roof windows, insulation & skim',
        '6 downlights & 4 twin power sockets'
      ],
      scopeModifiers: () => ({
        addedItems: []
      })
    },
    {
      id: 'nice',
      name: 'Nice',
      bullets: [
        'Everything in Basic',
        'Rear dormer for full standing height',
        'Plumbed radiator / climate heating',
        'Oak handrails & upgraded acoustic flooring'
      ],
      scopeModifiers: (m) => ({
        addedItems: [
          {
            id: 'dormer_nice',
            name: 'Rear dormer construction',
            quantity: 1,
            unit: 'item',
            unitCost: 4500,
            category: 'materials'
          },
          {
            id: 'heating_nice',
            name: 'Plumbed radiator and heating line',
            quantity: 1,
            unit: 'job',
            unitCost: 1100,
            category: 'materials'
          }
        ],
        extraDays: 4
      })
    },
    {
      id: 'top',
      name: 'Top',
      bullets: [
        'Everything in Nice',
        'Private ensuite with shower, vanity & toilet',
        'Built-in under-eaves wardrobe storage',
        'Designer trim, doors and dimmable lighting'
      ],
      scopeModifiers: (m) => ({
        addedItems: [
          {
            id: 'dormer_top',
            name: 'Wide dormer construction',
            quantity: 1,
            unit: 'item',
            unitCost: 6200,
            category: 'materials'
          },
          {
            id: 'ensuite_top',
            name: 'Full ensuite bath, shower & waste pipe',
            quantity: 1,
            unit: 'job',
            unitCost: 4800,
            category: 'materials'
          },
          {
            id: 'joinery_top',
            name: 'Bespoke under-eaves wardrobes',
            quantity: 1,
            unit: 'job',
            unitCost: 1800,
            category: 'materials'
          }
        ],
        extraDays: 7
      })
    }
  ],
  riskChecks: [
    {
      id: 'trusses_check',
      title: 'Roof trusses present',
      detail: 'Needs engineer calculations before cutting any web timber.',
      triggeredIf: (answers, m) => m.roof_type === 'trusses' || answers.roof_supports === 'trusses'
    },
    {
      id: 'headroom_check',
      title: 'Head room is tight',
      detail: 'Tallest ridge is under 2.2m. Check clearance rules for stairs and doors.',
      triggeredIf: (answers, m) => Number(m.tallest_height || 2.4) < 2.2
    },
    {
      id: 'stairs_blocked_check',
      title: 'Staircase room is tight',
      detail: 'Check ceiling height above where the stairs will land.',
      triggeredIf: (answers, m) => m.stairs === 'no_room' || answers.stairs_spot === 'no_spot'
    },
    {
      id: 'fusebox_check',
      title: 'Fuse box needs extra circuits',
      detail: 'Electrician should fit sub-panel before drywalling.',
      triggeredIf: (answers) => answers.fuse_box_space === 'needs_subpanel'
    },
    {
      id: 'escape_check',
      title: 'Fire escape window needed',
      detail: 'Bedroom requires an opening fire-egress window.',
      triggeredIf: (answers) => answers.escape_window === 'add_one'
    },
    {
      id: 'joist_check',
      title: 'Existing joists need strengthening',
      detail: 'Ceiling beams are under 6 inches deep and cannot take floor loads.',
      triggeredIf: (answers, m) => m.joist_depth === '4in' || answers.floor_strength === 'needs_beams'
    }
  ],
  exclusions: [
    'Moving main soil stack through lower floors unless specified',
    'Upgrading incoming mains water or electrical supply from the street',
    'Furniture, blinds, and soft decorations',
    'Planning appeals or council conservation application fees'
  ],
  assumptions: [
    'Water, electricity and clear driveway access available during work',
    'Existing foundations are sound and can take loft conversion load',
    'Working hours 8:00 AM to 5:00 PM Monday through Friday',
    'Dust sheets laid daily through hallways and stairs'
  ],
  customerWording: {
    headline: 'Your new loft conversion',
    description: 'We turn your empty attic into a bright, warm, fully finished room with safe stairs, natural light and solid floors.',
    whatsIncluded: (jobTypeId, tier) => {
      const base = [
        'Heavy-duty floor joists and solid tongue-and-groove boards',
        'Custom wooden staircase with safety handrails and spindles',
        'Rafter-level insulation keeping the room warm all year',
        'Fire-rated plasterboard walls with smooth skim coat',
        'Dimmable LED downlights, power sockets and smoke alarm',
        'Daily dust protection across carpets and hallway paths'
      ];
      if (tier === 'nice' || tier === 'top') {
        base.push('Rear roof dormer to give full head height across the room');
        base.push('Plumbed radiator connected to home heating');
      }
      if (tier === 'top') {
        base.push('Ensuite bathroom with walk-in shower, basin and toilet');
        base.push('Fitted under-eaves storage cupboards');
      }
      return base;
    },
    whatsNotIncluded: [
      'Paint touch-ups in unrelated rooms',
      'Council planning fees if extra permissions are requested',
      'Moving furniture or clearing out old boxes before work starts'
    ]
  },
  sanityBands: {
    bedroom: { minPerSqM: 1000, maxPerSqM: 2600, minPerSqFt: 95, maxPerSqFt: 240 },
    office: { minPerSqM: 950, maxPerSqM: 2200, minPerSqFt: 90, maxPerSqFt: 205 },
    ensuite: { minPerSqM: 1400, maxPerSqM: 3200, minPerSqFt: 130, maxPerSqFt: 300 },
    playroom: { minPerSqM: 950, maxPerSqM: 2200, minPerSqFt: 90, maxPerSqFt: 205 },
    storage: { minPerSqM: 250, maxPerSqM: 650, minPerSqFt: 25, maxPerSqFt: 60 }
  }
};
