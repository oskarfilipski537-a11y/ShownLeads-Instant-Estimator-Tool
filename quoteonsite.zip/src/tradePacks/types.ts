export type UnitSystem = 'metric' | 'imperial';

export interface TradeJobType {
  id: string;
  name: string;
  description: string;
  baseLabourDays: number;
  defaultSqM: number;
}

export interface TradePhotoShot {
  id: string;
  label: string;
  why: string;
  required?: boolean;
}

export interface TradeMeasureOption {
  value: string;
  label: string;
  description?: string;
  extraCost?: number;
  flag?: string;
}

export interface TradeMeasureField {
  id: string;
  label: string;
  helper: string;
  type: 'number' | 'stepper' | 'segmented' | 'picker';
  unit?: string;
  imperialUnit?: string;
  min?: number;
  max?: number;
  step?: number;
  defaultVal: number | string | boolean;
  options?: TradeMeasureOption[];
  group?: string;
}

export interface QuestionEffect {
  description: string;
  amount?: number;
  perSqM?: number;
  days?: number;
  category: 'materials' | 'labor' | 'extras' | 'fees';
}

export interface QuestionFlag {
  id: string;
  title: string;
  detail: string;
  type: 'warning' | 'risk' | 'blocker';
}

export interface TradeQuestionOption {
  value: string;
  label: string;
  priceEffect?: QuestionEffect;
  flagEffect?: QuestionFlag;
}

export interface TradeQuestion {
  id: string;
  text: string;
  options: TradeQuestionOption[];
  relevantIf?: (jobTypeId: string, measurements: Record<string, any>) => boolean;
}

export interface PriceBookItem {
  id: string;
  name: string;
  category: 'materials' | 'labor' | 'extras' | 'fees';
  unit: string;
  imperialUnit?: string;
  defaultCost: number;
  wastePct?: number;
  isDefault?: boolean;
}

export interface TradePackage {
  id: 'basic' | 'nice' | 'top';
  name: string;
  bullets: string[];
  scopeModifiers: (measurements: Record<string, any>) => {
    addedItems?: Array<{
      id: string;
      name: string;
      quantity: number;
      unit: string;
      unitCost: number;
      category: 'materials' | 'labor' | 'extras' | 'fees';
    }>;
    extraDays?: number;
  };
}

export interface RiskCheck {
  id: string;
  title: string;
  detail: string;
  triggeredIf: (answers: Record<string, string>, measurements: Record<string, any>) => boolean;
}

export interface CustomerWording {
  headline: string;
  description: string;
  whatsIncluded: (jobTypeId: string, packageId: 'basic' | 'nice' | 'top') => string[];
  whatsNotIncluded: string[];
}

export interface SanityBand {
  minPerSqM: number;
  maxPerSqM: number;
  minPerSqFt: number;
  maxPerSqFt: number;
}

export interface TradePack {
  id: string;
  displayName: string;
  jobWord: string; // e.g. "loft job", "driveway", "roof"
  icon: string;
  defaultUnitSystem: UnitSystem;
  jobTypes: TradeJobType[];
  photoShots: TradePhotoShot[];
  measureFields: TradeMeasureField[];
  questions: TradeQuestion[];
  priceBook: PriceBookItem[];
  labourRates: {
    hourlyRate: number;
    crewSize: number;
    hoursPerSqM: number;
  };
  packages: TradePackage[];
  riskChecks: RiskCheck[];
  exclusions: string[];
  assumptions: string[];
  customerWording: CustomerWording;
  sanityBands: Record<string, SanityBand>;
}
