import { TradePack } from './types';

export const drivewaysPack: TradePack = {
  id: 'driveways',
  displayName: 'Driveways & concrete',
  jobWord: 'driveway',
  icon: 'Layers',
  defaultUnitSystem: 'metric',
  jobTypes: [
    {
      id: 'poured_concrete',
      name: 'Poured concrete driveway',
      description: 'Reinforced brushed concrete with expansion joints',
      baseLabourDays: 4,
      defaultSqM: 50
    },
    {
      id: 'stamped_concrete',
      name: 'Pattern imprinted concrete',
      description: 'Coloured, stamped texture with protective high-gloss seal',
      baseLabourDays: 5,
      defaultSqM: 45
    },
    {
      id: 'block_paving',
      name: 'Block paving driveway',
      description: 'Kiln-dried sand, interlocked block pavers and curb edges',
      baseLabourDays: 6,
      defaultSqM: 40
    },
    {
      id: 'tarmac_asphalt',
      name: 'Asphalt / tarmac drive',
      description: 'Hot-rolled wearing course over compacted base',
      baseLabourDays: 3,
      defaultSqM: 60
    },
    {
      id: 'patio_slab',
      name: 'Backyard patio slab',
      description: 'Smooth outdoor concrete slab for outdoor living',
      baseLabourDays: 3,
      defaultSqM: 30
    }
  ],
  photoShots: [
    {
      id: 'whole_drive',
      label: 'Whole driveway',
      why: 'From the street showing width, length and boundary lines',
      required: true
    },
    {
      id: 'ground_slope',
      label: 'Ground slope & drain',
      why: 'Shows where rainwater runs off towards road or garden',
      required: true
    },
    {
      id: 'truck_access',
      label: 'Street & truck access',
      why: 'Checks if ready-mix concrete lorry can chute directly',
      required: true
    },
    {
      id: 'manholes',
      label: 'Manhole covers & drains',
      why: 'Shows any inspection covers needing recessed lids'
    },
    {
      id: 'current_surface',
      label: 'Current surface close-up',
      why: 'Shows old asphalt, grass or cracked concrete to dig out'
    }
  ],
  measureFields: [
    {
      id: 'length',
      label: 'Driveway length',
      helper: 'From pavement/road to garage or front door',
      type: 'number',
      unit: 'm',
      imperialUnit: 'ft',
      min: 3,
      max: 60,
      step: 0.5,
      defaultVal: 12.0,
      group: 'Size'
    },
    {
      id: 'width',
      label: 'Driveway width',
      helper: 'Average width across parking bays',
      type: 'number',
      unit: 'm',
      imperialUnit: 'ft',
      min: 2,
      max: 30,
      step: 0.2,
      defaultVal: 4.5,
      group: 'Size'
    },
    {
      id: 'thickness',
      label: 'Concrete thickness',
      helper: 'Depth of new concrete slab',
      type: 'segmented',
      defaultVal: '100mm',
      options: [
        { value: '100mm', label: '100 mm (4 in)', description: 'Cars and small vans' },
        { value: '150mm', label: '150 mm (6 in)', description: 'Heavy trucks / SUVs' }
      ],
      group: 'Excavation & depth'
    },
    {
      id: 'old_surface',
      label: 'Existing ground to remove',
      helper: 'What is currently on the ground',
      type: 'picker',
      defaultVal: 'tarmac',
      options: [
        { value: 'dirt', label: 'Dirt / lawn', extraCost: 0 },
        { value: 'gravel', label: 'Gravel & soil', extraCost: 350 },
        { value: 'tarmac', label: 'Old cracked asphalt', extraCost: 750 },
        { value: 'concrete', label: 'Old thick concrete', extraCost: 1400, flag: 'Needs hydraulic breaker attachment' }
      ],
      group: 'Excavation & depth'
    },
    {
      id: 'drainage',
      label: 'Rain drainage solution',
      helper: 'Channel to stop water running into house or road',
      type: 'segmented',
      defaultVal: 'aco',
      options: [
        { value: 'slope', label: 'Natural lawn slope' },
        { value: 'aco', label: 'ACO slot drain', extraCost: 650 },
        { value: 'soakaway', label: 'New soakaway crate', extraCost: 1200 }
      ],
      group: 'Drainage & edges'
    },
    {
      id: 'edge_kerb',
      label: 'Border edges',
      helper: 'Kerb stones along lawn or neighbor boundary',
      type: 'segmented',
      defaultVal: 'flush',
      options: [
        { value: 'timber', label: 'Treated timber forms' },
        { value: 'flush', label: 'Concrete pin kerbs', extraCost: 480 },
        { value: 'raised', label: 'Raised bullnose kerbs', extraCost: 950 }
      ],
      group: 'Drainage & edges'
    },
    {
      id: 'sealer',
      label: 'Protective sealer',
      helper: 'Resists oil spots, salt, water and UV fading',
      type: 'segmented',
      defaultVal: 'single',
      options: [
        { value: 'none', label: 'None' },
        { value: 'single', label: 'Matt sealer coat', extraCost: 380 },
        { value: 'double', label: 'Double gloss coat', extraCost: 680 }
      ],
      group: 'Finish'
    }
  ],
  questions: [
    {
      id: 'truck_access',
      text: 'Can a concrete truck chute directly?',
      options: [
        { value: 'yes', label: 'Yes, direct access' },
        {
          value: 'no_pump',
          label: 'No, needs ground pump',
          priceEffect: {
            description: 'Mobile concrete pump hire and line crew',
            amount: 850,
            category: 'extras'
          },
          flagEffect: {
            id: 'pump_flag',
            title: 'Concrete pump hire required',
            detail: 'Distance from road is over 8m. Ground line pump booked.',
            type: 'warning'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Contingency for tight truck access',
            amount: 450,
            category: 'extras'
          }
        }
      ]
    },
    {
      id: 'manhole_covers',
      text: 'Are there manhole covers on the drive?',
      options: [
        { value: 'none', label: 'None' },
        {
          value: 'one_two',
          label: '1 or 2 covers',
          priceEffect: {
            description: 'Recessed tray lids & riser frames',
            amount: 320,
            category: 'materials'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Contingency for drain lids',
            amount: 200,
            category: 'extras'
          }
        }
      ]
    },
    {
      id: 'ground_firmness',
      text: 'Is the sub-ground firm or soft clay?',
      options: [
        { value: 'firm', label: 'Firm ground' },
        {
          value: 'soft',
          label: 'Soft clay / boggy',
          priceEffect: {
            description: 'Geotextile separation membrane & extra crushed stone',
            amount: 550,
            category: 'materials'
          },
          flagEffect: {
            id: 'soft_subbase',
            title: 'Sub-base reinforcement required',
            detail: 'Soft ground requires non-woven membrane and 150mm compacted Type 1.',
            type: 'warning'
          }
        },
        {
          value: 'not_sure',
          label: 'Not sure',
          priceEffect: {
            description: 'Contingency for ground conditions',
            amount: 350,
            category: 'extras'
          }
        }
      ]
    },
    {
      id: 'road_kerb',
      text: 'Does pavement kerb need dropping?',
      options: [
        { value: 'no', label: 'No, already dropped' },
        {
          value: 'yes',
          label: 'Yes, needs dropped kerb',
          priceEffect: {
            description: 'Highway kerb work and street license',
            amount: 1400,
            category: 'fees'
          },
          flagEffect: {
            id: 'kerb_license',
            title: 'Council dropped kerb permit required',
            detail: 'Work on the public footway requires council streetworks license.',
            type: 'risk'
          }
        },
        { value: 'not_sure', label: 'Not sure' }
      ]
    }
  ],
  priceBook: [
    { id: 'sub_base', name: 'Type 1 crushed stone sub-base', category: 'materials', unit: 'tonne', defaultCost: 42, wastePct: 10, isDefault: true },
    { id: 'concrete_c35', name: 'Ready-mix C35 fibre concrete', category: 'materials', unit: 'm³', defaultCost: 155, wastePct: 5, isDefault: true },
    { id: 'steel_mesh', name: 'Steel reinforcing mesh A142', category: 'materials', unit: 'sheet', defaultCost: 48, wastePct: 8, isDefault: true },
    { id: 'aco_drain', name: 'ACO slot drain channel kit', category: 'materials', unit: 'm', defaultCost: 35, wastePct: 0, isDefault: true },
    { id: 'recessed_lid', name: 'Recessed pave-in manhole lid', category: 'materials', unit: 'item', defaultCost: 110, wastePct: 0, isDefault: true },
    { id: 'timber_shutter', name: 'Treated edge timber & stakes', category: 'materials', unit: 'm', defaultCost: 14, wastePct: 10, isDefault: true },
    { id: 'digger_hire', name: '3-tonne mini digger hire', category: 'extras', unit: 'job', defaultCost: 650, wastePct: 0, isDefault: true },
    { id: 'muck_away', name: 'Grab wagon soil muck-away', category: 'extras', unit: 'load', defaultCost: 320, wastePct: 0, isDefault: true },
    { id: 'concrete_sealer', name: 'Commercial driveway acrylic sealer', category: 'materials', unit: 'drum', defaultCost: 140, wastePct: 0, isDefault: true }
  ],
  labourRates: {
    hourlyRate: 52,
    crewSize: 3,
    hoursPerSqM: 1.8
  },
  packages: [
    {
      id: 'basic',
      name: 'Basic',
      bullets: [
        'Full mechanical excavation & waste muck-away',
        '100mm compacted Type 1 crushed stone base',
        '100mm C35 fibre-reinforced brushed concrete',
        'Hand-cut expansion joints to prevent cracking'
      ],
      scopeModifiers: () => ({ addedItems: [] })
    },
    {
      id: 'nice',
      name: 'Nice',
      bullets: [
        'Everything in Basic',
        '125mm reinforced slab with A142 steel mesh',
        'Decorative picture-frame trowel borders',
        'Double-coat penetrating acrylic seal against oil & salt'
      ],
      scopeModifiers: () => ({
        addedItems: [
          {
            id: 'steel_mesh_nice',
            name: 'A142 steel mesh reinforcing',
            quantity: 8,
            unit: 'sheet',
            unitCost: 48,
            category: 'materials'
          },
          {
            id: 'sealer_nice',
            name: 'Double-coat acrylic driveway sealer',
            quantity: 2,
            unit: 'drum',
            unitCost: 140,
            category: 'materials'
          }
        ],
        extraDays: 1
      })
    },
    {
      id: 'top',
      name: 'Top',
      bullets: [
        'Everything in Nice',
        'Pattern imprinted decorative slate or stone finish',
        'Integrated ACO slot drainage along front boundary',
        'Charcoal brick perimeter curb set in concrete haunch'
      ],
      scopeModifiers: () => ({
        addedItems: [
          {
            id: 'imprint_kit_top',
            name: 'Pattern stamp moulds, release & antique tint',
            quantity: 1,
            unit: 'job',
            unitCost: 950,
            category: 'materials'
          },
          {
            id: 'aco_top',
            name: 'Full boundary ACO slot drain run',
            quantity: 1,
            unit: 'job',
            unitCost: 650,
            category: 'materials'
          },
          {
            id: 'brick_kerb_top',
            name: 'Perimeter paving kerb course',
            quantity: 1,
            unit: 'job',
            unitCost: 850,
            category: 'materials'
          }
        ],
        extraDays: 2
      })
    }
  ],
  riskChecks: [
    {
      id: 'pump_check',
      title: 'Concrete pump booking required',
      detail: 'Truck cannot chute straight to driveway. Confirm pump truck arrival time.',
      triggeredIf: (answers) => answers.truck_access === 'no_pump'
    },
    {
      id: 'kerb_check',
      title: 'Dropped kerb license check',
      detail: 'Council road permit required before crossing footway.',
      triggeredIf: (answers) => answers.road_kerb === 'yes'
    },
    {
      id: 'soft_ground_check',
      title: 'Soft clay ground',
      detail: 'Ensure membrane is laid prior to gravel compaction.',
      triggeredIf: (answers) => answers.ground_firmness === 'soft'
    }
  ],
  exclusions: [
    'Council dropped kerb planning permissions or road inspection costs',
    'Moving underground gas or water main supply pipes',
    'Removal of hazardous underground waste or buried masonry'
  ],
  assumptions: [
    'Unrestricted lorry parking and clear access from road',
    'Water tap access available on site during wash-down and mixing',
    'Work carried out in dry weather conditions suitable for concrete curing'
  ],
  customerWording: {
    headline: 'Your new concrete driveway',
    description: 'A solid, clean driveway engineered to park your cars without sinking, pooling water or cracking.',
    whatsIncluded: (jobTypeId, tier) => {
      const base = [
        'Full dig out and carting away of old surface',
        'Compacted stone foundation layered for heavy vehicle weight',
        'High-strength concrete with fibre reinforcement',
        'Neat expansion joints to keep your driveway smooth and crack-free',
        'Clean site sweep and washdown when done'
      ];
      if (tier === 'nice' || tier === 'top') {
        base.push('Steel mesh rebar for long-term heavy car support');
        base.push('Oil-resistant and weatherproof protective seal coat');
      }
      if (tier === 'top') {
        base.push('Custom stone or slate textured finish with natural tint');
        base.push('Continuous rainwater drainage channel');
      }
      return base;
    },
    whatsNotIncluded: [
      'Dropped curb application to the local council',
      'Planting new flowerbeds or landscaping alongside drive'
    ]
  },
  sanityBands: {
    poured_concrete: { minPerSqM: 60, maxPerSqM: 140, minPerSqFt: 6, maxPerSqFt: 14 },
    stamped_concrete: { minPerSqM: 90, maxPerSqM: 190, minPerSqFt: 9, maxPerSqFt: 19 },
    block_paving: { minPerSqM: 80, maxPerSqM: 180, minPerSqFt: 8, maxPerSqFt: 18 },
    tarmac_asphalt: { minPerSqM: 55, maxPerSqM: 120, minPerSqFt: 5.5, maxPerSqFt: 12 },
    patio_slab: { minPerSqM: 70, maxPerSqM: 160, minPerSqFt: 7, maxPerSqFt: 16 }
  }
};
