import { TradePack } from './types';

export const roofingPack: TradePack = {
  id: 'roofing',
  displayName: 'Roofing',
  jobWord: 'roof',
  icon: 'Shield',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'pitched_slate', name: 'Slate / tile re-roof', description: 'Strip old tiles, breathable felt, new battens & tiles', baseLabourDays: 5, defaultSqM: 80 },
    { id: 'flat_epdm', name: 'EPDM rubber flat roof', description: 'Single-ply seamless membrane with 25-yr life', baseLabourDays: 2, defaultSqM: 25 },
    { id: 'roof_repair', name: 'Roof leak & valley repair', description: 'Replace broken slates, repoint ridge, lead flashing', baseLabourDays: 1, defaultSqM: 15 },
    { id: 'fascia_soffit', name: 'Fascia, soffit & gutters', description: 'New uPVC roofline boards and deep-flow gutters', baseLabourDays: 2, defaultSqM: 30 }
  ],
  photoShots: [
    { id: 'front_elevation', label: 'Front of house & roof', why: 'Shows roof pitch, height and scaffold access', required: true },
    { id: 'rear_elevation', label: 'Back roof slope', why: 'Checks rear valleys, chimneys or conservatories below', required: true },
    { id: 'chimney_flash', label: 'Chimney & lead flashing', why: 'Shows if chimney needs repointing or new lead', required: true },
    { id: 'gutters_fascia', label: 'Gutters & eave edge', why: 'Shows condition of timber fascia boards' }
  ],
  measureFields: [
    { id: 'roof_area', label: 'Roof surface area', helper: 'Total sloped area to cover', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 10, max: 300, defaultVal: 85, group: 'Size' },
    { id: 'roof_pitch', label: 'Roof pitch', helper: 'Steepness of the slope', type: 'segmented', defaultVal: 'medium', options: [{ value: 'low', label: 'Low (< 30°)' }, { value: 'medium', label: 'Medium (30-45°)' }, { value: 'steep', label: 'Steep (> 45°)', extraCost: 650 }], group: 'Size' },
    { id: 'ridge_length', label: 'Ridge length', helper: 'Length of apex ridge tiles', type: 'number', unit: 'm', imperialUnit: 'ft', min: 2, max: 40, defaultVal: 9, group: 'Details' },
    { id: 'valleys', label: 'Valleys / gulley joins', helper: 'Lead valley runs between slopes', type: 'stepper', min: 0, max: 6, defaultVal: 0, group: 'Details' },
    { id: 'chimneys', label: 'Chimney stacks', helper: 'Stacks needing lead apron & step flashing', type: 'stepper', min: 0, max: 4, defaultVal: 1, group: 'Details' },
    { id: 'stories', label: 'Building height', helper: 'Stories from ground to gutter', type: 'segmented', defaultVal: '2story', options: [{ value: 'bungalow', label: '1 story' }, { value: '2story', label: '2 story' }, { value: '3story', label: '3+ story', extraCost: 800 }], group: 'Access' }
  ],
  questions: [
    { id: 'scaffold_access', text: 'Can scaffolding go up on both sides?', options: [{ value: 'yes', label: 'Yes, clear ground' }, { value: 'conservatory', label: 'Conservatory / bridge needed', priceEffect: { description: 'Bridging scaffold beam', amount: 650, category: 'extras' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'batten_condition', text: 'Are current timber battens rotted?', options: [{ value: 'replace_all', label: 'Replace all battens' }, { value: 'sound', label: 'Good condition' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'felt_type', text: 'Breathable roofing membrane required?', options: [{ value: 'yes', label: 'Yes, heavy breather felt' }, { value: 'standard', label: 'Standard' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'tile_type', text: 'New tile material preference?', options: [{ value: 'concrete', label: 'Interlocking concrete' }, { value: 'natural_slate', label: 'Natural slate', priceEffect: { description: 'Natural slate premium', amount: 2200, category: 'materials' } }, { value: 'clay', label: 'Clay pantiles' }] },
    { id: 'lead_gutters', text: 'Replace lead valley liners?', options: [{ value: 'yes', label: 'Yes, Code 4 lead' }, { value: 'dry_valley', label: 'Dry GRP valley' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'solar_panels', text: 'Are there solar panels on roof?', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes, need solar team to remove', priceEffect: { description: 'Solar array de-mount & re-fit', amount: 1200, category: 'extras' }, flagEffect: { id: 'solar_flag', title: 'Solar panel removal', detail: 'Electrician needed to isolate and reinstall panels.', type: 'warning' } }, { value: 'not_sure', label: 'Not sure' }] }
  ],
  priceBook: [
    { id: 'roof_tiles', name: 'Interlocking concrete roof tiles', category: 'materials', unit: 'm²', defaultCost: 32, wastePct: 10, isDefault: true },
    { id: 'breathable_felt', name: 'Non-tear breathable felt roll', category: 'materials', unit: 'roll', defaultCost: 65, wastePct: 5, isDefault: true },
    { id: 'treated_battens', name: 'Treated 25x50mm roof battens', category: 'materials', unit: 'm', defaultCost: 2.2, wastePct: 10, isDefault: true },
    { id: 'code4_lead', name: 'Code 4 milled lead roll', category: 'materials', unit: 'roll', defaultCost: 140, wastePct: 0, isDefault: true },
    { id: 'scaffold_package', name: 'Full perimeter scaffold wrap', category: 'extras', unit: 'job', defaultCost: 1750, wastePct: 0, isDefault: true },
    { id: 'skip_waste', name: 'Tile rubble skip & disposal', category: 'extras', unit: 'job', defaultCost: 650, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 55, crewSize: 3, hoursPerSqM: 1.2 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Tear-off old tiles & felt', 'Treated timber battens', 'Concrete interlocking tiles', 'Mortar-bedded ridge'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Heavy-grade breathable membrane', 'Maintenance-free dry ridge & verge system', 'Code 4 lead chimney flashing'], scopeModifiers: () => ({ addedItems: [{ id: 'dry_ridge_kit', name: 'Mechanical dry ridge & verge kit', quantity: 1, unit: 'job', unitCost: 480, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Premium natural Spanish slate', 'New uPVC fascia, vented soffit and deep gutters', '25-year structural guarantee'], scopeModifiers: () => ({ addedItems: [{ id: 'slate_premium', name: 'Natural slate & copper rivet upgrade', quantity: 1, unit: 'job', unitCost: 2800, category: 'materials' }, { id: 'roofline_kit', name: 'Fascia, soffit & gutter replacement', quantity: 1, unit: 'job', unitCost: 950, category: 'materials' }], extraDays: 2 }) }
  ],
  riskChecks: [
    { id: 'chimney_check', title: 'Chimney stack deterioration', detail: 'Check mortar joints and pot flaunching for cracks.', triggeredIf: (a, m) => Number(m.chimneys || 0) > 0 }
  ],
  exclusions: ['Structural rafter alterations', 'Asbestos tile disposal fees'],
  assumptions: ['Clear driveway parking for skip and ladder access', 'Dry weather for strip-and-felt phase'],
  customerWording: {
    headline: 'Your new roof guarantee',
    description: 'A storm-proof, watertight roof that protects your home for decades to come.',
    whatsIncluded: () => ['Complete removal and disposal of old roof materials', 'Heavy-duty breathable felt layer', 'Solid treated timber battens', 'Neat tile alignment and waterproof leadwork', 'Full magnet sweep for nails on completion'],
    whatsNotIncluded: ['Fixing broken ceilings inside bedrooms', 'Interior wall painting']
  },
  sanityBands: {
    pitched_slate: { minPerSqM: 70, maxPerSqM: 180, minPerSqFt: 7, maxPerSqFt: 18 },
    flat_epdm: { minPerSqM: 80, maxPerSqM: 200, minPerSqFt: 8, maxPerSqFt: 20 },
    roof_repair: { minPerSqM: 40, maxPerSqM: 120, minPerSqFt: 4, maxPerSqFt: 12 },
    fascia_soffit: { minPerSqM: 45, maxPerSqM: 110, minPerSqFt: 4.5, maxPerSqFt: 11 }
  }
};

export const insulationPack: TradePack = {
  id: 'insulation',
  displayName: 'Insulation',
  jobWord: 'insulation',
  icon: 'Sun',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'loft_topup', name: 'Attic floor insulation top-up', description: 'Lay 200mm mineral wool roll over existing floor', baseLabourDays: 1, defaultSqM: 60 },
    { id: 'cavity_wall', name: 'Cavity wall bead insulation', description: 'Bonded silver EPS beads pumped through brickwork', baseLabourDays: 1, defaultSqM: 90 },
    { id: 'spray_foam', name: 'Open-cell rafter spray foam', description: 'Breathable foam spray directly to roof underside', baseLabourDays: 2, defaultSqM: 75 },
    { id: 'underfloor', name: 'Suspended floor insulation', description: 'PIR boards friction-fitted between ground joists', baseLabourDays: 2, defaultSqM: 45 }
  ],
  photoShots: [
    { id: 'attic_current', label: 'Current attic floor', why: 'Shows existing insulation depth and pipe lags', required: true },
    { id: 'hatch_seal', label: 'Loft hatch', why: 'Checks draft strip and insulated hatch board', required: true },
    { id: 'external_brick', label: 'Outside wall drill zone', why: 'Checks cavity width and brick mortar' }
  ],
  measureFields: [
    { id: 'insulation_area', label: 'Insulation area', helper: 'Floor or wall area to insulate', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 10, max: 250, defaultVal: 65, group: 'Size' },
    { id: 'current_depth', label: 'Current depth', helper: 'Depth of existing old insulation', type: 'segmented', defaultVal: '100mm', options: [{ value: 'none', label: 'Zero / bare' }, { value: '100mm', label: '100 mm (thin)' }, { value: '200mm', label: '200 mm' }], group: 'Specs' },
    { id: 'target_depth', label: 'Target depth', helper: 'New building standard target', type: 'segmented', defaultVal: '300mm', options: [{ value: '200mm', label: '200 mm' }, { value: '300mm', label: '300 mm (standard)' }, { value: '400mm', label: '400 mm (passive)' }], group: 'Specs' },
    { id: 'pipe_lagging', label: 'Water pipes to insulate', helper: 'Length of water pipe runs in attic', type: 'number', unit: 'm', imperialUnit: 'ft', min: 0, max: 30, defaultVal: 8, group: 'Extras' },
    { id: 'boarded_walkway', label: 'Walkway boarding', helper: 'Safe raised boarding to access water tanks', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 0, max: 20, defaultVal: 6, group: 'Extras' },
    { id: 'hatch_upgrade', label: 'Insulated hatch door', helper: 'Air-tight draft-proof drop down door', type: 'segmented', defaultVal: 'yes', options: [{ value: 'yes', label: 'Yes, draft-seal door', extraCost: 180 }, { value: 'no', label: 'Keep current' }], group: 'Extras' }
  ],
  questions: [
    { id: 'damp_signs', text: 'Any damp patches or mold in the attic?', options: [{ value: 'none', label: 'Completely dry' }, { value: 'some_damp', label: 'Damp near eaves', priceEffect: { description: 'Soffit vent baffles to stop condensation', amount: 220, category: 'materials' }, flagEffect: { id: 'damp_flag', title: 'Roof ventilation check', detail: 'Ensure air flow at eaves is not blocked by insulation.', type: 'warning' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'downlight_covers', text: 'Are there recessed ceiling downlights?', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes, need fire hoods', priceEffect: { description: 'Fire-rated downlight protection hoods', amount: 160, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'old_rubbish', text: 'Clear out old junk before starting?', options: [{ value: 'empty', label: 'Already cleared' }, { value: 'needs_clearing', label: 'Contractor to clear', priceEffect: { description: 'Attic clearance and rubbish bag disposal', amount: 300, category: 'labor' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'hatch_ladder', text: 'Add an aluminum loft ladder?', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes, 3-section ladder', priceEffect: { description: 'Integrated fold-down aluminum ladder', amount: 240, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'water_tank_jacket', text: 'Insulate header water tank?', options: [{ value: 'yes', label: 'Yes, tank insulation jacket' }, { value: 'no', label: 'No tank / combi boiler' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'vermin_evidence', text: 'Any signs of mice or squirrels?', options: [{ value: 'clean', label: 'No, clean attic' }, { value: 'vermin', label: 'Yes, droppings seen', flagEffect: { id: 'vermin_flag', title: 'Pest check required', detail: 'Seal external access points before laying fresh wool.', type: 'warning' } }, { value: 'not_sure', label: 'Not sure' }] }
  ],
  priceBook: [
    { id: 'mineral_wool', name: 'Earthwool 200mm thermal insulation', category: 'materials', unit: 'm²', defaultCost: 12, wastePct: 5, isDefault: true },
    { id: 'air_seal_foam', name: 'Acoustic air-stop expanding foam', category: 'materials', unit: 'can', defaultCost: 16, wastePct: 0, isDefault: true },
    { id: 'vent_baffle', name: 'Rafter eave ventilation baffle', category: 'materials', unit: 'item', defaultCost: 6.5, wastePct: 0, isDefault: true },
    { id: 'insulated_hatch', name: 'Thermal draught-proof drop-down hatch', category: 'materials', unit: 'item', defaultCost: 180, wastePct: 0, isDefault: true },
    { id: 'raised_legs', name: 'StoreFloor loft storage stilts & boards', category: 'materials', unit: 'm²', defaultCost: 28, wastePct: 5, isDefault: true }
  ],
  labourRates: { hourlyRate: 48, crewSize: 2, hoursPerSqM: 0.35 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Top-up to 200mm mineral wool', 'Pipe lagging around exposed water pipes', 'Cold water tank insulation wrap'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Top-up to 300mm building spec depth', 'Draft-proof insulated hatch door', 'Eaves ventilation baffles'], scopeModifiers: () => ({ addedItems: [{ id: 'hatch_nice', name: 'Draft-proof insulated hatch door', quantity: 1, unit: 'item', unitCost: 180, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', '10 m² raised storage boarding system', 'Aluminum fold-down loft ladder', 'Full air-leak sealing around ceiling lights'], scopeModifiers: () => ({ addedItems: [{ id: 'storage_top', name: 'Raised floor storage boarding system', quantity: 10, unit: 'm²', unitCost: 28, category: 'materials' }, { id: 'ladder_top', name: 'Fold-down aluminum ladder', quantity: 1, unit: 'item', unitCost: 220, category: 'materials' }] }) }
  ],
  riskChecks: [
    { id: 'eaves_vent_risk', title: 'Eaves ventilation blockage', detail: 'Ensure air flow at roof eaves stays open to avoid roof condensation.', triggeredIf: (a) => a.damp_signs === 'some_damp' }
  ],
  exclusions: ['Roof timber rot repairs', 'Electrical rewiring'],
  assumptions: ['Clear access through hatch into attic', 'Safe walking boards over joists provided during work'],
  customerWording: {
    headline: 'Your home insulation upgrade',
    description: 'Keep heat in and bills down with thick, breathable, modern thermal insulation.',
    whatsIncluded: () => ['Full coverage with itchy-free thermal insulation', 'Foam air-sealing around pipe penetrations', 'Protective pipe insulation wraps', 'Tidy clean-up and dust vacuum'],
    whatsNotIncluded: ['Clearing out personal storage boxes', 'Roof tile repairs']
  },
  sanityBands: {
    loft_topup: { minPerSqM: 18, maxPerSqM: 45, minPerSqFt: 1.8, maxPerSqFt: 4.5 },
    cavity_wall: { minPerSqM: 25, maxPerSqM: 60, minPerSqFt: 2.5, maxPerSqFt: 6 },
    spray_foam: { minPerSqM: 45, maxPerSqM: 110, minPerSqFt: 4.5, maxPerSqFt: 11 },
    underfloor: { minPerSqM: 35, maxPerSqM: 85, minPerSqFt: 3.5, maxPerSqFt: 8.5 }
  }
};

export const kitchenPack: TradePack = {
  id: 'kitchen',
  displayName: 'Kitchen remodel',
  jobWord: 'kitchen',
  icon: 'Utensils',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'full_remodel', name: 'Full kitchen rip & fit', description: 'Remove old kitchen, fit cabinets, worktops, appliances and tiles', baseLabourDays: 8, defaultSqM: 15 },
    { id: 'cabinet_refresh', name: 'Door & worktop swap', description: 'Keep carcases, fit new doors, handles and quartz worktop', baseLabourDays: 3, defaultSqM: 12 },
    { id: 'open_plan_knock', name: 'Open plan kitchen-diner', description: 'Knock down dividing wall, install steel lintel, full fit-out', baseLabourDays: 14, defaultSqM: 25 }
  ],
  photoShots: [
    { id: 'current_kitchen', label: 'Overall kitchen view', why: 'Shows cabinet layout and room bounds', required: true },
    { id: 'sink_plumbing', label: 'Under sink plumbing', why: 'Shows stopcock, waste pipes and water pressure', required: true },
    { id: 'cooker_point', label: 'Cooker supply / gas', why: 'Shows 32A cooker point or gas valve' },
    { id: 'walls_tiles', label: 'Wall tile area', why: 'Shows square meters for splashback tiles' }
  ],
  measureFields: [
    { id: 'room_area', label: 'Kitchen floor area', helper: 'Square metres of floor space', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 4, max: 60, defaultVal: 14, group: 'Dimensions' },
    { id: 'cabinet_units', label: 'Number of cabinets', helper: 'Base and wall cabinets combined', type: 'stepper', min: 4, max: 30, defaultVal: 12, group: 'Cabinets' },
    { id: 'worktop_length', label: 'Worktop length', helper: 'Total running metres of counter', type: 'number', unit: 'm', imperialUnit: 'ft', min: 2, max: 20, defaultVal: 6, group: 'Worktops' },
    { id: 'worktop_type', label: 'Worktop material', helper: 'Countertop surface', type: 'segmented', defaultVal: 'quartz', options: [{ value: 'laminate', label: 'Laminate' }, { value: 'solid_wood', label: 'Solid oak', extraCost: 650 }, { value: 'quartz', label: 'Quartz stone', extraCost: 1800 }], group: 'Worktops' },
    { id: 'appliances', label: 'Integrated appliances', helper: 'Oven, hob, dishwasher, fridge to install', type: 'stepper', min: 1, max: 8, defaultVal: 4, group: 'Appliances' },
    { id: 'splashback', label: 'Splashback tiles', helper: 'Tiled area between counter and wall units', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 0, max: 15, defaultVal: 4, group: 'Finish' }
  ],
  questions: [
    { id: 'sink_location', text: 'Keep sink in same spot?', options: [{ value: 'keep', label: 'Yes, same spot' }, { value: 'move', label: 'No, move sink', priceEffect: { description: 'Extend waste and hot/cold pipes', amount: 480, category: 'labor' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'hob_fuel', text: 'Electric induction or gas hob?', options: [{ value: 'electric', label: 'Induction / electric' }, { value: 'gas', label: 'Gas hob', priceEffect: { description: 'Gas Safe engineer connection', amount: 220, category: 'fees' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'flooring_work', text: 'Replace kitchen flooring?', options: [{ value: 'no', label: 'Keep current' }, { value: 'lvt_tiles', label: 'New LVT / tile floor', priceEffect: { description: 'Floor prep and luxury vinyl tile lay', amount: 750, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'drywall_condition', text: 'Are walls in good condition behind tiles?', options: [{ value: 'sound', label: 'Good plaster' }, { value: 're_plaster', label: 'Need plaster skimming', priceEffect: { description: 'Plaster skim kitchen walls', amount: 450, category: 'labor' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'lighting_upgrade', text: 'Add ceiling downlights?', options: [{ value: 'keep', label: 'Keep pendant' }, { value: 'downlights', label: 'Add 6 LED downlights', priceEffect: { description: 'LED downlights and dimmer switch', amount: 380, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'skip_disposal', text: 'Old kitchen rip-out & waste skip?', options: [{ value: 'contractor_skip', label: 'Yes, skip included' }, { value: 'homeowner_clears', label: 'Homeowner clears' }, { value: 'not_sure', label: 'Not sure' }] }
  ],
  priceBook: [
    { id: 'base_cabinet', name: 'Soft-close kitchen base unit', category: 'materials', unit: 'item', defaultCost: 120, wastePct: 0, isDefault: true },
    { id: 'wall_cabinet', name: 'Wall kitchen cupboard unit', category: 'materials', unit: 'item', defaultCost: 95, wastePct: 0, isDefault: true },
    { id: 'quartz_counter', name: 'Fabricated 30mm quartz counter', category: 'materials', unit: 'm', defaultCost: 280, wastePct: 0, isDefault: true },
    { id: 'undermount_sink', name: 'Stainless sink and mixer tap', category: 'materials', unit: 'item', defaultCost: 260, wastePct: 0, isDefault: true },
    { id: 'extractor_duct', name: 'Cooker hood and external vent', category: 'materials', unit: 'item', defaultCost: 210, wastePct: 0, isDefault: true },
    { id: 'waste_skip', name: 'Kitchen rip-out skip & carting', category: 'extras', unit: 'job', defaultCost: 450, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 56, crewSize: 2, hoursPerSqM: 4.0 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Removal of old kitchen', 'Flat-pack cabinet assembly & levelling', 'Laminate worktop with neat jointing', 'Plumbing sink and appliance hook-up'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Factory-built rigid carcases with soft-close', 'Solid oak or composite counter', 'Wall tile splashback with neat silicone', 'Under-cabinet LED strip lighting'], scopeModifiers: () => ({ addedItems: [{ id: 'lighting_nice', name: 'Under-cabinet LED strip lighting', quantity: 1, unit: 'job', unitCost: 320, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Bespoke quartz counters with undermount sink', 'Integrated wine cooler & pull-out larder', 'Full plaster skim and fresh washable paint', 'Luxury vinyl tile flooring installed'], scopeModifiers: () => ({ addedItems: [{ id: 'quartz_top', name: 'Templated quartz stone counter', quantity: 1, unit: 'job', unitCost: 1950, category: 'materials' }, { id: 'flooring_top', name: 'Prep and luxury vinyl tile flooring', quantity: 1, unit: 'job', unitCost: 850, category: 'materials' }], extraDays: 3 }) }
  ],
  riskChecks: [
    { id: 'gas_pipe_check', title: 'Gas safety check', detail: 'Gas hob disconnect and reconnect requires Gas Safe registration.', triggeredIf: (a) => a.hob_fuel === 'gas' }
  ],
  exclusions: ['Purchasing freestanding microwave/kettle', 'Major structural beam installation'],
  assumptions: ['Water shutoff valve is operable', 'Electric fuse board has 32A cooker circuit'],
  customerWording: {
    headline: 'Your dream kitchen installation',
    description: 'We handle everything from rip-out to final polish so you can cook in a stunning, organised kitchen.',
    whatsIncluded: () => ['Safe removal and recycling of your old cabinets', 'Level installation of new base and wall units', 'Water and drain connections to sink and dishwasher', 'Neat joint sealing around worktops', 'Full clean and surface vacuum before handover'],
    whatsNotIncluded: ['Specialist stone supplier templating delays', 'Painting non-kitchen hallways']
  },
  sanityBands: {
    full_remodel: { minPerSqM: 600, maxPerSqM: 1800, minPerSqFt: 55, maxPerSqFt: 165 },
    cabinet_refresh: { minPerSqM: 250, maxPerSqM: 700, minPerSqFt: 25, maxPerSqFt: 65 },
    open_plan_knock: { minPerSqM: 900, maxPerSqM: 2500, minPerSqFt: 85, maxPerSqFt: 230 }
  }
};

export const bathroomPack: TradePack = {
  id: 'bathroom',
  displayName: 'Bathroom remodel',
  jobWord: 'bathroom',
  icon: 'Droplet',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'full_bathroom', name: 'Full family bathroom renovation', description: 'Bath, shower, vanity, toilet and floor-to-ceiling tiles', baseLabourDays: 7, defaultSqM: 6 },
    { id: 'walkin_shower', name: 'Walk-in wet room / shower', description: 'Remove bath, fit low-profile tray, glass panel and power shower', baseLabourDays: 5, defaultSqM: 5 },
    { id: 'cloakroom', name: 'Downstairs cloakroom / WC', description: 'Compact toilet, basin vanity and splashback tiles', baseLabourDays: 3, defaultSqM: 3 }
  ],
  photoShots: [
    { id: 'current_bath', label: 'Full bathroom overview', why: 'Shows toilet, basin and bath layout', required: true },
    { id: 'soil_pipe', label: 'Soil waste stack', why: 'Checks where toilet waste pipe exits wall or floor', required: true },
    { id: 'shower_wall', label: 'Shower wall area', why: 'Checks waterproofing and tile condition' }
  ],
  measureFields: [
    { id: 'room_area', label: 'Bathroom floor area', helper: 'Floor space between walls', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 2, max: 20, defaultVal: 5.5, group: 'Size' },
    { id: 'tile_wall_area', label: 'Wall tile area', helper: 'Square metres of wall to tile', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 4, max: 35, defaultVal: 18, group: 'Tiling' },
    { id: 'tile_type', label: 'Tile material', helper: 'Ceramic, porcelain or marble', type: 'segmented', defaultVal: 'porcelain', options: [{ value: 'ceramic', label: 'Ceramic' }, { value: 'porcelain', label: 'Porcelain (large)', extraCost: 350 }, { value: 'marble', label: 'Natural stone', extraCost: 850 }], group: 'Tiling' },
    { id: 'shower_type', label: 'Shower specification', helper: 'Mixer valve and shower head', type: 'segmented', defaultVal: 'thermostatic', options: [{ value: 'electric', label: 'Electric shower' }, { value: 'thermostatic', label: 'Thermostatic mixer', extraCost: 280 }, { value: 'rainfall', label: 'Rainfall & handset', extraCost: 520 }], group: 'Fittings' },
    { id: 'towel_rail', label: 'Heated towel radiator', helper: 'Connect to heating pipes or dual fuel', type: 'segmented', defaultVal: 'dual_fuel', options: [{ value: 'standard', label: 'Central heating only' }, { value: 'dual_fuel', label: 'Dual fuel electric & heat', extraCost: 220 }], group: 'Fittings' },
    { id: 'extractor_fan', label: 'Ventilation fan', helper: 'Ceiling extractor through loft or external wall', type: 'segmented', defaultVal: 'timer_fan', options: [{ value: 'timer_fan', label: 'Quiet timer fan', extraCost: 150 }, { value: 'humidistat', label: 'Continuous moisture fan', extraCost: 260 }], group: 'Fittings' }
  ],
  questions: [
    { id: 'move_toilet', text: 'Keep toilet in current position?', options: [{ value: 'keep', label: 'Yes, same position' }, { value: 'move', label: 'Move toilet', priceEffect: { description: 'Re-route 110mm soil stack pipe', amount: 550, category: 'labor' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'water_pressure', text: 'Is water pressure strong?', options: [{ value: 'good', label: 'High pressure / combi' }, { value: 'low_gravity', label: 'Low gravity flow', priceEffect: { description: 'Add shower booster pump', amount: 480, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'underfloor_heating', text: 'Install electric floor heating?', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes, warm floor wire & thermostat', priceEffect: { description: 'Electric under-tile warming mat', amount: 380, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'tanking_waterproof', text: 'Tank shower walls with waterproof membrane?', options: [{ value: 'yes', label: 'Yes, full liquid membrane' }, { value: 'standard', label: 'Standard tile backer' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'ceiling_downlights', text: 'Fit moisture-proof LED ceiling lights?', options: [{ value: 'yes', label: 'Yes, 4 IP65 downlights', priceEffect: { description: 'IP65 waterproof LED downlights', amount: 240, category: 'materials' } }, { value: 'keep', label: 'Keep current' }] },
    { id: 'lead_pipes', text: 'Any old lead pipes behind walls?', options: [{ value: 'copper_plastic', label: 'Modern copper/plastic' }, { value: 'old_lead', label: 'Old lead pipes present', priceEffect: { description: 'Replace lead pipework to mains', amount: 420, category: 'labor' }, flagEffect: { id: 'lead_flag', title: 'Lead pipe replacement', detail: 'Replace old lead pipes with WRAS approved barrier pipe.', type: 'warning' } }, { value: 'not_sure', label: 'Not sure' }] }
  ],
  priceBook: [
    { id: 'toilet_vanity', name: 'Close-coupled rimless WC & vanity unit', category: 'materials', unit: 'job', defaultCost: 520, wastePct: 0, isDefault: true },
    { id: 'acrylic_bath', name: 'Reinforced acrylic bath & waste kit', category: 'materials', unit: 'item', defaultCost: 340, wastePct: 0, isDefault: true },
    { id: 'thermo_shower', name: 'Twin-head thermostatic shower valve', category: 'materials', unit: 'item', defaultCost: 280, wastePct: 0, isDefault: true },
    { id: 'tanking_kit', name: 'Shower wet-room tanking membrane kit', category: 'materials', unit: 'job', defaultCost: 160, wastePct: 0, isDefault: true },
    { id: 'porcelain_tiles', name: 'Porcelain wall & floor tiles', category: 'materials', unit: 'm²', defaultCost: 35, wastePct: 10, isDefault: true },
    { id: 'towel_radiator', name: 'Anthracite heated ladder towel rail', category: 'materials', unit: 'item', defaultCost: 190, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 54, crewSize: 2, hoursPerSqM: 8.0 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Rip out old suite and tiles', 'New bath with front panel and mixer tap', 'Toilet and ceramic basin pedestal', 'Shower area wall tiling & silicone'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Walk-in low-profile stone resin shower tray', 'Waterproof tanking membrane behind tiles', 'Porcelain wall tiles & anthracite towel rail', 'Quiet extractor fan through outside wall'], scopeModifiers: () => ({ addedItems: [{ id: 'tanking_nice', name: 'Liquid tanking waterproofing membrane', quantity: 1, unit: 'job', unitCost: 180, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Designer vanity drawer unit with LED illuminated mirror', 'Thermostatic rainfall dual-head shower system', 'Under-tile electric floor warming kit', 'Full floor-to-ceiling tiling throughout'], scopeModifiers: () => ({ addedItems: [{ id: 'underfloor_top', name: 'Electric underfloor tile warming kit', quantity: 1, unit: 'job', unitCost: 380, category: 'materials' }, { id: 'mirror_top', name: 'Demisting LED illuminated touch mirror', quantity: 1, unit: 'item', unitCost: 240, category: 'materials' }], extraDays: 2 }) }
  ],
  riskChecks: [
    { id: 'soil_pipe_check', title: 'Soil pipe fall angle', detail: 'Check waste pipe has sufficient gradient if moving toilet.', triggeredIf: (a) => a.move_toilet === 'move' }
  ],
  exclusions: ['Boiler replacement or cylinder swap', 'Tile supply if client provides own'],
  assumptions: ['Water main stopcock isolates fully', 'Subfloor timbers are dry and free of rot'],
  customerWording: {
    headline: 'Your luxury new bathroom',
    description: 'A clean, watertight sanctuary with powerful hot water, modern fittings and perfect tile grout.',
    whatsIncluded: () => ['Complete removal and disposal of old fixtures', '100% waterproof barrier behind shower walls', 'Precision tiling and anti-mould silicone sealing', 'All hot and cold pipe testing under pressure', 'Polished cleanup ready for your first shower'],
    whatsNotIncluded: ['Bath towels, shampoo dispensers or blinds', 'Painting other hallways']
  },
  sanityBands: {
    full_bathroom: { minPerSqM: 800, maxPerSqM: 2500, minPerSqFt: 75, maxPerSqFt: 230 },
    walkin_shower: { minPerSqM: 900, maxPerSqM: 2800, minPerSqFt: 85, maxPerSqFt: 260 },
    cloakroom: { minPerSqM: 600, maxPerSqM: 1800, minPerSqFt: 55, maxPerSqFt: 165 }
  }
};

export const paintingPack: TradePack = {
  id: 'painting',
  displayName: 'Painting & decorating',
  jobWord: 'paint job',
  icon: 'Palette',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'interior_full', name: 'Full house interior painting', description: 'Walls, ceilings, woodwork, doors and radiators', baseLabourDays: 6, defaultSqM: 120 },
    { id: 'single_room', name: 'Single room redecorate', description: 'Prep walls, 2 coats vinyl matt, gloss woodwork', baseLabourDays: 2, defaultSqM: 25 },
    { id: 'exterior_masonry', name: 'Exterior masonry & sills', description: 'Power wash, stabilise cracks, 2 coats weather-shield paint', baseLabourDays: 4, defaultSqM: 140 }
  ],
  photoShots: [
    { id: 'room_walls', label: 'Main walls & light', why: 'Shows wall condition and ceiling height', required: true },
    { id: 'woodwork_doors', label: 'Doors & skirting boards', why: 'Shows if existing paint is oil-based or peeling', required: true },
    { id: 'cracks_stains', label: 'Cracks or water stains', why: 'Shows repair prep needed before painting' }
  ],
  measureFields: [
    { id: 'wall_area', label: 'Total wall & ceiling area', helper: 'Square metres of surfaces to paint', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 10, max: 500, defaultVal: 110, group: 'Surfaces' },
    { id: 'doors_count', label: 'Internal doors', helper: 'Doors to rub down, undercoat and gloss', type: 'stepper', min: 0, max: 20, defaultVal: 6, group: 'Woodwork' },
    { id: 'skirting_length', label: 'Skirting board length', helper: 'Metres of baseboards to paint', type: 'number', unit: 'm', imperialUnit: 'ft', min: 5, max: 120, defaultVal: 35, group: 'Woodwork' },
    { id: 'wall_condition', label: 'Wall preparation needed', helper: 'How much filling and sanding', type: 'segmented', defaultVal: 'minor', options: [{ value: 'minor', label: 'Minor picture holes' }, { value: 'moderate', label: 'Cracks and flaking', extraCost: 350 }, { value: 'heavy', label: 'Heavy lining / repair', extraCost: 750 }], group: 'Prep' },
    { id: 'paint_brand', label: 'Paint grade', helper: 'Quality of wall emulsion', type: 'segmented', defaultVal: 'trade', options: [{ value: 'trade', label: 'Trade vinyl matt' }, { value: 'washable', label: 'Durable scrubbable matt', extraCost: 180 }, { value: 'designer', label: 'Designer spec (F&B / Little Greene)', extraCost: 450 }], group: 'Materials' },
    { id: 'radiators', label: 'Radiators to paint', helper: 'Metal radiators to spray or brush', type: 'stepper', min: 0, max: 10, defaultVal: 3, group: 'Woodwork' }
  ],
  questions: [
    { id: 'ceiling_color', text: 'Ceilings brilliant white or match walls?', options: [{ value: 'white', label: 'Brilliant white' }, { value: 'match', label: 'Colour match walls' }, { value: 'no_ceiling', label: 'Do not paint ceilings' }] },
    { id: 'wallpaper_removal', text: 'Strip existing wallpaper first?', options: [{ value: 'no', label: 'No wallpaper' }, { value: 'strip_prep', label: 'Yes, strip and wash paste', priceEffect: { description: 'Wallpaper stripping and adhesive wash', amount: 480, category: 'labor' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'stain_blocking', text: 'Any water or smoke stains to seal?', options: [{ value: 'none', label: 'No stains' }, { value: 'stains_present', label: 'Yes, need stain blocker', priceEffect: { description: 'Zinsser stain-blocking primer coat', amount: 120, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'furniture_moved', text: 'Who moves heavy furniture into middle?', options: [{ value: 'homeowner', label: 'Homeowner clears rooms' }, { value: 'painter_helps', label: 'Painters move & cover furniture', priceEffect: { description: 'Furniture moving and heavy wrapping', amount: 250, category: 'labor' } }, { value: 'empty', label: 'House is empty' }] },
    { id: 'woodwork_sheen', text: 'Woodwork finish sheen?', options: [{ value: 'satinwood', label: 'Satinwood (subtle)' }, { value: 'eggshell', label: 'Eggshell (matt look)' }, { value: 'gloss', label: 'High gloss' }] },
    { id: 'exterior_ladder', text: 'Any high exterior walls above 2 stories?', options: [{ value: 'no', label: 'Standard ladder reach' }, { value: 'scaffold_needed', label: 'Need tower scaffold', priceEffect: { description: 'Access tower hire for high peaks', amount: 450, category: 'extras' } }, { value: 'not_sure', label: 'Not sure' }] }
  ],
  priceBook: [
    { id: 'trade_emulsion', name: 'Trade vinyl matt emulsion (10L)', category: 'materials', unit: 'tub', defaultCost: 48, wastePct: 5, isDefault: true },
    { id: 'durable_matt', name: 'Cleanable scrubbable acrylic matt', category: 'materials', unit: 'tub', defaultCost: 85, wastePct: 5, isDefault: true },
    { id: 'satinwood_paint', name: 'Water-based quick dry satinwood', category: 'materials', unit: 'can', defaultCost: 42, wastePct: 0, isDefault: true },
    { id: 'filler_sandpaper', name: 'Easy-sand filler, caulk & abrasives', category: 'materials', unit: 'job', defaultCost: 65, wastePct: 0, isDefault: true },
    { id: 'masking_sheets', name: 'Drop sheets and clean-edge tape', category: 'materials', unit: 'job', defaultCost: 55, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 44, crewSize: 2, hoursPerSqM: 0.3 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Fill minor picture pin holes', '2 coats trade vinyl matt on walls', '1 coat refresh on woodwork', 'Heavy dust sheets laid'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Full wall raking, flexible filler and machine sanding', '2 coats durable washable acrylic wall paint', 'Undercoat + satinwood finish on all doors and frames'], scopeModifiers: () => ({ addedItems: [{ id: 'prep_upgrade', name: 'Dustless mechanical wall sanding and prep', quantity: 1, unit: 'job', unitCost: 280, category: 'labor' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Designer paint brand specification (Farrow & Ball / Little Greene)', 'Stain-block sealing across all knots and patches', 'Detailed masking and two coats on all ceilings and radiators'], scopeModifiers: () => ({ addedItems: [{ id: 'designer_spec', name: 'Designer paint pigment upgrade', quantity: 1, unit: 'job', unitCost: 450, category: 'materials' }], extraDays: 1 }) }
  ],
  riskChecks: [
    { id: 'lead_paint_risk', title: 'Old peeling paint check', detail: 'Properties built before 1970 may have lead paint under layers.', triggeredIf: (a, m) => m.wall_condition === 'heavy' }
  ],
  exclusions: ['Plastering complete collapsed walls', 'Carpentry or door trimming'],
  assumptions: ['Electricity and good lighting available in every room', 'Homeowner clears small ornaments and pictures'],
  customerWording: {
    headline: 'Your professional paint finish',
    description: 'Sharp lines, perfectly filled walls and smooth satin woodwork that makes every room feel brand new.',
    whatsIncluded: () => ['Thorough floor and furniture sheet protection', 'Filling of cracks and nail holes with smooth sanding', 'Two full solid coats of quality paint', 'Crisp tape lines around skirting and frames', 'Daily tidy-up and clean vacuum before leaving'],
    whatsNotIncluded: ['Stripping non-agreed wallpaper', 'Moving delicate electrical equipment']
  },
  sanityBands: {
    interior_full: { minPerSqM: 18, maxPerSqM: 45, minPerSqFt: 1.8, maxPerSqFt: 4.5 },
    single_room: { minPerSqM: 22, maxPerSqM: 55, minPerSqFt: 2.2, maxPerSqFt: 5.5 },
    exterior_masonry: { minPerSqM: 20, maxPerSqM: 50, minPerSqFt: 2.0, maxPerSqFt: 5.0 }
  }
};

export const sidingPack: TradePack = {
  id: 'siding',
  displayName: 'Siding & cladding',
  jobWord: 'siding',
  icon: 'Square',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'fiber_cement', name: 'Fiber cement lap siding', description: 'James Hardie style fire-resistant composite planks', baseLabourDays: 5, defaultSqM: 90 },
    { id: 'vinyl_siding', name: 'Insulated vinyl siding', description: 'Low maintenance, pre-finished thermal vinyl cladding', baseLabourDays: 4, defaultSqM: 95 },
    { id: 'cedar_timber', name: 'Cedar / larch wood cladding', description: 'Architectural natural tongue & groove horizontal cladding', baseLabourDays: 6, defaultSqM: 80 }
  ],
  photoShots: [
    { id: 'elevation_full', label: 'Full exterior wall', why: 'Shows height and window cut-outs', required: true },
    { id: 'corner_detail', label: 'Corner and eaves detail', why: 'Shows corner trim requirements', required: true }
  ],
  measureFields: [
    { id: 'wall_area', label: 'Wall area to clad', helper: 'Total square metres minus windows', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 10, max: 400, defaultVal: 85, group: 'Size' },
    { id: 'corners_count', label: 'External corners', helper: 'Corner trim profile runs', type: 'stepper', min: 2, max: 12, defaultVal: 4, group: 'Trim' },
    { id: 'window_wraps', label: 'Windows to trim around', helper: 'Frame trim reveals', type: 'stepper', min: 0, max: 16, defaultVal: 6, group: 'Trim' },
    { id: 'weather_wrap', label: 'Housewrap moisture barrier', helper: 'Breathable Tyvek weather membrane', type: 'segmented', defaultVal: 'tyvek', options: [{ value: 'tyvek', label: 'Breathable Tyvek' }, { value: 'insulated', label: 'Rigid foam insulated board', extraCost: 650 }], group: 'Prep' },
    { id: 'soffit_depth', label: 'Eaves overhang depth', helper: 'Depth under roofline', type: 'segmented', defaultVal: 'standard', options: [{ value: 'flush', label: 'Flush eave' }, { value: 'standard', label: 'Standard 300mm' }, { value: 'deep', label: 'Deep 600mm+', extraCost: 350 }], group: 'Prep' },
    { id: 'scaffold_height', label: 'Wall height stories', helper: 'Access requirement', type: 'segmented', defaultVal: '2story', options: [{ value: 'single', label: '1 story' }, { value: '2story', label: '2 stories' }, { value: '3story', label: '3 stories', extraCost: 750 }], group: 'Access' }
  ],
  questions: [
    { id: 'tear_off', text: 'Remove old siding or cladding first?', options: [{ value: 'tear_off_all', label: 'Tear off old siding', priceEffect: { description: 'Tear off old cladding and disposal', amount: 850, category: 'labor' } }, { value: 'clean_substrate', label: 'Bare block/sheathing' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'rot_repair', text: 'Any known wood rot underneath?', options: [{ value: 'none', label: 'Sound wall' }, { value: 'some_rot', label: 'Suspected rot around windows', priceEffect: { description: 'Timber sheathing repair contingency', amount: 450, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'trim_colour', text: 'Contrasting colour corners and window trim?', options: [{ value: 'contrast', label: 'Yes, contrast colour' }, { value: 'match', label: 'Match siding colour' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'hose_bibs', text: 'Number of outside taps / electrical boxes to block out?', options: [{ value: 'few', label: '1 or 2 fixtures' }, { value: 'many', label: '3+ fixtures', priceEffect: { description: 'Mounting blocks and silicone seals', amount: 180, category: 'materials' } }, { value: 'none', label: 'None' }] },
    { id: 'ventilation_gap', text: 'Rain-screen batten air gap required?', options: [{ value: 'yes', label: 'Yes, counter-batten cavity' }, { value: 'direct', label: 'Direct fix to sheathing' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'pest_screen', text: 'Add stainless steel pest comb at base?', options: [{ value: 'yes', label: 'Yes, insect / rodent comb' }, { value: 'no', label: 'No' }, { value: 'not_sure', label: 'Not sure' }] }
  ],
  priceBook: [
    { id: 'fiber_cement_plank', name: 'Fiber cement primed siding plank', category: 'materials', unit: 'm²', defaultCost: 44, wastePct: 10, isDefault: true },
    { id: 'tyvek_wrap', name: 'Tyvek weather protection barrier roll', category: 'materials', unit: 'roll', defaultCost: 110, wastePct: 0, isDefault: true },
    { id: 'corner_trim_profile', name: 'Aluminium / cement corner trim', category: 'materials', unit: 'm', defaultCost: 18, wastePct: 5, isDefault: true },
    { id: 'stainless_nails', name: 'Stainless steel ring-shank siding nails', category: 'materials', unit: 'box', defaultCost: 45, wastePct: 0, isDefault: true },
    { id: 'scaffold_tower', name: 'Access scaffold & safety gear', category: 'extras', unit: 'job', defaultCost: 1200, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 52, crewSize: 3, hoursPerSqM: 1.1 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Moisture barrier housewrap', 'Standard horizontal lap siding', 'Matched corner pieces and seals'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Counter-batten rain-screen air gap', 'Window header flashings & drip caps', 'Factory pre-painted colour finish with 15-yr warranty'], scopeModifiers: () => ({ addedItems: [{ id: 'rainscreen_nice', name: 'Treated timber counter-batten air cavity', quantity: 1, unit: 'job', unitCost: 450, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Rigid exterior foam insulation backer board', 'Architectural mitered corners & window surrounds', 'Stainless insect and rodent comb along base'], scopeModifiers: () => ({ addedItems: [{ id: 'rigid_insul_top', name: 'Exterior insulation continuous thermal board', quantity: 1, unit: 'job', unitCost: 780, category: 'materials' }], extraDays: 2 }) }
  ],
  riskChecks: [
    { id: 'rot_check', title: 'Substrate moisture damage', detail: 'Inspect plywood sheathing for rot once old cladding is stripped.', triggeredIf: (a) => a.rot_repair === 'some_rot' }
  ],
  exclusions: ['Replacing window frames', 'Interior wall repairs'],
  assumptions: ['Clear 1m walkway around exterior walls during work', 'Exterior power point available'],
  customerWording: {
    headline: 'Your exterior siding transformation',
    description: 'Protect your home against driving rain and wind with crisp, durable, beautiful exterior cladding.',
    whatsIncluded: () => ['Tear-off and clean prep of exterior wall', 'Weather-tight breathable protective membrane', 'Straight precision-cut lap siding planks', 'Corner profiles and drip flashing over windows', 'Full site magnet sweep for stray fasteners'],
    whatsNotIncluded: ['Replacing double-glazed glass units', 'Roof guttering repairs']
  },
  sanityBands: {
    fiber_cement: { minPerSqM: 80, maxPerSqM: 200, minPerSqFt: 8, maxPerSqFt: 20 },
    vinyl_siding: { minPerSqM: 60, maxPerSqM: 140, minPerSqFt: 6, maxPerSqFt: 14 },
    cedar_timber: { minPerSqM: 110, maxPerSqM: 260, minPerSqFt: 11, maxPerSqFt: 26 }
  }
};

export const landscapingPack: TradePack = {
  id: 'landscaping',
  displayName: 'Landscaping & patios',
  jobWord: 'garden job',
  icon: 'Compass',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'porcelain_patio', name: 'Porcelain stone patio', description: 'Modern outdoor porcelain paving on full mortar bed', baseLabourDays: 4, defaultSqM: 35 },
    { id: 'composite_deck', name: 'Composite decking terrace', description: 'Treated frame with long-life composite deck boards', baseLabourDays: 3, defaultSqM: 25 },
    { id: 'turf_lawn', name: 'New lawn & soil prep', description: 'Rotovate ground, topsoil level, premium rolled turf', baseLabourDays: 2, defaultSqM: 80 }
  ],
  photoShots: [
    { id: 'garden_area', label: 'Full garden area', why: 'Shows slope, ground levels and boundary fences', required: true },
    { id: 'side_gate_access', label: 'Side gate access width', why: 'Checks if wheelbarrow or mini digger fits', required: true }
  ],
  measureFields: [
    { id: 'area_sqm', label: 'Patio or deck area', helper: 'Square metres of ground work', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 5, max: 200, defaultVal: 35, group: 'Size' },
    { id: 'ground_levels', label: 'Ground slope & level change', helper: 'Does ground need terracing or retaining', type: 'segmented', defaultVal: 'flat', options: [{ value: 'flat', label: 'Flat / level' }, { value: 'moderate', label: 'Gentle slope', extraCost: 350 }, { value: 'steep', label: 'Steep (needs retaining wall)', extraCost: 1200 }], group: 'Levels' },
    { id: 'paving_type', label: 'Paving material', helper: 'Slab selection', type: 'segmented', defaultVal: 'porcelain', options: [{ value: 'concrete_flag', label: 'Concrete flags' }, { value: 'sandstone', label: 'Indian sandstone', extraCost: 400 }, { value: 'porcelain', label: 'Outdoor porcelain', extraCost: 850 }], group: 'Materials' },
    { id: 'retaining_length', label: 'Retaining sleeper wall', helper: 'Oak sleeper wall length', type: 'number', unit: 'm', imperialUnit: 'ft', min: 0, max: 25, defaultVal: 0, group: 'Walls' },
    { id: 'steps_count', label: 'Garden steps needed', helper: 'Steps between levels', type: 'stepper', min: 0, max: 10, defaultVal: 2, group: 'Levels' },
    { id: 'edging_restraint', label: 'Perimeter garden edging', helper: 'Border restraint against lawn', type: 'segmented', defaultVal: 'stone_edge', options: [{ value: 'none', label: 'Direct lawn edge' }, { value: 'stone_edge', label: 'Setts / granite cobbles', extraCost: 320 }], group: 'Materials' }
  ],
  questions: [
    { id: 'gate_width', text: 'Can a mini digger get through the gate?', options: [{ value: 'yes', label: 'Wide gate (over 900mm)' }, { value: 'narrow', label: 'Narrow gate (hand barrow only)', priceEffect: { description: 'Manual barrowing labour surcharge', amount: 380, category: 'labor' } }, { value: 'no_access', label: 'Through house only', priceEffect: { description: 'Carry through house with floor protection', amount: 650, category: 'labor' } }] },
    { id: 'drainage_run', text: 'Where will rainwater drain?', options: [{ value: 'lawn', label: 'Falls into lawn/beds' }, { value: 'soakaway', label: 'Needs soakaway crate', priceEffect: { description: 'Percolation soakaway crate and pipe', amount: 480, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'weed_membrane', text: 'Heavy commercial geotextile weed barrier?', options: [{ value: 'yes', label: 'Yes, heavy woven membrane' }, { value: 'standard', label: 'Standard membrane' }] },
    { id: 'outdoor_lighting', text: 'Pre-wire for garden spike lights?', options: [{ value: 'no', label: 'No' }, { value: 'yes', label: 'Yes, conduit and junction box', priceEffect: { description: 'Underground armoured cable and ducting', amount: 280, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'old_patio_break', text: 'Old concrete patio to break up first?', options: [{ value: 'none', label: 'Lawn / bare soil' }, { value: 'break_patio', label: 'Old slab to break out', priceEffect: { description: 'Hydraulic breaker hire and rubble disposal', amount: 550, category: 'extras' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'skip_carting', text: 'Skip placement at front driveway?', options: [{ value: 'private_drive', label: 'On private driveway' }, { value: 'road_permit', label: 'On public road (permit needed)', priceEffect: { description: 'Council skip road license and lights', amount: 140, category: 'fees' } }, { value: 'not_sure', label: 'Not sure' }] }
  ],
  priceBook: [
    { id: 'porcelain_slabs', name: '20mm rectified porcelain paving slabs', category: 'materials', unit: 'm²', defaultCost: 45, wastePct: 10, isDefault: true },
    { id: 'type1_stone', name: 'Type 1 MOT crushed stone sub-base', category: 'materials', unit: 'tonne', defaultCost: 42, wastePct: 5, isDefault: true },
    { id: 'primer_slurry', name: 'Polymer bonding slurry primer', category: 'materials', unit: 'tub', defaultCost: 38, wastePct: 0, isDefault: true },
    { id: 'jointing_grout', name: 'Brush-in outdoor porcelain grout', category: 'materials', unit: 'tub', defaultCost: 55, wastePct: 0, isDefault: true },
    { id: 'oak_sleepers', name: 'Treated solid hardwood sleepers', category: 'materials', unit: 'item', defaultCost: 34, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 48, crewSize: 2, hoursPerSqM: 1.4 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Excavation and sub-base compaction', 'Paving laid on full mortar bed', 'Joints filled with brush-in sand compound'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Porcelain tiles slurry-primed on underside', 'Precision tile-leveling clips to avoid lipping', 'Weather-resistant epoxy grout'], scopeModifiers: () => ({ addedItems: [{ id: 'levelling_nice', name: 'Precision anti-lipping leveling spacers', quantity: 1, unit: 'job', unitCost: 140, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Oak sleeper raised flower bed wall', 'Recessed outdoor step lighting conduit', 'Pressure-washed and sealed clean surface'], scopeModifiers: () => ({ addedItems: [{ id: 'sleeper_top', name: 'Hardwood sleeper raised border feature', quantity: 6, unit: 'item', unitCost: 34, category: 'materials' }], extraDays: 1 }) }
  ],
  riskChecks: [
    { id: 'tree_roots_risk', title: 'Tree root interference', detail: 'Nearby large trees may require root-barrier membrane under patio.', triggeredIf: (a, m) => m.ground_levels === 'steep' }
  ],
  exclusions: ['Tree surgery above 3m', 'Gas barbecue gas line connection'],
  assumptions: ['Outside water hose available on site', 'Clear side access unobstructed by stored furniture'],
  customerWording: {
    headline: 'Your outdoor living patio',
    description: 'A level, beautiful outdoor terrace ready for garden dining and summer barbecues.',
    whatsIncluded: () => ['Mechanical dig out and ground compaction', 'Solid stone base so your patio never sinks', 'Porcelain or sandstone precision-laid flat', 'Neat weed-proof jointing between slabs', 'Tidy sweep and hose down on completion'],
    whatsNotIncluded: ['Supply of outdoor dining furniture', 'Lawn mowing after work']
  },
  sanityBands: {
    porcelain_patio: { minPerSqM: 85, maxPerSqM: 220, minPerSqFt: 8.5, maxPerSqFt: 22 },
    composite_deck: { minPerSqM: 110, maxPerSqM: 260, minPerSqFt: 11, maxPerSqFt: 26 },
    turf_lawn: { minPerSqM: 18, maxPerSqM: 45, minPerSqFt: 1.8, maxPerSqFt: 4.5 }
  }
};

export const electricalPack: TradePack = {
  id: 'electrical',
  displayName: 'Electrical',
  jobWord: 'electrical job',
  icon: 'Zap',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'consumer_unit', name: 'Fuse box / consumer unit upgrade', description: '18th Edition metal board with dual RCD & surge protection', baseLabourDays: 1, defaultSqM: 0 },
    { id: 'full_rewire', name: 'Complete house rewire', description: 'All new circuits, back boxes, sockets, switches and test certificate', baseLabourDays: 5, defaultSqM: 90 },
    { id: 'ev_charger', name: 'EV home charger installation', description: '7kW smart wallbox, dedicated cable run and PEN protection', baseLabourDays: 1, defaultSqM: 0 },
    { id: 'garden_power', name: 'Outdoor power & security lighting', description: 'Armoured cable, weatherproof sockets and sensor floodlights', baseLabourDays: 1, defaultSqM: 0 }
  ],
  photoShots: [
    { id: 'fuse_box_photo', label: 'Main fuse board', why: 'Shows incoming main fuse, meter and current board', required: true },
    { id: 'earth_bonding', label: 'Earth bonding pipe', why: 'Checks gas and water earth bonds', required: true }
  ],
  measureFields: [
    { id: 'house_size', label: 'House bedrooms / size', helper: 'Determines circuits required', type: 'segmented', defaultVal: '3bed', options: [{ value: '2bed', label: '1–2 Bed' }, { value: '3bed', label: '3 Bed' }, { value: '4bed', label: '4+ Bed', extraCost: 450 }], group: 'Size' },
    { id: 'sockets_count', label: 'Double socket outlets', helper: 'Number of twin power sockets to fit', type: 'stepper', min: 4, max: 40, defaultVal: 18, group: 'Outlets' },
    { id: 'lights_count', label: 'Lighting points / downlights', helper: 'Pendants or ceiling downlights', type: 'stepper', min: 2, max: 35, defaultVal: 12, group: 'Outlets' },
    { id: 'cable_run_length', label: 'Main supply cable run', helper: 'Metres from fuse board to EV / garden point', type: 'number', unit: 'm', imperialUnit: 'ft', min: 2, max: 50, defaultVal: 15, group: 'Cable' },
    { id: 'ev_power', label: 'EV Charger speed', helper: 'Smart charger wattage', type: 'segmented', defaultVal: '7kw', options: [{ value: '7kw', label: '7 kW Fast Charger' }, { value: '22kw', label: '22 kW (Requires 3-Phase)', extraCost: 850 }], group: 'Specs' },
    { id: 'certificate_type', label: 'Testing & building notice', helper: 'Part P certification & NICEIC signoff', type: 'segmented', defaultVal: 'part_p', options: [{ value: 'minor', label: 'Minor works cert' }, { value: 'part_p', label: 'Full EICR & Part P notice', extraCost: 150 }], group: 'Compliance' }
  ],
  questions: [
    { id: 'main_earth_good', text: 'Is main earth bonding intact at gas & water pipes?', options: [{ value: 'yes', label: 'Yes, 10mm earth visible' }, { value: 'no_earth', label: 'No earth or cut wire', priceEffect: { description: 'Run new 10mm copper main earth bonding', amount: 180, category: 'materials' }, flagEffect: { id: 'earth_flag', title: 'Main earthing missing', detail: 'Regulations require 10mm bonding to gas and incoming water mains.', type: 'warning' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'plaster_chasing', text: 'Chasing cables into solid brick walls?', options: [{ value: 'surface_trunking', label: 'Plastic surface mini-trunking' }, { value: 'flush_chasing', label: 'Chased into plaster & capped', priceEffect: { description: 'Wall chasing, galvanised capping and patching', amount: 480, category: 'labor' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'smoke_alarms', text: 'Fit mains-powered interlinked smoke alarms?', options: [{ value: 'yes', label: 'Yes, 3 interlinked alarms', priceEffect: { description: 'Aico mains interlinked heat & smoke alarms', amount: 260, category: 'materials' } }, { value: 'already_there', label: 'Already compliant' }] },
    { id: 'outdoor_cable_trench', text: 'Dig outdoor trench for armoured cable?', options: [{ value: 'contractor_digs', label: 'Electrician digs trench', priceEffect: { description: 'Trench digging 450mm deep and warning tape', amount: 320, category: 'labor' } }, { value: 'client_digs', label: 'Trench already dug' }, { value: 'clipped_fence', label: 'Clipped direct to wall' }] },
    { id: 'meter_tails_size', text: 'Are incoming meter tails 25mm thick?', options: [{ value: 'modern_25mm', label: 'Modern 25mm tails' }, { value: 'old_16mm', label: 'Old 16mm tails', priceEffect: { description: 'Upgrade meter tails and 100A double pole isolator', amount: 140, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'house_occupied', text: 'Will the house be occupied during rewiring?', options: [{ value: 'empty', label: 'Empty house' }, { value: 'occupied', label: 'Family living in house', priceEffect: { description: 'Temporary power restoration every evening', amount: 350, category: 'labor' } }] }
  ],
  priceBook: [
    { id: 'metal_consumer_unit', name: '10-way metal dual RCD consumer unit', category: 'materials', unit: 'item', defaultCost: 195, wastePct: 0, isDefault: true },
    { id: 'twin_earth_cable', name: 'Twin & earth cable 2.5mm roll (100m)', category: 'materials', unit: 'drum', defaultCost: 85, wastePct: 0, isDefault: true },
    { id: 'white_socket', name: 'Double 13A socket outlet with USB', category: 'materials', unit: 'item', defaultCost: 12.5, wastePct: 0, isDefault: true },
    { id: 'ev_wallbox', name: '7.4kW smart tethered EV wallbox', category: 'materials', unit: 'item', defaultCost: 520, wastePct: 0, isDefault: true },
    { id: 'part_p_fee', name: 'Building control Part P notification fee', category: 'fees', unit: 'job', defaultCost: 45, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 62, crewSize: 2, hoursPerSqM: 1.0 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Metal consumer unit with surge protection device', 'Full circuit insulation resistance testing', 'Electrical installation certificate provided'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'RCBO individual circuit breakers (prevents whole house tripping)', 'Upgraded USB-C charging points in bedrooms and kitchen', 'Mains interlinked smoke and heat detection'], scopeModifiers: () => ({ addedItems: [{ id: 'rcbo_nice', name: 'RCBO individual breaker upgrades', quantity: 1, unit: 'job', unitCost: 160, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Smart app-controlled dimmer lighting switches', 'Dedicated high-capacity car charger ready circuit', 'Screwless brushed steel faceplates throughout'], scopeModifiers: () => ({ addedItems: [{ id: 'faceplates_top', name: 'Screwless brushed steel decorative sockets', quantity: 18, unit: 'item', unitCost: 15, category: 'materials' }], extraDays: 1 }) }
  ],
  riskChecks: [
    { id: 'earth_bonding_risk', title: 'Main earthing missing', detail: 'Check water and gas meter for mandatory green/yellow 10mm bond.', triggeredIf: (a) => a.main_earth_good === 'no_earth' }
  ],
  exclusions: ['Plastering complete chased walls if decorator is booked', 'Energy supplier smart meter installation'],
  assumptions: ['Clear access to consumer unit cupboard', 'Main supplier cut-out fuse is intact and sealed'],
  customerWording: {
    headline: 'Your safe, certified electrical work',
    description: 'Modern, surge-protected wiring that keeps your family safe and powers all your home devices.',
    whatsIncluded: () => ['100% compliant installation by certified electrician', 'Surge protection device safeguarding smart TVs and computers', 'Rigorous instrument testing of all wires and breakers', 'Official electrical safety certificate filed with council', 'Clean hoovering of all drilling dust'],
    whatsNotIncluded: ['Painting chased plaster tracks', 'Replacing burned supplier meter cables']
  },
  sanityBands: {
    consumer_unit: { minPerSqM: 450, maxPerSqM: 1100, minPerSqFt: 450, maxPerSqFt: 1100 },
    full_rewire: { minPerSqM: 40, maxPerSqM: 95, minPerSqFt: 4, maxPerSqFt: 9.5 },
    ev_charger: { minPerSqM: 650, maxPerSqM: 1500, minPerSqFt: 650, maxPerSqFt: 1500 },
    garden_power: { minPerSqM: 350, maxPerSqM: 950, minPerSqFt: 350, maxPerSqFt: 950 }
  }
};

export const plumbingPack: TradePack = {
  id: 'plumbing',
  displayName: 'Plumbing & heating',
  jobWord: 'plumbing job',
  icon: 'Droplet',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'boiler_swap', name: 'Combi boiler replacement', description: 'A-rated condensing combi boiler, chemical flush & filter', baseLabourDays: 1, defaultSqM: 0 },
    { id: 'unvented_cylinder', name: 'Unvented hot water cylinder', description: 'Mains-pressure stainless cylinder for high-flow showers', baseLabourDays: 2, defaultSqM: 0 },
    { id: 'radiators_pipework', name: 'Full central heating radiators', description: 'New designer radiators, thermostatic valves and pipe runs', baseLabourDays: 3, defaultSqM: 80 }
  ],
  photoShots: [
    { id: 'boiler_location', label: 'Current boiler', why: 'Shows flue exit, gas pipe and drain pipe', required: true },
    { id: 'flue_terminal', label: 'Boiler flue outside', why: 'Checks clearance from windows and boundary', required: true }
  ],
  measureFields: [
    { id: 'radiator_count', label: 'Radiators in home', helper: 'Total radiators connected to system', type: 'stepper', min: 2, max: 20, defaultVal: 8, group: 'Radiators' },
    { id: 'boiler_kw', label: 'Boiler output size', helper: 'Kilowatt rating for home size', type: 'segmented', defaultVal: '30kw', options: [{ value: '25kw', label: '25 kW (1–2 Bed)' }, { value: '30kw', label: '30 kW (3 Bed / 2 Bath)' }, { value: '36kw', label: '36 kW (Large house)', extraCost: 350 }], group: 'Boiler' },
    { id: 'flue_type', label: 'Flue exit direction', helper: 'Where exhaust pipe goes', type: 'segmented', defaultVal: 'horizontal', options: [{ value: 'horizontal', label: 'Horizontal through wall' }, { value: 'vertical_roof', label: 'Vertical through roof', extraCost: 280 }], group: 'Boiler' },
    { id: 'gas_pipe_length', label: 'Gas pipe distance to meter', helper: 'Metres of 22mm copper pipe needed', type: 'number', unit: 'm', imperialUnit: 'ft', min: 1, max: 30, defaultVal: 8, group: 'Pipework' },
    { id: 'filter_type', label: 'Magnetic system filter', helper: 'Protects boiler from black sludge', type: 'segmented', defaultVal: 'magna_clean', options: [{ value: 'standard', label: 'Standard filter' }, { value: 'magna_clean', label: 'MagnaClean magnetic filter', extraCost: 140 }], group: 'Protection' },
    { id: 'thermostat_type', label: 'Room heating control', helper: 'Smart thermostat control', type: 'segmented', defaultVal: 'smart', options: [{ value: 'wireless', label: 'Standard wireless stat' }, { value: 'smart', label: 'Smart app control (Hive / Nest)', extraCost: 210 }], group: 'Protection' }
  ],
  questions: [
    { id: 'flue_clearance', text: 'Is flue terminal at least 300mm from openable window?', options: [{ value: 'yes', label: 'Yes, clear wall' }, { value: 'plume_kit', label: 'Close to window (needs plume kit)', priceEffect: { description: 'Flue plume diverter deflection kit', amount: 130, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'condensate_drain', text: 'Where will plastic condensate drain run?', options: [{ value: 'internal_waste', label: 'Direct to internal kitchen sink drain' }, { value: 'external_soak', label: 'Through wall to external gulley', priceEffect: { description: 'Trace-heated external condensate pipe', amount: 160, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'power_flush', text: 'Chemical power flush existing radiators?', options: [{ value: 'chemical_cleanse', label: 'Rapid chemical cleanse' }, { value: 'full_powerflush', label: 'High-pressure full powerflush', priceEffect: { description: 'Machine powerflush with acid inhibitor', amount: 380, category: 'labor' } }, { value: 'new_rads', label: 'All new radiators' }] },
    { id: 'gas_pipe_size', text: 'Is gas supply pipe 22mm thick?', options: [{ value: '22mm_ok', label: 'Yes, 22mm pipe' }, { value: '15mm_upgrade', label: 'Old 15mm (needs upgrade)', priceEffect: { description: 'Upgrade gas pipe from meter to 22mm', amount: 320, category: 'materials' }, flagEffect: { id: 'gas_size_flag', title: 'Gas pipe upgrade needed', detail: 'Modern combis require 22mm gas feed to maintain burner pressure.', type: 'warning' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'trv_valves', text: 'Replace manual radiator valves with thermostatic TRVs?', options: [{ value: 'yes', label: 'Yes, fit TRVs on all radiators', priceEffect: { description: 'Thermostatic radiator valves on all radiators', amount: 240, category: 'materials' } }, { value: 'no', label: 'Keep current valves' }] },
    { id: 'warranty_years', text: 'Boiler manufacturer warranty period?', options: [{ value: '5yr', label: '5 Year warranty' }, { value: '10yr', label: '10–12 Year warranty tier' }] }
  ],
  priceBook: [
    { id: 'combi_boiler_30kw', name: 'High-efficiency 30kW condensing combi', category: 'materials', unit: 'item', defaultCost: 1100, wastePct: 0, isDefault: true },
    { id: 'horizontal_flue', name: 'Standard telescopic horizontal flue kit', category: 'materials', unit: 'item', defaultCost: 95, wastePct: 0, isDefault: true },
    { id: 'magnetic_filter', name: 'Adey MagnaClean magnetic system filter', category: 'materials', unit: 'item', defaultCost: 125, wastePct: 0, isDefault: true },
    { id: 'system_inhibitor', name: 'System chemical cleaner & inhibitor pack', category: 'materials', unit: 'pack', defaultCost: 55, wastePct: 0, isDefault: true },
    { id: 'gas_safe_fee', name: 'Gas Safe register certification notice', category: 'fees', unit: 'job', defaultCost: 35, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 64, crewSize: 2, hoursPerSqM: 1.0 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Removal and safe disposal of old boiler', 'A-rated condensing combi boiler installed', 'Magnetic dirt filter & system inhibitor added', 'Gas Safe registration and warranty activation'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', '10-Year manufacturer parts and labour warranty', 'Smart wireless programmable room thermostat', 'Thermostatic valves on all bedroom radiators'], scopeModifiers: () => ({ addedItems: [{ id: 'smart_stat_nice', name: 'Smart wireless room thermostat (Hive style)', quantity: 1, unit: 'item', unitCost: 195, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Stainless steel unvented high-flow hot water system', 'Machine powerflush of every radiator in house', 'Scale reducer filter on incoming mains water'], scopeModifiers: () => ({ addedItems: [{ id: 'flush_top', name: 'High-pressure chemical machine powerflush', quantity: 1, unit: 'job', unitCost: 380, category: 'labor' }], extraDays: 1 }) }
  ],
  riskChecks: [
    { id: 'gas_capacity_risk', title: 'Gas pipe sizing check', detail: 'Check working gas pressure at meter with all burners lit.', triggeredIf: (a) => a.gas_pipe_size === '15mm_upgrade' }
  ],
  exclusions: ['Repairing internal leaks on old hidden pipes', 'Radiator decorating'],
  assumptions: ['Gas meter regulator is working correctly', 'Mains water pressure is above 1.0 bar'],
  customerWording: {
    headline: 'Your new heating & hot water system',
    description: 'Instant hot water and lower winter fuel bills from a whisper-quiet, modern condensing boiler.',
    whatsIncluded: () => ['Careful removal of your old appliance', 'New high-efficiency boiler with magnetic filter', 'Chemical cleansing of radiator pipes', 'Smart heating controls setup on your phone', 'Official Gas Safe building certificate issued'],
    whatsNotIncluded: ['Boxing in exposed pipes with woodwork', 'Bleeding unrelated radiators in other buildings']
  },
  sanityBands: {
    boiler_swap: { minPerSqM: 1800, maxPerSqM: 4200, minPerSqFt: 1800, maxPerSqFt: 4200 },
    unvented_cylinder: { minPerSqM: 2200, maxPerSqM: 5200, minPerSqFt: 2200, maxPerSqFt: 5200 },
    radiators_pipework: { minPerSqM: 35, maxPerSqM: 85, minPerSqFt: 3.5, maxPerSqFt: 8.5 }
  }
};

export const hvacPack: TradePack = {
  id: 'hvac',
  displayName: 'HVAC & heat pumps',
  jobWord: 'HVAC job',
  icon: 'Wind',
  defaultUnitSystem: 'metric',
  jobTypes: [
    { id: 'air_source_heatpump', name: 'Air source heat pump (ASHP)', description: 'Outdoor heat pump unit, buffer tank, controls and radiator upsizing', baseLabourDays: 4, defaultSqM: 120 },
    { id: 'multisplit_ac', name: 'Multi-split air conditioning', description: 'Outdoor inverter heat pump with 2–4 indoor wall units', baseLabourDays: 2, defaultSqM: 60 },
    { id: 'ducted_heat', name: 'Ducted heat recovery ventilation (MVHR)', description: 'Whole-house continuous fresh air ventilation with heat recovery', baseLabourDays: 3, defaultSqM: 110 }
  ],
  photoShots: [
    { id: 'outdoor_unit_spot', label: 'Outdoor unit ground spot', why: 'Shows concrete base area, air circulation and boundary gap', required: true },
    { id: 'cylinder_cupboard', label: 'Indoor cylinder space', why: 'Checks height for 250L heat pump hot water cylinder', required: true }
  ],
  measureFields: [
    { id: 'floor_area_heat', label: 'Total heated floor area', helper: 'Square metres of house to heat', type: 'number', unit: 'm²', imperialUnit: 'sq ft', min: 30, max: 350, defaultVal: 110, group: 'Size' },
    { id: 'indoor_units_count', label: 'Indoor AC wall units', helper: 'Number of air conditioning heads', type: 'stepper', min: 1, max: 6, defaultVal: 2, group: 'Units' },
    { id: 'heat_pump_kw', label: 'Heat pump capacity', helper: 'Outdoor output size', type: 'segmented', defaultVal: '8kw', options: [{ value: '5kw', label: '5 kW (Small/flat)' }, { value: '8kw', label: '8 kW (Standard 3-bed)' }, { value: '12kw', label: '12–16 kW (Large house)', extraCost: 850 }], group: 'Specs' },
    { id: 'refrigerant_run', label: 'Refrigerant pipe run length', helper: 'Distance from indoor heads to outdoor unit', type: 'number', unit: 'm', imperialUnit: 'ft', min: 2, max: 30, defaultVal: 10, group: 'Pipe' },
    { id: 'ground_bracket', label: 'Outdoor mount type', helper: 'Mounting outdoor inverter', type: 'segmented', defaultVal: 'ground_slab', options: [{ value: 'ground_slab', label: 'Anti-vibration ground slab' }, { value: 'wall_bracket', label: 'Heavy wall cantilever bracket', extraCost: 180 }], group: 'Specs' },
    { id: 'smart_controls', label: 'Weather compensation control', helper: 'Modulates heat automatically based on outdoor temp', type: 'segmented', defaultVal: 'weather_comp', options: [{ value: 'standard', label: 'Basic stat' }, { value: 'weather_comp', label: 'Weather compensation & app' }], group: 'Protection' }
  ],
  questions: [
    { id: 'power_supply_capacity', text: 'Does home fuse box have spare 32A breaker for heat pump?', options: [{ value: 'yes', label: 'Yes, spare breaker ready' }, { value: 'need_subboard', label: 'Needs dedicated sub-board', priceEffect: { description: 'Dedicated heat pump electrical supply & isolator', amount: 450, category: 'extras' }, flagEffect: { id: 'hvac_electric_flag', title: 'Electrical supply required', detail: 'Electrician needed to pull dedicated supply to outdoor unit.', type: 'warning' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'radiator_upgrade', text: 'Do radiators need upsizing for low-temperature heat pump?', options: [{ value: 'none', label: 'Underfloor heating already' }, { value: 'upsize_some', label: 'Upsize 4 key radiators', priceEffect: { description: 'High-output K2 radiators for heat pump flow', amount: 680, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'condensate_drain_hvac', text: 'Where will indoor cooling condensate drain?', options: [{ value: 'gravity', label: 'Gravity fall outside wall' }, { value: 'mini_pump', label: 'Needs silent mini condensate pump', priceEffect: { description: 'Silent electronic condensate removal pump', amount: 160, category: 'materials' } }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'trunking_finish', text: 'Refrigerant pipe cosmetic trunking colour?', options: [{ value: 'white', label: 'Clean white trunking' }, { value: 'anthracite', label: 'Anthracite grey trunking' }, { value: 'brown', label: 'Brown brick match' }] },
    { id: 'planning_boundary', text: 'Is outdoor unit at least 1m from neighbor boundary?', options: [{ value: 'yes', label: 'Yes, permitted development compliant' }, { value: 'tight', label: 'Tight boundary (acoustic check needed)' }, { value: 'not_sure', label: 'Not sure' }] },
    { id: 'annual_service', text: 'Include 1st year seasonal maintenance visit?', options: [{ value: 'yes', label: 'Yes, 1-year service visit included' }, { value: 'no', label: 'Installation only' }] }
  ],
  priceBook: [
    { id: 'ashp_unit', name: 'Monobloc 8kW air source heat pump unit', category: 'materials', unit: 'item', defaultCost: 3400, wastePct: 0, isDefault: true },
    { id: 'heatpump_cylinder', name: '250L pre-plumbed stainless heat pump tank', category: 'materials', unit: 'item', defaultCost: 1450, wastePct: 0, isDefault: true },
    { id: 'copper_pairs', name: 'Insulated pair-coil refrigerant pipe (20m)', category: 'materials', unit: 'roll', defaultCost: 160, wastePct: 0, isDefault: true },
    { id: 'anti_vib_feet', name: 'Rubber anti-vibration mounting rails', category: 'materials', unit: 'set', defaultCost: 65, wastePct: 0, isDefault: true },
    { id: 'f_gas_fee', name: 'F-Gas pressure test & vacuum certification', category: 'fees', unit: 'job', defaultCost: 180, wastePct: 0, isDefault: true }
  ],
  labourRates: { hourlyRate: 60, crewSize: 2, hoursPerSqM: 1.0 },
  packages: [
    { id: 'basic', name: 'Basic', bullets: ['Outdoor inverter unit mounted on anti-vibration slab', 'Insulated refrigerant line runs with tidy trunking', 'Nitrogen pressure testing and vacuum dehydration', 'Digital remote control & commissioning'], scopeModifiers: () => ({ addedItems: [] }) },
    { id: 'nice', name: 'Nice', bullets: ['Everything in Basic', 'Wi-Fi smartphone app climate scheduling', 'A+++ ultra-quiet indoor wall units with air purification', '5-year manufacturer parts guarantee'], scopeModifiers: () => ({ addedItems: [{ id: 'wifi_nice', name: 'Smart Wi-Fi climate interface modules', quantity: 1, unit: 'job', unitCost: 180, category: 'materials' }] }) },
    { id: 'top', name: 'Top', bullets: ['Everything in Nice', 'Full heat pump hot water integration with 250L cylinder', 'Weather-compensating smart central controller', 'Sound-dampening acoustic enclosure wrap'], scopeModifiers: () => ({ addedItems: [{ id: 'cylinder_top', name: 'High-efficiency heat pump hot water cylinder', quantity: 1, unit: 'item', unitCost: 1450, category: 'materials' }], extraDays: 2 }) }
  ],
  riskChecks: [
    { id: 'hvac_breaker_risk', title: 'Dedicated electrical circuit check', detail: 'Ensure consumer unit has spare capacity for compressor surge.', triggeredIf: (a) => a.power_supply_capacity === 'need_subboard' }
  ],
  exclusions: ['Three-phase electricity grid upgrade fees', 'Interior wall plastering after trunking'],
  assumptions: ['Clear outdoor perimeter for air circulation around fan', 'Customer provides Wi-Fi password for smart thermostat linking'],
  customerWording: {
    headline: 'Your efficient home climate control',
    description: 'Enjoy whisper-quiet cooling in summer and super-efficient warmth all winter long.',
    whatsIncluded: () => ['Certified installation by F-Gas qualified engineers', 'Vibration-free mounting that prevents hums through walls', 'Tidy outdoor pipe casing matched to your exterior', 'Complete pressure testing and vacuum purge', 'Phone app demonstration before handover'],
    whatsNotIncluded: ['Repairing unrelated electric heaters', 'Structural wall changes']
  },
  sanityBands: {
    air_source_heatpump: { minPerSqM: 6000, maxPerSqM: 14000, minPerSqFt: 6000, maxPerSqFt: 14000 },
    multisplit_ac: { minPerSqM: 1800, maxPerSqM: 4500, minPerSqFt: 1800, maxPerSqFt: 4500 },
    ducted_heat: { minPerSqM: 3200, maxPerSqM: 7500, minPerSqFt: 3200, maxPerSqFt: 7500 }
  }
};
