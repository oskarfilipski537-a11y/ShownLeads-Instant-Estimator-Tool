export type UnitSystem = 'metric' | 'imperial';

// Conversion factors
export const M_TO_FT = 3.28084;
export const FT_TO_M = 0.3048;
export const SQM_TO_SQFT = 10.7639;
export const SQFT_TO_SQM = 0.092903;

/**
 * Formats a metric dimension (length in meters) into the active unit system
 */
export function formatLength(meters: number, system: UnitSystem, decimals = 1): string {
  if (system === 'imperial') {
    const feet = meters * M_TO_FT;
    return `${feet.toFixed(decimals)} ft`;
  }
  return `${meters.toFixed(decimals)} m`;
}

/**
 * Formats a metric area (sq meters) into the active unit system
 */
export function formatArea(sqm: number, system: UnitSystem, decimals = 0): string {
  if (system === 'imperial') {
    const sqft = sqm * SQM_TO_SQFT;
    return `${sqft.toFixed(decimals)} sq ft`;
  }
  return `${sqm.toFixed(decimals)} m²`;
}

/**
 * Returns the unit label for area based on system
 */
export function getAreaUnit(system: UnitSystem): string {
  return system === 'imperial' ? 'sq ft' : 'm²';
}

/**
 * Returns the unit label for length based on system
 */
export function getLengthUnit(system: UnitSystem): string {
  return system === 'imperial' ? 'ft' : 'm';
}

/**
 * Converts user input in current system back to internal canonical metric
 */
export function toCanonicalLength(value: number, system: UnitSystem): number {
  if (system === 'imperial') {
    return value * FT_TO_M;
  }
  return value;
}

export function toDisplayLength(canonicalMeters: number, system: UnitSystem): number {
  if (system === 'imperial') {
    return Number((canonicalMeters * M_TO_FT).toFixed(1));
  }
  return Number(canonicalMeters.toFixed(1));
}

export function toCanonicalArea(value: number, system: UnitSystem): number {
  if (system === 'imperial') {
    return value * SQFT_TO_SQM;
  }
  return value;
}

export function toDisplayArea(canonicalSqm: number, system: UnitSystem): number {
  if (system === 'imperial') {
    return Math.round(canonicalSqm * SQM_TO_SQFT);
  }
  return Math.round(canonicalSqm);
}

/**
 * Formats currency nicely with commas and symbol
 */
export function formatMoney(amount: number, currency = '$'): string {
  const rounded = Math.round(amount);
  const formatted = rounded.toLocaleString('en-US');
  return `${currency}${formatted}`;
}

export function formatUnitCost(costPerCanonicalUnit: number, unit: string, system: UnitSystem, currency = '$'): string {
  if (system === 'imperial') {
    if (unit === 'm²') {
      const costPerSqFt = costPerCanonicalUnit / SQM_TO_SQFT;
      return `${currency}${costPerSqFt.toFixed(1)} / sq ft`;
    }
    if (unit === 'm') {
      const costPerFt = costPerCanonicalUnit / M_TO_FT;
      return `${currency}${costPerFt.toFixed(1)} / ft`;
    }
  }
  return `${currency}${costPerCanonicalUnit.toFixed(1)} / ${unit}`;
}
