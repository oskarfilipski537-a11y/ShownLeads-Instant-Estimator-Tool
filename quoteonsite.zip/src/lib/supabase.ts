import { createClient } from '@supabase/supabase-js';

const SUPABASE_FALLBACK_URL = 'https://vlhobumjnpuzhihpqgkt.supabase.co';
const SUPABASE_FALLBACK_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZsaG9idW1qbnB1emhpaHBxZ2t0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMxMDY0MzIsImV4cCI6MjEwODY4MjQzMn0.cYjn9wFvAiM42_IQLKscS4cY_313kFcPmuaMgEndC9k';

export const supabaseUrl =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) ||
  SUPABASE_FALLBACK_URL;

export const supabaseAnonKey =
  (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) ||
  SUPABASE_FALLBACK_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storage: typeof window !== 'undefined' ? window.localStorage : undefined,
  },
});

/**
 * Storage Bucket Upload Helpers
 * Always uses the file path: {userId}/{filename}
 */

export interface StorageUploadResult {
  success: boolean;
  publicUrl?: string;
  storagePath?: string;
  error?: string;
}

export async function uploadToBucket(
  bucket: 'estimate-photos' | 'logos' | 'past-quotes',
  userId: string,
  filename: string,
  fileOrBlob: File | Blob
): Promise<StorageUploadResult> {
  if (!userId) {
    return { success: false, error: 'User must be authenticated to upload files.' };
  }

  // Sanitize filename and construct {userId}/{filename}
  const cleanFilename = filename.replace(/[^a-zA-Z0-9._-]/g, '_');
  const filePath = `${userId}/${Date.now()}_${cleanFilename}`;

  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(filePath, fileOrBlob, {
        upsert: true,
        cacheControl: '3600',
      });

    if (error) {
      console.warn(`Storage upload to ${bucket} warning:`, error.message);
      // If the bucket needs public access or RLS, still return the standard expected path
      return {
        success: false,
        error: error.message,
        storagePath: filePath,
      };
    }

    const { data: urlData } = supabase.storage.from(bucket).getPublicUrl(data.path);

    return {
      success: true,
      storagePath: data.path,
      publicUrl: urlData?.publicUrl || '',
    };
  } catch (err: any) {
    console.error(`Upload error to ${bucket}:`, err);
    return {
      success: false,
      error: err.message || 'File upload failed',
    };
  }
}

export async function uploadEstimatePhoto(
  userId: string,
  fileOrBlob: File | Blob,
  filename: string = 'photo.jpg'
): Promise<StorageUploadResult> {
  return uploadToBucket('estimate-photos', userId, filename, fileOrBlob);
}

export async function uploadCompanyLogo(
  userId: string,
  fileOrBlob: File | Blob,
  filename: string = 'logo.png'
): Promise<StorageUploadResult> {
  return uploadToBucket('logos', userId, filename, fileOrBlob);
}

export async function uploadPastQuote(
  userId: string,
  fileOrBlob: File | Blob,
  filename: string = 'quote.pdf'
): Promise<StorageUploadResult> {
  return uploadToBucket('past-quotes', userId, filename, fileOrBlob);
}
